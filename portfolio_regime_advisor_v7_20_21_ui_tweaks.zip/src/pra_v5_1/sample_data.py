from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Dict, List, Optional

import pandas as pd

from .cache import MarketDataCache
from .utils import normalize_ticker


@dataclass
class BootstrapResult:
    ticker: str
    providers: List[str]
    rows: int
    start_date: str
    end_date: str
    is_sample_data: bool = True


def _ticker_seed(ticker: str) -> float:
    # Deterministic ticker-specific seed without random module dependency.
    return (sum(ord(ch) for ch in normalize_ticker(ticker)) % 97) / 97.0


def make_sample_ohlcv(ticker: str, start: str = "2013-01-01", end: Optional[str] = None, periods: Optional[int] = None) -> pd.DataFrame:
    """Create deterministic non-random OHLCV data for local UI/API smoke tests.

    This is not market data and must never be used for model performance claims.
    It exists so that API, Stitch UI, allocation, validation, and prediction-cache
    flows can be tested before KIS credentials or network access are available.
    """
    t = normalize_ticker(ticker)
    if periods is not None:
        dates = pd.bdate_range(start=start, periods=int(periods))
    else:
        end_ts = pd.to_datetime(end) if end else pd.Timestamp.today().normalize()
        dates = pd.bdate_range(start=start, end=end_ts)
    if len(dates) == 0:
        dates = pd.bdate_range(start=start, periods=800)
    seed = _ticker_seed(t)
    base = 50.0 + seed * 150.0
    trend = 0.00010 + seed * 0.00025
    amp1 = 0.018 + seed * 0.012
    amp2 = 0.006 + seed * 0.004
    rows = []
    price_prev = base
    for i, dt in enumerate(dates):
        cycle = math.sin(i / 17.0 + seed * 5.0) * amp1 + math.sin(i / 63.0 + seed * 2.0) * amp2
        close = base * ((1.0 + trend) ** i) * (1.0 + cycle)
        open_ = price_prev * (1.0 + math.sin(i / 11.0 + seed) * 0.002)
        high = max(open_, close) * (1.003 + abs(math.sin(i / 13.0)) * 0.004)
        low = min(open_, close) * (0.997 - abs(math.cos(i / 19.0)) * 0.003)
        volume = int(500_000 + seed * 2_000_000 + (1 + math.sin(i / 23.0)) * 250_000)
        rows.append({"Date": dt.date().isoformat(), "Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume})
        price_prev = close
    return pd.DataFrame(rows)


def bootstrap_sample_cache(
    cache: MarketDataCache,
    tickers: Iterable[str],
    providers: Iterable[str] = ("yahoo", "hybrid"),
    start: str = "2013-01-01",
    end: Optional[str] = None,
    periods: Optional[int] = None,
    overwrite: bool = False,
) -> List[BootstrapResult]:
    results: List[BootstrapResult] = []
    provider_list = [str(p).lower() for p in providers]
    for raw in tickers:
        t = normalize_ticker(raw)
        wrote: List[str] = []
        df = make_sample_ohlcv(t, start=start, end=end, periods=periods)
        for provider in provider_list:
            if provider not in {"yahoo", "hybrid", "kis"}:
                continue
            if not overwrite and cache.has_ohlcv(t, provider):
                continue
            cache.write_ohlcv(t, df, provider=provider)
            wrote.append(provider)
        if wrote:
            results.append(BootstrapResult(ticker=t, providers=wrote, rows=len(df), start_date=str(df["Date"].iloc[0]), end_date=str(df["Date"].iloc[-1])))
    return results
