from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Callable

import pandas as pd

from .allocation import PortfolioAllocationService
from .constants import TRADING_DAYS_PER_YEAR
from .cache import MarketDataCache
from .config import AppConfig
from .logging_utils import JsonlLogger
from .performance import PerformanceAnalyzer
from .prediction_engine import PredictionGenerationService, PredictionRepository
from .provider import DailyMarketDataUpdater
from .schemas import DailyUpdateRequest, PortfolioAssetInput, PortfolioEvaluateRequest, PredictionGenerateRequest, KisSettingsSaveRequest, BootstrapSampleDataRequest, RunLatestRequest
from .signals import SignalClassifier
from .sample_data import bootstrap_sample_cache
from .ticker_registry import LocalTickerRegistry
from .utils import PraCancelledError, atomic_write_json, config_hash, ensure_dir, normalize_ticker, utc_now_iso
from .ui_contract import postprocess_dashboard_payload
from .validation import ValidationService


class PortfolioRegimeAdvisorService:
    def __init__(self, config: AppConfig | None = None):
        self.config = config or AppConfig.from_json()
        ensure_dir(self.config.storage_root)
        self.registry = LocalTickerRegistry(self.config.registry_path)
        self.cache = MarketDataCache(self.config.cache_dir)
        self.updater = DailyMarketDataUpdater(self.cache, self.config)
        self.pred_repo = PredictionRepository(self.config.prediction_dir)
        self.pred_gen = PredictionGenerationService(
            self.cache,
            self.pred_repo,
            self.config.run_dir,
            external_script_path=self.config.external_v8641_script,
        )
        self.allocator = PortfolioAllocationService()
        self.performance = PerformanceAnalyzer()
        self.validator = ValidationService()
        self.signals = SignalClassifier()
        self.logger = JsonlLogger(self.config.log_dir / "events.jsonl")

    @property
    def latest_request_path(self) -> Path:
        return self.config.config_dir / "latest_portfolio_request.json"

    @property
    def latest_dashboard_path(self) -> Path:
        return self.config.storage_root / "latest_dashboard_payload.json"



    def _risk_volatility_estimates(self, tickers: List[str], provider: str, lookback: int = TRADING_DAYS_PER_YEAR) -> Dict[str, float]:
        """Estimate annualized realized volatility from cached OHLCV data.

        This supports ``capital_mode='inverse_vol'`` without silently falling
        back to current weights. The cache provider is the same provider used by
        the model, including ``auto`` after KIS/Yahoo fallback resolution.
        """
        vols: Dict[str, float] = {}
        for raw in tickers:
            t = normalize_ticker(raw)
            try:
                df = self.cache.read_ohlcv(t, provider)
                close = pd.to_numeric(df.get("Close"), errors="coerce")
                ret = close.pct_change().dropna().tail(int(lookback))
                if len(ret) >= 60:
                    vol = float(ret.std() * (float(TRADING_DAYS_PER_YEAR) ** 0.5))
                    if pd.notna(vol) and vol > 0:
                        vols[t] = vol
            except Exception as exc:
                self.logger.write("risk_volatility_estimate_failed", ticker=t, provider=provider, error=str(exc))
        return vols

    def cache_inventory(self, tickers: List[str] | None = None) -> Dict[str, Any]:
        """Return provider-specific OHLCV cache status for the local app UI.

        Provider cache policy:
        - yahoo  -> storage/market_cache/ohlcv/yahoo/{TICKER}.csv
        - kis    -> storage/market_cache/ohlcv/kis/{TICKER}.csv
        - hybrid -> storage/market_cache/ohlcv/hybrid/{TICKER}.csv

        The hybrid cache is not a replacement for raw KIS storage. When KIS data
        is successfully fetched, raw KIS rows are saved under provider='kis' and
        the merged Yahoo+KIS view is saved under provider='hybrid'.
        """
        from .utils import normalize_ticker
        providers = ["auto", "yahoo", "kis", "hybrid"]
        default_tickers = [self.config.default_bond_ticker, self.config.default_cash_ticker]
        if tickers is None:
            seen = []
            for t in [*self.registry.enabled_tickers(), *default_tickers]:
                nt = normalize_ticker(t)
                if nt and nt not in seen:
                    seen.append(nt)
            tickers = seen
        rows = []
        for raw in tickers:
            t = normalize_ticker(raw)
            item = {"ticker": t, "providers": {}}
            for provider in providers:
                path = self.cache.ohlcv_path(t, provider)
                item["providers"][provider] = {
                    "exists": path.exists(),
                    "path": str(path),
                    "latest_date": self.cache.latest_date(t, provider) if path.exists() else None,
                    "rows": int(len(self.cache.read_ohlcv(t, provider))) if path.exists() else 0,
                }
            rows.append(item)
        return {
            "ok": True,
            "storage_root": str(self.config.storage_root),
            "cache_root": str(self.config.cache_dir / "ohlcv"),
            "providers": providers,
            "policy": {
                "yahoo": "Raw Yahoo OHLCV cache.",
                "kis": "Raw KIS OHLCV cache. Created only after a successful KIS fetch.",
                "hybrid": "Merged view: Yahoo historical backfill + KIS overlay. KIS duplicate dates win.",
            },
            "items": rows,
        }

    def provider_status(self) -> Dict[str, Any]:
        kis = self.kis_status()
        return {
            "default_provider": self.config.default_provider,
            "supported_providers": ["auto", "yahoo", "kis", "hybrid"],
            "recommended_without_kis_key": "yahoo",
            "recommended_with_kis_key": "hybrid",
            "provider_notes": {
                "yahoo": "Uses yfinance for long historical OHLCV cache.",
                "kis": "Uses KIS quotation/daily OHLCV only; credentials required.",
                "hybrid": "Yahoo historical backfill plus KIS latest overlay when KIS credentials are configured; otherwise degrades to Yahoo-only hybrid cache with warnings.",
            },
            "kis": kis,
            "order_execution": False,
            "realtime_streaming": False,
        }

    def bootstrap_sample_data(self, req: BootstrapSampleDataRequest) -> Dict[str, Any]:
        results = bootstrap_sample_cache(
            self.cache,
            req.tickers,
            providers=req.providers,
            start=req.start,
            end=req.end,
            periods=req.periods,
            overwrite=req.overwrite,
        )
        payload = {
            "ok": True,
            "is_sample_data": True,
            "warning": "Generated deterministic sample OHLCV for local UI/API smoke tests only. Do not use this cache for model performance claims or investment decisions.",
            "results": [r.__dict__ for r in results],
        }
        self.logger.write("bootstrap_sample_data", **payload)
        return payload

    def load_latest_dashboard(self) -> Dict[str, Any]:
        from .utils import load_json
        payload = load_json(self.latest_dashboard_path, default=None)
        if not payload:
            raise FileNotFoundError(f"Latest dashboard payload not found: {self.latest_dashboard_path}")
        return payload

    def latest_validation(self) -> Dict[str, Any]:
        dashboard = self.load_latest_dashboard()
        return {
            "ok": bool(dashboard.get("ok")),
            "request_id": dashboard.get("request_id"),
            "as_of_date": dashboard.get("as_of_date"),
            "engine_status": dashboard.get("engine_status"),
            "validation": dashboard.get("validation"),
        }

    def run_latest(self, req: RunLatestRequest | None = None) -> Dict[str, Any]:
        from .utils import load_json
        data = load_json(self.latest_request_path, default=None)
        if not data:
            raise FileNotFoundError(f"Latest portfolio request not found: {self.latest_request_path}")
        request = PortfolioEvaluateRequest.model_validate(data)
        if req is not None:
            overrides = {
                "provider": req.provider,
                "prediction_engine_mode": req.prediction_engine_mode,
                "prediction_run_mode": req.prediction_run_mode,
                "latest_train_rows": req.latest_train_rows,
                "update_data": req.update_data,
                "generate_predictions": req.generate_predictions,
                "force_update": req.force_update,
                "force_prediction": req.force_prediction,
                "speed_profile": req.speed_profile,
            }
            update = {k: v for k, v in overrides.items() if v is not None}
            if update:
                current = request.settings.model_dump()
                current.update(update)
                request.settings = request.settings.__class__.model_validate(current)
        return self.evaluate(request)

    def add_tickers(self, tickers: List[str], asset_type: str = "stock", market: str = "US", note: str | None = None) -> Dict:
        records = self.registry.add_or_update(tickers, asset_type=asset_type, market=market, note=note)
        return {"ok": True, "tickers": [r.__dict__ for r in records]}

    def update_daily(
        self,
        req: DailyUpdateRequest,
        cancel_event: object | None = None,
        progress_callback: Callable[[int, int, str, str], None] | None = None,
    ) -> Dict:
        tickers = req.tickers or self.registry.enabled_tickers()
        status = self.updater.update_daily(
            tickers,
            provider=req.provider,
            start=req.start,
            end=req.end,
            force=req.force,
            cancel_event=cancel_event,
            progress_callback=progress_callback,
        )
        payload = {"provider": status.provider, "updated": status.updated, "skipped": status.skipped, "errors": status.errors, "notes": status.notes or []}
        self.logger.write("daily_update", **payload)
        return payload

    def kis_status(self) -> Dict:
        return self.updater.kis_status()

    def save_kis_settings(self, req: KisSettingsSaveRequest) -> Dict:
        from .kis_provider import KisSettings
        settings = KisSettings(
            app_key=req.app_key,
            app_secret=req.app_secret,
            base_url=req.base_url.rstrip("/"),
            virtual_trade=req.virtual_trade,
            account_no=req.account_no or "",
            account_product_code=req.account_product_code,
            overseas_exchange=req.overseas_exchange,
            custtype=req.custtype,
            access_token=req.access_token or "",
        )
        path = self.updater.kis_store.save(settings, persist_secret=req.persist_secret)
        payload = {"ok": True, "path": str(path), "settings": settings.redacted(), "warning": "KIS credentials are stored in a local-only config file. Do not commit or share it."}
        self.logger.write("kis_settings_saved", ok=True, path=str(path))
        return payload

    def generate_predictions(self, req: PredictionGenerateRequest, risk_sensitivity: float = 1.0, provider: str = "yahoo", cancel_event: object | None = None, progress_callback: Callable[[float, str, str | None], None] | None = None) -> Dict:
        """Generate predictions with the real v8.6.41 model script path only.

        The old reference-compatible lightweight engine has been removed because it
        could be mistaken for a real model. The only supported mode is now
        external_v8641_xgb.
        """
        tickers = req.tickers or self.registry.enabled_tickers()
        if req.mode != "external_v8641_xgb":
            raise ValueError("Only external_v8641_xgb is supported. The lightweight reference engine was removed in v6.5.")
        results = self.pred_gen.generate_external_v8641_xgb(
            tickers,
            provider=provider,
            force=req.force,
            speed_profile=req.speed_profile,
            start=req.start,
            end=req.end,
            transaction_cost_bps=req.transaction_cost_bps,
            prediction_run_mode=req.prediction_run_mode,
            latest_train_rows=req.latest_train_rows,
            backtest_start_date=getattr(req, "backtest_start_date", None),
            cancel_event=cancel_event,
            progress_callback=progress_callback,
            progress_start=0.44,
            progress_end=0.64,
        )
        payload = {"ok": all(not r.errors for r in results), "results": [r.__dict__ | {"path": str(r.path)} for r in results]}
        self.logger.write("prediction_generation", **payload)
        return payload

    @staticmethod
    def _risk_assets(portfolio: List[PortfolioAssetInput]) -> List[PortfolioAssetInput]:
        return [a for a in portfolio if a.is_risk_asset]

    def _defensive_return_frame(self, ticker: str, provider: str, col: str) -> pd.DataFrame:
        try:
            df = self.cache.read_ohlcv(ticker, provider=provider)
        except Exception:
            return pd.DataFrame(columns=["Date", col])
        if df.empty or "Date" not in df.columns or "Close" not in df.columns:
            return pd.DataFrame(columns=["Date", col])
        out = df[["Date", "Close"]].copy()
        out["Date"] = pd.to_datetime(out["Date"])
        out[col] = pd.to_numeric(out["Close"], errors="coerce").pct_change().fillna(0.0)
        return out[["Date", col]]

    def _attach_defensive_returns_to_performance(
        self,
        perf_df: pd.DataFrame,
        provider: str,
        bond_weight: float,
        cash_weight: float,
    ) -> tuple[pd.DataFrame, List[str]]:
        """Add cached defensive ETF returns to recommended portfolio performance.

        Earlier versions reported model performance using only risk-asset returns.
        That implicitly treated recommended bond/cash buckets as 0% return. For a
        personal portfolio dashboard, this can distort CAGR, volatility, MDD, and
        benchmark comparisons. v6.0 uses configured defensive proxies when cached.
        """
        notes: List[str] = []
        if perf_df is None or perf_df.empty:
            return perf_df, notes
        out = perf_df.copy()
        out["Date"] = pd.to_datetime(out["Date"])
        risk_return = pd.to_numeric(out["portfolio_return"], errors="coerce").fillna(0.0)

        bond_col = "bond_bucket_return"
        cash_col = "cash_bucket_return"
        bond = self._defensive_return_frame(self.config.default_bond_ticker, provider, bond_col)
        cash = self._defensive_return_frame(self.config.default_cash_ticker, provider, cash_col)

        if bond_weight > 0 and bond.empty:
            notes.append(f"{self.config.default_bond_ticker} cache unavailable; recommended bond bucket return treated as 0.")
        if cash_weight > 0 and cash.empty:
            notes.append(f"{self.config.default_cash_ticker} cache unavailable; recommended cash bucket return treated as 0.")

        if not bond.empty:
            out = pd.merge(out, bond, on="Date", how="left")
        else:
            out[bond_col] = 0.0
        if not cash.empty:
            out = pd.merge(out, cash, on="Date", how="left")
        else:
            out[cash_col] = 0.0

        out["risk_asset_return"] = risk_return.values
        out["portfolio_return"] = (
            pd.to_numeric(out["risk_asset_return"], errors="coerce").fillna(0.0)
            + pd.to_numeric(out[bond_col], errors="coerce").fillna(0.0) * float(bond_weight)
            + pd.to_numeric(out[cash_col], errors="coerce").fillna(0.0) * float(cash_weight)
        )
        out["equity"] = (1 + out["portfolio_return"].fillna(0.0)).cumprod()
        out["drawdown"] = out["equity"] / out["equity"].cummax() - 1
        return out, notes

    def _current_buy_and_hold_performance(
        self,
        request: PortfolioEvaluateRequest,
        prediction_frames: Dict[str, pd.DataFrame],
        provider: str,
    ) -> tuple[Dict[str, Any], pd.DataFrame, List[str]]:
        """Compute static current-portfolio buy-and-hold performance.

        This is not a benchmark universe such as SPY/QQQ/60-40. It is the user's
        own entered portfolio held at the input weights. Risk assets use the same
        stock_next_return series used for model-recommended performance; bond and
        cash buckets use the configured defensive proxy returns when available.
        """
        risk_weights: Dict[str, float] = {}
        bond_weight = 0.0
        cash_weight = 0.0
        for asset in request.portfolio:
            if not asset.enabled:
                continue
            w = float(asset.current_weight or 0.0)
            t = asset.ticker
            at = asset.asset_type
            if asset.is_risk_asset:
                risk_weights[t] = risk_weights.get(t, 0.0) + w
            elif at in {"cash", "cash_bucket"} or t in {"CASH", "CASH_BUCKET"}:
                cash_weight += w
            elif at in {"bond", "bond_etf", "bond_bucket"} or t == "BOND_BUCKET":
                bond_weight += w
        bh_df = self.performance.portfolio_returns(
            prediction_frames,
            risk_weights,
            missing_asset_policy=request.settings.missing_asset_policy,
        )
        bh_df, notes = self._attach_defensive_returns_to_performance(
            bh_df,
            provider=provider,
            bond_weight=bond_weight,
            cash_weight=cash_weight,
        )
        returns = bh_df["portfolio_return"] if not bh_df.empty else pd.Series(dtype=float)
        metrics = self.performance.metrics(returns)
        return metrics, bh_df, notes

    def evaluate(self, request: PortfolioEvaluateRequest, progress_callback: Callable[[float, str, str | None], None] | None = None, cancel_event: object | None = None) -> Dict:
        def check_cancel() -> None:
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                raise PraCancelledError("사용자가 분석을 취소했습니다.")

        def progress(percent: float, stage: str, message: str | None = None) -> None:
            check_cancel()
            if progress_callback is None:
                return
            try:
                progress_callback(percent, stage, message)
            except Exception:
                pass
            check_cancel()

        progress(0.04, "요청 준비", "입력 포트폴리오와 실행 설정을 저장합니다.")
        request_id = config_hash(request.model_dump())
        ensure_dir(self.config.config_dir)
        atomic_write_json(self.latest_request_path, request.model_dump())
        self.logger.write("portfolio_evaluate_started", request_id=request_id, user_level=request.user_level)
        risk_assets = self._risk_assets(request.portfolio)
        risk_tickers = [a.ticker for a in risk_assets]
        if not risk_tickers:
            raise ValueError("At least one risk asset ticker is required")
        progress(0.08, "위험자산 확인", f"모델 실행 대상: {', '.join(risk_tickers)}")
        # Registry update is local JSON only, not user account storage.
        self.registry.add_or_update(risk_tickers, asset_type="risk_asset", market="US", note="from_evaluate_request")
        # Data update. Besides risk assets, update defensive proxies so recommended
        # portfolio performance can include bond/cash bucket returns. Standalone
        # benchmark comparison was removed in v6.5.
        if request.settings.update_data:
            progress(0.16, "OHLCV 다운로드/캐시 갱신", f"provider={request.settings.provider}; auto는 KIS 우선, 실패 시 Yahoo fallback으로 주식/ETF와 방어자산 데이터를 준비합니다.")
            defensive_tickers = [self.config.default_bond_ticker, self.config.default_cash_ticker]
            update_tickers = list(dict.fromkeys([*risk_tickers, *defensive_tickers]))
            update_start = request.settings.start_date
            update_req = DailyUpdateRequest(tickers=update_tickers, provider=request.settings.provider, start=update_start, end=request.settings.end_date, force=request.settings.force_update)

            def update_progress(idx: int, total: int, ticker: str, message: str) -> None:
                span = max(0.30 - 0.16, 0.01)
                local = min(max((float(idx) - 1.0) / max(float(total), 1.0), 0.0), 1.0)
                progress(0.16 + span * local, "OHLCV 다운로드/캐시 갱신", message)

            update_status = self.update_daily(update_req, cancel_event=cancel_event, progress_callback=update_progress)
            progress(0.30, "OHLCV 캐시 갱신 완료", f"updated={len(update_status.get('updated', []) or [])}, skipped={len(update_status.get('skipped', []) or [])}, errors={len(update_status.get('errors', {}) or {})}")
            if update_status.get("errors"):
                # Errors are tolerated only for tickers that still have a usable
                # cache; the explicit guard below enforces that intent.
                pass
        else:
            update_status = {"provider": request.settings.provider, "updated": [], "skipped": [], "errors": {}}
            progress(0.30, "OHLCV 캐시 재사용", "데이터 갱신 옵션이 꺼져 있어 기존 캐시를 사용합니다.")

        # Fail fast with a clear message when a risk-asset ticker has no usable
        # OHLCV (fetch failed AND no existing cache). Without this guard an
        # invalid symbol such as "SAMSUNG" passes the format check, produces no
        # cache file, and only surfaces much later as a model-subprocess
        # traceback ("Cached OHLCV not found"). Samsung Electronics is
        # "005930.KS" on Yahoo and "005930" on KIS.
        err_map = update_status.get("errors", {}) or {}
        unfetchable = [t for t in risk_tickers if not self.cache.has_ohlcv(t, request.settings.provider)]
        if unfetchable:
            details = "; ".join(f"{t}: {err_map.get(t, '데이터/캐시 없음')}" for t in unfetchable)
            raise ValueError(
                f"다음 위험자산 티커의 OHLCV 데이터를 준비하지 못했습니다 (provider={request.settings.provider}): "
                + ", ".join(unfetchable)
                + ". 티커 심볼이 올바른지 확인하세요. 예: 삼성전자는 Yahoo 기준 '005930.KS', "
                + "코스닥 종목은 '.KQ' 접미사가 필요하고, KIS provider는 '005930' 형식입니다. "
                + "상세: " + details
            )
        # Prediction generation policy for the XGB-only app.
        #
        # In v6.5+ the lightweight reference engine was removed. That means a
        # first run has no cached prediction CSV to read. Earlier versions still
        # allowed the UI/localStorage to send generate_predictions=false, then
        # evaluate() immediately tried to read storage/predictions/... and raised
        # a confusing 409 "Prediction file not found".
        #
        # Personal-app behavior should be safer:
        # - generate when the user requested generation,
        # - also auto-generate when any required prediction file is missing,
        # - if the external script fails, surface the actual generation error
        #   before trying to read the missing CSV.
        missing_before = [t for t in risk_tickers if not self.pred_repo.exists(t)]

        # Prediction freshness guard. The displayed model date comes from
        # storage/predictions, not directly from storage/market_cache. If the user
        # refreshes Yahoo/KIS OHLCV but reuses an older prediction CSV, the app can
        # look as if Yahoo data stopped a month ago. When cache_latest is newer
        # than prediction_latest, regenerate predictions automatically.
        stale_predictions = []
        for t in risk_tickers:
            try:
                cache_latest = self.cache.latest_date(t, request.settings.provider)
                pred_latest = self.pred_repo.latest_date(t)
                if cache_latest and pred_latest and pd.to_datetime(cache_latest) > pd.to_datetime(pred_latest):
                    stale_predictions.append({"ticker": t, "cache_latest": cache_latest, "prediction_latest": pred_latest})
            except Exception:
                pass

        freshness_msg_parts = []
        if missing_before:
            freshness_msg_parts.append("누락 예측: " + ", ".join(missing_before))
        if stale_predictions:
            freshness_msg_parts.append(
                "오래된 예측: " + ", ".join(
                    f"{x['ticker']} pred={x['prediction_latest']} < cache={x['cache_latest']}"
                    for x in stale_predictions
                )
            )
        progress(0.36, "예측 파일 확인", " / ".join(freshness_msg_parts) if freshness_msg_parts else "누락/오래된 예측 없음")
        should_generate = bool(request.settings.generate_predictions or missing_before or stale_predictions)
        force_prediction_for_stale = bool(request.settings.force_prediction or stale_predictions)
        if should_generate:
            if request.settings.prediction_run_mode == "latest":
                progress(0.42, "최신 예측 생성 준비", "최근 학습 윈도우만 사용해 최신일 예측을 생성합니다.")
            else:
                progress(0.42, "정밀 백테스트 생성 준비", "과거 전체 walk-forward 예측을 생성합니다. 오래 걸릴 수 있습니다.")
            gen_req = PredictionGenerateRequest(
                tickers=risk_tickers,
                start=request.settings.start_date,
                end=request.settings.end_date,
                provider=request.settings.provider,
                mode=request.settings.prediction_engine_mode,
                prediction_run_mode=request.settings.prediction_run_mode,
                latest_train_rows=request.settings.latest_train_rows,
                backtest_start_date=request.settings.backtest_start_date,
                force=force_prediction_for_stale,
                speed_profile=request.settings.speed_profile,
                transaction_cost_bps=request.settings.transaction_cost_bps,
            )
            gen_status = self.generate_predictions(gen_req, risk_sensitivity=request.settings.risk_sensitivity, provider=request.settings.provider, cancel_event=cancel_event, progress_callback=progress)
            progress(0.66, "모델 예측 생성 완료", f"results={len(gen_status.get('results', []) or [])}")
            result_errors = []
            for item in gen_status.get("results", []) or []:
                errs = item.get("errors") or []
                if errs:
                    result_errors.append(f"{item.get('ticker', '-')}: " + " | ".join(map(str, errs)))
            missing_after = [t for t in risk_tickers if not self.pred_repo.exists(t)]
            if result_errors or missing_after:
                detail_lines = []
                if missing_before:
                    detail_lines.append("missing_before=" + ",".join(missing_before))
                if missing_after:
                    detail_lines.append("missing_after=" + ",".join(missing_after))
                if result_errors:
                    detail_lines.append("generation_errors=" + " || ".join(result_errors))
                raise FileNotFoundError(
                    "Prediction generation did not produce all required files. "
                    + " ; ".join(detail_lines)
                    + ". Check Yahoo/KIS cache, ticker validity, Python dependencies, and the backend console log."
                )
        else:
            gen_status = {"ok": True, "results": [], "reused_cached_predictions": True}
            progress(0.64, "예측 캐시 재사용", "기존 prediction CSV를 사용합니다.")
        progress(0.70, "예측 로딩/신호 계산", "종목별 최신 확률과 국면 신호를 계산합니다.")
        frames: Dict[str, pd.DataFrame] = {}
        latest_predictions: Dict[str, Dict] = {}
        latest_signals: List[Dict] = []
        for t in risk_tickers:
            df = self.pred_repo.read(t)
            frames[t] = df
            latest = df.iloc[-1].to_dict()
            latest["Date"] = str(latest.get("Date"))
            cls = self.signals.classify(latest)
            latest.update(cls)
            latest_predictions[t] = latest
            latest_signals.append({k: latest.get(k) for k in [
                "ticker", "Date", "prob_normal", "prob_high_vol", "prob_overall_risk",
                "prob_up_strengthening_5d", "prob_up_strengthening_10d", "prob_up_strengthening_20d", "prob_up_strengthening_score",
                "prob_down_strengthening_5d", "prob_down_strengthening_10d", "prob_down_strengthening_20d", "prob_down_strengthening_score",
                "risk_class", "direction_class", "allocation_class", "stock_weight", "bond_weight", "cash_weight"
            ]})
        progress(0.78, "추천 비중 계산", "모델 확률을 현재 보유금액에 반영합니다.")
        risk_vols = self._risk_volatility_estimates(risk_tickers, provider=request.settings.provider) if request.settings.capital_mode == "inverse_vol" else None
        allocation = self.allocator.allocate(request, latest_predictions, risk_vols=risk_vols)
        perf_weights = {row["ticker"]: row["recommended_weight"] for row in allocation["allocation_rows"]}
        progress(0.84, "포트폴리오 성과 계산", "추천 비중 기준 수익률과 위험지표를 계산합니다.")
        perf_df = self.performance.portfolio_returns(frames, perf_weights, missing_asset_policy=request.settings.missing_asset_policy)
        recommended_bond_weight = float(allocation.get("portfolio_totals", {}).get("bond_weight", 0.0) or 0.0)
        recommended_cash_weight = float(allocation.get("portfolio_totals", {}).get("cash_weight", 0.0) or 0.0)
        perf_df, defensive_return_notes = self._attach_defensive_returns_to_performance(
            perf_df,
            provider=request.settings.provider,
            bond_weight=recommended_bond_weight,
            cash_weight=recommended_cash_weight,
        )
        recommended_returns = perf_df["portfolio_return"] if not perf_df.empty else pd.Series(dtype=float)
        metrics = self.performance.metrics(recommended_returns)
        buy_hold_metrics, buy_hold_df, buy_hold_notes = self._current_buy_and_hold_performance(
            request,
            prediction_frames=frames,
            provider=request.settings.provider,
        )
        # This is not a broad market benchmark. It compares the model-recommended
        # allocation with the user's input portfolio held as-is.
        progress(0.90, "검증 실행", "prediction, cache, allocation 결과를 점검합니다.")
        freshness = self.cache.freshness(risk_tickers, provider=request.settings.provider)
        checks = []
        checks.extend(self.validator.validate_predictions(frames, freshness))
        checks.extend(self.validator.validate_allocation(allocation))
        validation = self.validator.summarize(checks)
        all_return_notes = [*defensive_return_notes, *buy_hold_notes]
        if all_return_notes:
            validation.setdefault("ui_warnings", [])
            validation["ui_warnings"] = list(dict.fromkeys([*validation.get("ui_warnings", []), *all_return_notes]))
        payload = {
            "ok": validation["fail_count"] == 0,
            "request_id": request_id,
            "model_version": "v8.6.41_model_label_fixed_xgboost_script",
            "engine_mode": request.settings.prediction_engine_mode,
            "prediction_run_mode": request.settings.prediction_run_mode,
            "latest_train_rows": request.settings.latest_train_rows,
            "as_of_date": max((s.get("Date") for s in latest_signals if s.get("Date")), default=None),
            "portfolio_input": [a.model_dump() for a in request.portfolio],
            "latest_signals": latest_signals,
            "allocation": allocation,
            "performance": {
                "metrics": metrics,
                "equity_curve_tail": perf_df.tail(20).assign(Date=lambda x: x["Date"].astype(str)).to_dict(orient="records") if not perf_df.empty else [],
                "buy_and_hold_metrics": buy_hold_metrics,
                "buy_and_hold_equity_curve_tail": buy_hold_df.tail(20).assign(Date=lambda x: x["Date"].astype(str)).to_dict(orient="records") if not buy_hold_df.empty else [],
                "comparison_note": "buy_and_hold = 현재 입력 포트폴리오를 그대로 보유한 성과",
                "status": {
                    "recommended_rows": int(len(perf_df)) if perf_df is not None else 0,
                    "buy_and_hold_rows": int(len(buy_hold_df)) if buy_hold_df is not None else 0,
                    "has_recommended_metrics": bool(metrics),
                    "has_buy_and_hold_metrics": bool(buy_hold_metrics),
                },
            },
            "data_update_status": update_status,
            "prediction_generation_status": gen_status,
            "cache_freshness": freshness,
            "prediction_freshness": {
                "missing_before": missing_before,
                "stale_predictions": stale_predictions,
                "auto_regenerated_due_to_stale_cache": bool(stale_predictions),
            },
            "validation": validation,
        }
        progress(0.96, "결과 저장", "화면 표시용 payload와 최신 결과 JSON을 저장합니다.")
        payload = postprocess_dashboard_payload(payload, perf_df=perf_df)
        atomic_write_json(self.latest_dashboard_path, payload)
        self.logger.write("portfolio_evaluate_finished", request_id=request_id, ok=payload["ok"], fail_count=validation["fail_count"], warn_count=validation["warn_count"])
        return payload
