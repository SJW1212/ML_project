from __future__ import annotations

MODEL_VERSION = "v8_6_41"
TRADING_DAYS_PER_YEAR = 252
