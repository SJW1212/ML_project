from __future__ import annotations

from typing import Dict

from .utils import safe_float

HIGH_RISK_PROB_THRESHOLD = 0.65
WATCH_RISK_PROB_THRESHOLD = 0.50
WATCH_HIGH_VOL_THRESHOLD = 0.40
DIRECTION_STRENGTH_THRESHOLD = 0.55


class SignalClassifier:
    def classify(self, row: Dict) -> Dict:
        phv = safe_float(row.get("prob_high_vol"), 0.5)
        prisk = safe_float(row.get("prob_overall_risk"), 0.5)
        pup = safe_float(row.get("prob_up_strengthening_score"), 0.5)
        pdown = safe_float(row.get("prob_down_strengthening_score"), 0.5)
        if prisk >= HIGH_RISK_PROB_THRESHOLD or phv >= HIGH_RISK_PROB_THRESHOLD:
            risk_class = "HIGH_RISK"
        elif prisk >= WATCH_RISK_PROB_THRESHOLD or phv >= WATCH_HIGH_VOL_THRESHOLD or pdown >= WATCH_RISK_PROB_THRESHOLD:
            risk_class = "WATCH"
        else:
            risk_class = "NORMAL"
        if pdown >= DIRECTION_STRENGTH_THRESHOLD and pdown > pup:
            direction_class = "DOWN_STRENGTH"
        elif pup >= DIRECTION_STRENGTH_THRESHOLD and pup > pdown:
            direction_class = "UP_STRENGTH"
        else:
            direction_class = "NEUTRAL"
        if risk_class == "HIGH_RISK":
            allocation_class = "DEFENSIVE"
        elif direction_class == "UP_STRENGTH" and risk_class == "NORMAL":
            allocation_class = "PARTICIPATION"
        else:
            allocation_class = "BALANCED"
        return {"risk_class": risk_class, "direction_class": direction_class, "allocation_class": allocation_class}
