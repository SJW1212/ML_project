from __future__ import annotations

import json
import queue
import threading
import traceback
from pathlib import Path
from typing import Any, Dict, List, Tuple

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .schemas import EvaluateSettings, PortfolioAssetInput, PortfolioEvaluateRequest
from .service import PortfolioRegimeAdvisorService
from .utils import atomic_write_json, normalize_ticker


ASSET_TYPES = ["stock", "etf", "risk_asset", "bond_bucket", "cash"]
PROVIDERS = ["auto", "yahoo", "kis", "hybrid"]
RISK_PROFILES = ["conservative", "balanced", "aggressive"]
SPEED_PROFILES = ["fast", "balanced", "full"]


EXAMPLE_ROWS = [
    ("AAPL", "Apple", "stock", "2500000"),
    ("QQQ", "Nasdaq 100 ETF", "etf", "2500000"),
    ("NVDA", "NVIDIA", "stock", "2000000"),
    ("LLY", "Eli Lilly", "stock", "1500000"),
    ("BOND_BUCKET", "채권", "bond_bucket", "1000000"),
    ("CASH", "현금", "cash", "500000"),
]


class PortfolioRow:
    def __init__(self, parent: tk.Widget, remove_callback):
        self.frame = ttk.Frame(parent)
        self.ticker = tk.StringVar()
        self.name = tk.StringVar()
        self.asset_type = tk.StringVar(value="stock")
        self.amount = tk.StringVar()
        self.weight_text = tk.StringVar(value="0.00%")
        self.remove_callback = remove_callback

        self.ticker_entry = ttk.Entry(self.frame, textvariable=self.ticker, width=12)
        self.name_entry = ttk.Entry(self.frame, textvariable=self.name, width=18)
        self.type_combo = ttk.Combobox(self.frame, textvariable=self.asset_type, values=ASSET_TYPES, width=12, state="readonly")
        self.amount_entry = ttk.Entry(self.frame, textvariable=self.amount, width=16)
        self.weight_label = ttk.Label(self.frame, textvariable=self.weight_text, width=10, anchor="e")
        self.delete_btn = ttk.Button(self.frame, text="삭제", command=self.remove)

        self.ticker_entry.grid(row=0, column=0, padx=3, pady=3, sticky="ew")
        self.name_entry.grid(row=0, column=1, padx=3, pady=3, sticky="ew")
        self.type_combo.grid(row=0, column=2, padx=3, pady=3, sticky="ew")
        self.amount_entry.grid(row=0, column=3, padx=3, pady=3, sticky="ew")
        self.weight_label.grid(row=0, column=4, padx=3, pady=3, sticky="ew")
        self.delete_btn.grid(row=0, column=5, padx=3, pady=3)

        for var in [self.ticker, self.name, self.asset_type, self.amount]:
            var.trace_add("write", lambda *_: self.remove_callback(recalc_only=True))

    def set_values(self, ticker: str, name: str, asset_type: str, amount: str) -> None:
        self.ticker.set(ticker)
        self.name.set(name)
        self.asset_type.set(asset_type)
        self.amount.set(amount)

    def remove(self) -> None:
        self.frame.destroy()
        self.remove_callback(row=self)

    def amount_value(self) -> float:
        raw = (self.amount.get() or "0").replace(",", "").strip()
        if not raw:
            return 0.0
        return float(raw)

    def to_asset(self) -> PortfolioAssetInput:
        ticker = normalize_ticker(self.ticker.get().strip())
        if not ticker:
            raise ValueError("티커가 비어 있는 자산이 있습니다.")
        amount = self.amount_value()
        if amount < 0:
            raise ValueError(f"{ticker}: 금액은 0 이상이어야 합니다.")
        return PortfolioAssetInput(
            ticker=ticker,
            name=(self.name.get().strip() or None),
            asset_type=self.asset_type.get(),
            current_value=amount,
            enabled=True,
        )


class DesktopApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Portfolio Regime Advisor v6.8 - Desktop Core Pipeline")
        self.geometry("1280x820")
        self.minsize(1080, 720)
        self.rows: List[PortfolioRow] = []
        self.worker_queue: queue.Queue[Tuple[str, Any]] = queue.Queue()
        self.latest_payload: Dict[str, Any] | None = None
        self._build_ui()
        self.after(200, self._poll_worker_queue)

    def _build_ui(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root)
        header.pack(fill="x")
        ttk.Label(header, text="Portfolio Regime Advisor", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Label(header, text="Python Desktop · Core Pipeline Only", foreground="#666").pack(side="left", padx=12)

        main = ttk.PanedWindow(root, orient="horizontal")
        main.pack(fill="both", expand=True, pady=(12, 0))

        left = ttk.Frame(main, padding=8)
        right = ttk.Frame(main, padding=8)
        main.add(left, weight=3)
        main.add(right, weight=2)

        # Portfolio input
        portfolio_box = ttk.LabelFrame(left, text="1. 포트폴리오 입력: 보유 금액 기준")
        portfolio_box.pack(fill="both", expand=False)

        header_row = ttk.Frame(portfolio_box)
        header_row.pack(fill="x", padx=6, pady=(8, 2))
        for idx, (text, width) in enumerate([("Ticker", 12), ("Name", 18), ("Type", 12), ("Amount", 16), ("Weight", 10), ("", 6)]):
            ttk.Label(header_row, text=text, width=width, anchor="center").grid(row=0, column=idx, padx=3, sticky="ew")

        self.rows_frame = ttk.Frame(portfolio_box)
        self.rows_frame.pack(fill="x", padx=6, pady=2)

        buttons = ttk.Frame(portfolio_box)
        buttons.pack(fill="x", padx=6, pady=8)
        ttk.Button(buttons, text="자산 추가", command=self.add_row).pack(side="left")
        ttk.Button(buttons, text="예시 로드", command=self.load_example).pack(side="left", padx=6)
        ttk.Button(buttons, text="전체 비우기", command=self.clear_rows).pack(side="left")
        self.total_text = tk.StringVar(value="총 평가금액: 0 / 주식 0.00% · 채권 0.00% · 현금 0.00%")
        ttk.Label(buttons, textvariable=self.total_text).pack(side="right")

        # Settings
        settings_box = ttk.LabelFrame(left, text="2. 실행 설정")
        settings_box.pack(fill="x", pady=(10, 0))
        self.provider = tk.StringVar(value="yahoo")
        self.risk_profile = tk.StringVar(value="balanced")
        self.speed_profile = tk.StringVar(value="balanced")
        self.force_update = tk.BooleanVar(value=False)
        self.force_prediction = tk.BooleanVar(value=False)
        self.transaction_cost_bps = tk.StringVar(value="10")
        self.risk_sensitivity = tk.StringVar(value="1.0")

        row1 = ttk.Frame(settings_box)
        row1.pack(fill="x", padx=8, pady=6)
        ttk.Label(row1, text="Provider").pack(side="left")
        ttk.Combobox(row1, textvariable=self.provider, values=PROVIDERS, width=10, state="readonly").pack(side="left", padx=6)
        ttk.Label(row1, text="Risk").pack(side="left", padx=(12, 0))
        ttk.Combobox(row1, textvariable=self.risk_profile, values=RISK_PROFILES, width=13, state="readonly").pack(side="left", padx=6)
        ttk.Label(row1, text="Speed").pack(side="left", padx=(12, 0))
        ttk.Combobox(row1, textvariable=self.speed_profile, values=SPEED_PROFILES, width=10, state="readonly").pack(side="left", padx=6)
        ttk.Checkbutton(row1, text="데이터 강제 갱신", variable=self.force_update).pack(side="left", padx=12)
        ttk.Checkbutton(row1, text="예측 강제 재생성", variable=self.force_prediction).pack(side="left")

        row2 = ttk.Frame(settings_box)
        row2.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Label(row2, text="거래비용 bps").pack(side="left")
        ttk.Entry(row2, textvariable=self.transaction_cost_bps, width=8).pack(side="left", padx=6)
        ttk.Label(row2, text="위험 민감도").pack(side="left", padx=(12, 0))
        ttk.Entry(row2, textvariable=self.risk_sensitivity, width=8).pack(side="left", padx=6)
        ttk.Label(row2, text="분석 기간은 내부 고정: 1999-03-10 ~ 최신", foreground="#666").pack(side="left", padx=16)

        run_box = ttk.Frame(left)
        run_box.pack(fill="x", pady=10)
        self.run_btn = ttk.Button(run_box, text="핵심 파이프라인 실행", command=self.run_pipeline)
        self.run_btn.pack(side="left")
        ttk.Button(run_box, text="결과 JSON 저장", command=self.save_payload_as).pack(side="left", padx=6)
        self.status_text = tk.StringVar(value="대기 중")
        ttk.Label(run_box, textvariable=self.status_text).pack(side="left", padx=12)

        # Log
        log_box = ttk.LabelFrame(left, text="실행 로그")
        log_box.pack(fill="both", expand=True)
        self.log = tk.Text(log_box, height=14, wrap="word")
        self.log.pack(fill="both", expand=True, padx=6, pady=6)

        # Results
        summary_box = ttk.LabelFrame(right, text="결과 요약")
        summary_box.pack(fill="x")
        self.summary_text = tk.StringVar(value="아직 분석 결과가 없습니다.")
        ttk.Label(summary_box, textvariable=self.summary_text, justify="left", wraplength=460).pack(fill="x", padx=8, pady=8)

        alloc_box = ttk.LabelFrame(right, text="추천 배분")
        alloc_box.pack(fill="both", expand=True, pady=(10, 0))
        self.alloc_tree = ttk.Treeview(alloc_box, columns=("ticker", "current", "recommended", "action"), show="headings", height=8)
        for col, text, width in [("ticker", "Ticker", 90), ("current", "현재", 90), ("recommended", "추천", 90), ("action", "Action", 120)]:
            self.alloc_tree.heading(col, text=text)
            self.alloc_tree.column(col, width=width, anchor="center")
        self.alloc_tree.pack(fill="both", expand=True, padx=6, pady=6)

        signal_box = ttk.LabelFrame(right, text="모델 확률")
        signal_box.pack(fill="both", expand=True, pady=(10, 0))
        self.signal_tree = ttk.Treeview(signal_box, columns=("ticker", "normal", "highvol", "risk", "up", "down"), show="headings", height=8)
        for col, text, width in [
            ("ticker", "Ticker", 80),
            ("normal", "Normal", 75),
            ("highvol", "HighVol", 75),
            ("risk", "Risk", 75),
            ("up", "Up", 75),
            ("down", "Down", 75),
        ]:
            self.signal_tree.heading(col, text=text)
            self.signal_tree.column(col, width=width, anchor="center")
        self.signal_tree.pack(fill="both", expand=True, padx=6, pady=6)

        self.add_row()

    def log_line(self, msg: str) -> None:
        self.log.insert("end", msg.rstrip() + "\n")
        self.log.see("end")
        self.update_idletasks()

    def add_row(self) -> PortfolioRow:
        row = PortfolioRow(self.rows_frame, self._row_changed)
        row.frame.pack(fill="x")
        self.rows.append(row)
        self.recalculate_weights()
        return row

    def _row_changed(self, row=None, recalc_only=False) -> None:
        if row is not None and row in self.rows:
            self.rows.remove(row)
        self.recalculate_weights()

    def clear_rows(self) -> None:
        for row in list(self.rows):
            row.frame.destroy()
        self.rows.clear()
        self.latest_payload = None
        self.clear_results()
        self.recalculate_weights()
        self.log_line("입력 포트폴리오를 비웠습니다.")

    def load_example(self) -> None:
        self.clear_rows()
        for values in EXAMPLE_ROWS:
            row = self.add_row()
            row.set_values(*values)
        self.recalculate_weights()
        self.log_line("예시 포트폴리오를 로드했습니다.")

    def recalculate_weights(self) -> None:
        total = 0.0
        amounts = []
        for row in self.rows:
            try:
                amount = row.amount_value()
            except Exception:
                amount = 0.0
            amounts.append(amount)
            total += amount
        stock = bond = cash = 0.0
        for row, amount in zip(self.rows, amounts):
            w = amount / total if total > 0 else 0.0
            row.weight_text.set(f"{w * 100:.2f}%")
            at = row.asset_type.get()
            ticker = normalize_ticker(row.ticker.get())
            if at in {"cash", "cash_bucket"} or ticker in {"CASH", "CASH_BUCKET"}:
                cash += w
            elif at in {"bond_bucket", "bond", "bond_etf"} or ticker == "BOND_BUCKET":
                bond += w
            else:
                stock += w
        self.total_text.set(f"총 평가금액: {total:,.0f} / 주식 {stock*100:.2f}% · 채권 {bond*100:.2f}% · 현금 {cash*100:.2f}%")

    def build_request(self) -> PortfolioEvaluateRequest:
        assets = [row.to_asset() for row in self.rows]
        assets = [a for a in assets if float(a.current_value or 0.0) > 0]
        if not assets:
            raise ValueError("금액이 0보다 큰 자산을 1개 이상 입력해야 합니다.")
        if not any(a.is_risk_asset for a in assets):
            raise ValueError("모델 실행 대상인 주식/ETF/risk_asset 자산이 최소 1개 필요합니다.")
        settings = EvaluateSettings(
            start_date="1999-03-10",
            update_data=True,
            generate_predictions=True,
            force_update=bool(self.force_update.get()),
            force_prediction=bool(self.force_prediction.get()),
            provider=self.provider.get(),
            prediction_engine_mode="external_v8641_xgb",
            speed_profile=self.speed_profile.get(),
            transaction_cost_bps=float(self.transaction_cost_bps.get() or 10.0),
            risk_sensitivity=float(self.risk_sensitivity.get() or 1.0),
        )
        return PortfolioEvaluateRequest(
            portfolio=assets,
            risk_profile=self.risk_profile.get(),
            user_level="general",
            settings=settings,
        )

    def run_pipeline(self) -> None:
        try:
            req = self.build_request()
        except Exception as exc:
            messagebox.showerror("입력 오류", str(exc))
            return
        self.run_btn.configure(state="disabled")
        self.status_text.set("실행 중")
        self.log_line("=" * 80)
        self.log_line("핵심 파이프라인 실행 시작")
        self.log_line(f"provider={req.settings.provider}, engine={req.settings.prediction_engine_mode}, risk={req.risk_profile}")
        self.log_line("단계: 포트폴리오 입력 → OHLCV 다운로드/정제 → XGBoost 실행 → 추천 비중 출력")
        threading.Thread(target=self._worker_run, args=(req,), daemon=True).start()

    def _worker_run(self, req: PortfolioEvaluateRequest) -> None:
        try:
            service = PortfolioRegimeAdvisorService()
            payload = service.evaluate(req)
            # Explicit desktop copy for easier inspection.
            atomic_write_json(Path("storage/latest_desktop_result.json"), payload)
            self.worker_queue.put(("success", payload))
        except Exception as exc:
            self.worker_queue.put(("error", {"message": str(exc), "traceback": traceback.format_exc()}))

    def _poll_worker_queue(self) -> None:
        try:
            while True:
                kind, data = self.worker_queue.get_nowait()
                if kind == "success":
                    self.latest_payload = data
                    self.render_payload(data)
                    self.log_line("핵심 파이프라인 실행 완료")
                    self.log_line("결과 저장: storage/latest_dashboard_payload.json")
                    self.log_line("결과 저장: storage/latest_desktop_result.json")
                    self.status_text.set("완료")
                    self.run_btn.configure(state="normal")
                else:
                    self.log_line("실행 실패")
                    self.log_line(data.get("message", ""))
                    self.log_line(data.get("traceback", ""))
                    self.status_text.set("실패")
                    self.run_btn.configure(state="normal")
                    messagebox.showerror("실행 실패", data.get("message", "알 수 없는 오류"))
        except queue.Empty:
            pass
        self.after(200, self._poll_worker_queue)

    def clear_results(self) -> None:
        self.summary_text.set("아직 분석 결과가 없습니다.")
        for tree in [self.alloc_tree, self.signal_tree]:
            for item in tree.get_children():
                tree.delete(item)

    @staticmethod
    def pct(v: Any) -> str:
        try:
            return f"{float(v) * 100:.2f}%"
        except Exception:
            return "-"

    def render_payload(self, payload: Dict[str, Any]) -> None:
        self.clear_results()
        totals = payload.get("allocation", {}).get("portfolio_totals", {}) or {}
        metrics = payload.get("performance", {}).get("metrics", {}) or {}
        validation = payload.get("validation", {}) or {}
        self.summary_text.set(
            "\n".join([
                f"상태: {'정상' if payload.get('ok') else '주의/실패'}",
                f"기준일: {payload.get('as_of_date') or '-'}",
                f"추천 주식: {self.pct(totals.get('stock_weight'))} / 채권: {self.pct(totals.get('bond_weight'))} / 현금: {self.pct(totals.get('cash_weight'))}",
                f"CAGR: {self.pct(metrics.get('cagr'))} / MDD: {self.pct(metrics.get('mdd'))} / Sharpe: {metrics.get('sharpe', '-')}",
                f"검증: fail={validation.get('fail_count', '-')} warn={validation.get('warn_count', '-')}",
            ])
        )
        for row in payload.get("allocation", {}).get("allocation_rows", []) or []:
            self.alloc_tree.insert("", "end", values=(
                row.get("ticker", "-"),
                self.pct(row.get("current_weight")),
                self.pct(row.get("recommended_weight")),
                row.get("action", "-"),
            ))
        for sig in payload.get("latest_signals", []) or []:
            self.signal_tree.insert("", "end", values=(
                sig.get("ticker", "-"),
                self.pct(sig.get("prob_normal")),
                self.pct(sig.get("prob_high_vol")),
                self.pct(sig.get("prob_overall_risk")),
                self.pct(sig.get("prob_up_strengthening_score")),
                self.pct(sig.get("prob_down_strengthening_score")),
            ))

    def save_payload_as(self) -> None:
        if not self.latest_payload:
            messagebox.showinfo("저장", "저장할 분석 결과가 없습니다.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="portfolio_regime_result.json",
        )
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.latest_payload, f, ensure_ascii=False, indent=2, default=str)
        messagebox.showinfo("저장", f"저장 완료:\n{path}")


def main() -> None:
    app = DesktopApp()
    app.mainloop()


if __name__ == "__main__":
    main()
