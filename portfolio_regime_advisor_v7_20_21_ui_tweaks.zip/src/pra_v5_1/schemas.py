from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from .utils import normalize_ticker


UserLevel = Literal["general", "advanced", "expert", "developer"]
RiskProfile = Literal["conservative", "balanced", "aggressive"]
AssetType = Literal["stock", "etf", "risk_asset", "bond", "bond_etf", "bond_bucket", "cash", "cash_bucket"]
CapitalMode = Literal["current_weight", "equal", "custom", "inverse_vol"]
MissingAssetPolicy = Literal["cash_fallback", "active_weight_renormalize", "common_range_only"]
PredictionEngineMode = Literal["external_v8641_xgb"]
PredictionRunMode = Literal["latest", "walk_forward"]


class PortfolioAssetInput(BaseModel):
    name: Optional[str] = None
    ticker: str
    asset_type: AssetType = "stock"
    current_weight: Optional[float] = Field(default=None, ge=0.0)
    current_value: Optional[float] = Field(default=None, ge=0.0)
    enabled: bool = True

    @field_validator("ticker")
    @classmethod
    def _ticker(cls, v: str) -> str:
        return normalize_ticker(v)

    @property
    def is_cash_bucket(self) -> bool:
        return self.asset_type in {"cash", "cash_bucket"} or self.ticker in {"CASH", "CASH_BUCKET"}

    @property
    def is_bond_bucket(self) -> bool:
        return self.asset_type == "bond_bucket" or self.ticker == "BOND_BUCKET"

    @property
    def is_risk_asset(self) -> bool:
        return self.enabled and not self.is_cash_bucket and not self.is_bond_bucket and self.asset_type in {"stock", "etf", "risk_asset"}

    @property
    def is_defensive_etf(self) -> bool:
        return self.enabled and self.asset_type in {"bond", "bond_etf"} and not self.is_bond_bucket


class EvaluateSettings(BaseModel):
    start_date: str = "2013-01-01"
    end_date: Optional[str] = None
    backtest_start_date: Optional[str] = None
    holdout_start: str = "2024-01-01"
    update_data: bool = True
    generate_predictions: bool = True
    force_update: bool = False
    force_prediction: bool = False
    provider: Literal["auto", "yahoo", "kis", "hybrid"] = "auto"
    prediction_engine_mode: PredictionEngineMode = "external_v8641_xgb"
    prediction_run_mode: PredictionRunMode = "latest"
    latest_train_rows: int = Field(default=756, ge=504, le=2520)
    capital_mode: CapitalMode = "current_weight"
    custom_weights: Dict[str, float] = Field(default_factory=dict)
    missing_asset_policy: MissingAssetPolicy = "cash_fallback"
    transaction_cost_bps: float = Field(default=10.0, ge=0.0, le=200.0)
    min_cash_weight: float = Field(default=0.0, ge=0.0, le=1.0)
    max_asset_weight: float = Field(default=1.0, gt=0.0, le=1.0)
    risk_sensitivity: float = Field(default=1.0, ge=0.1, le=3.0)
    speed_profile: Literal["fast", "balanced", "full"] = "balanced"

    @field_validator("custom_weights")
    @classmethod
    def _normalize_custom_keys(cls, v: Dict[str, float]) -> Dict[str, float]:
        return {normalize_ticker(k): float(val) for k, val in (v or {}).items()}


class PortfolioEvaluateRequest(BaseModel):
    portfolio: List[PortfolioAssetInput]
    risk_profile: RiskProfile = "balanced"
    user_level: UserLevel = "general"
    settings: EvaluateSettings = Field(default_factory=EvaluateSettings)

    @model_validator(mode="after")
    def _has_assets_and_normalize_amounts(self):
        if not self.portfolio:
            raise ValueError("portfolio must not be empty")

        # Personal/local UI mode: users may enter holding amounts instead of weights.
        # When current_value is provided, treat it as the source of truth and
        # derive current_weight from total enabled portfolio value. This keeps
        # the downstream allocation/performance code unchanged because it still
        # consumes normalized current_weight.
        total_value = sum(
            float(a.current_value or 0.0)
            for a in self.portfolio
            if a.enabled and a.current_value is not None
        )
        if total_value > 0:
            for asset in self.portfolio:
                if asset.enabled:
                    asset.current_weight = float(asset.current_value or 0.0) / total_value
                else:
                    asset.current_weight = 0.0
        return self


class TickerAddRequest(BaseModel):
    tickers: List[str]
    asset_type: AssetType = "stock"
    market: str = "US"
    note: Optional[str] = None

    @field_validator("tickers")
    @classmethod
    def _tickers(cls, v: List[str]) -> List[str]:
        return [normalize_ticker(x) for x in v]


class DailyUpdateRequest(BaseModel):
    tickers: List[str] = Field(default_factory=list)
    provider: Literal["auto", "yahoo", "kis", "hybrid"] = "auto"
    start: str = "2013-01-01"
    end: Optional[str] = None
    force: bool = False

    @field_validator("tickers")
    @classmethod
    def _tickers(cls, v: List[str]) -> List[str]:
        return [normalize_ticker(x) for x in v]


class PredictionGenerateRequest(BaseModel):
    tickers: List[str] = Field(default_factory=list)
    start: str = "2013-01-01"
    end: Optional[str] = None
    provider: Literal["auto", "yahoo", "kis", "hybrid"] = "auto"
    mode: PredictionEngineMode = "external_v8641_xgb"
    prediction_run_mode: PredictionRunMode = "latest"
    latest_train_rows: int = Field(default=756, ge=504, le=2520)
    backtest_start_date: Optional[str] = None
    force: bool = False
    speed_profile: Literal["fast", "balanced", "full"] = "balanced"
    transaction_cost_bps: float = Field(default=10.0, ge=0.0, le=200.0)

    @field_validator("tickers")
    @classmethod
    def _tickers(cls, v: List[str]) -> List[str]:
        return [normalize_ticker(x) for x in v]


class KisSettingsSaveRequest(BaseModel):
    app_key: str = Field(..., min_length=1)
    app_secret: str = Field(..., min_length=1)
    base_url: str = "https://openapi.koreainvestment.com:9443"
    virtual_trade: bool = False
    account_no: Optional[str] = None
    account_product_code: str = "01"
    overseas_exchange: str = "NAS"
    custtype: str = "P"
    access_token: Optional[str] = None
    persist_secret: bool = True


class BootstrapSampleDataRequest(BaseModel):
    tickers: List[str] = Field(default_factory=lambda: ["AAPL", "QQQ", "NVDA", "LLY", "IEF", "BIL"])
    providers: List[Literal["auto", "yahoo", "hybrid", "kis"]] = Field(default_factory=lambda: ["auto", "yahoo", "hybrid"])
    start: str = "2013-01-01"
    end: Optional[str] = None
    periods: Optional[int] = Field(default=None, ge=260)
    overwrite: bool = False

    @field_validator("tickers")
    @classmethod
    def _bootstrap_tickers(cls, v: List[str]) -> List[str]:
        return [normalize_ticker(x) for x in v]


class RunLatestRequest(BaseModel):
    provider: Optional[Literal["auto", "yahoo", "kis", "hybrid"]] = None
    prediction_engine_mode: Optional[PredictionEngineMode] = None
    prediction_run_mode: Optional[PredictionRunMode] = None
    latest_train_rows: Optional[int] = None
    update_data: Optional[bool] = None
    generate_predictions: Optional[bool] = None
    force_update: Optional[bool] = None
    force_prediction: Optional[bool] = None
    speed_profile: Optional[Literal["fast", "balanced", "full"]] = None
