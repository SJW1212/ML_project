from __future__ import annotations

import os
import logging
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
import requests

from .utils import atomic_write_json, ensure_dir, load_json, normalize_ticker


KIS_REAL_BASE_URL = "https://openapi.koreainvestment.com:9443"
KIS_VIRTUAL_BASE_URL = "https://openapivts.koreainvestment.com:29443"
KIS_TOKEN_PATH = "/oauth2/tokenP"


@dataclass
class KisSettings:
    app_key: str = ""
    app_secret: str = ""
    base_url: str = KIS_REAL_BASE_URL
    virtual_trade: bool = False
    account_no: str = ""
    account_product_code: str = "01"
    overseas_exchange: str = "NAS"
    custtype: str = "P"
    access_token: str = ""

    def redacted(self) -> Dict[str, Any]:
        data = asdict(self)
        for key in ["app_key", "app_secret", "access_token"]:
            val = str(data.get(key) or "")
            data[key] = "" if not val else f"{val[:4]}...{val[-4:]}"
        data["configured"] = bool(self.app_key and self.app_secret)
        return data


class KisCredentialStore:
    """Local-only KIS settings loader.

    Priority: environment variables > storage/config/kis_config.json > defaults.
    This package intentionally implements quotation/daily data only. It does not
    implement order placement, balance inquiry, or automated trading methods.
    """

    def __init__(self, config_dir: Path):
        self.config_dir = config_dir
        self.config_path = config_dir / "kis_config.json"
        self.token_path = config_dir / "kis_token.json"

    def load(self) -> KisSettings:
        data = load_json(self.config_path, default={}) or {}
        env = os.environ
        virtual = str(env.get("KIS_VIRTUAL_TRADE", data.get("virtual_trade", "false"))).lower() in {"1", "true", "yes", "y"}
        base_url = env.get("KIS_BASE_URL") or data.get("base_url") or (KIS_VIRTUAL_BASE_URL if virtual else KIS_REAL_BASE_URL)
        settings = KisSettings(
            app_key=env.get("KIS_APP_KEY") or data.get("app_key", ""),
            app_secret=env.get("KIS_APP_SECRET") or data.get("app_secret", ""),
            base_url=str(base_url).rstrip("/"),
            virtual_trade=virtual,
            account_no=env.get("KIS_ACCOUNT_NO") or data.get("account_no", ""),
            account_product_code=env.get("KIS_ACCOUNT_PRODUCT_CODE") or data.get("account_product_code", "01"),
            overseas_exchange=env.get("KIS_OVERSEAS_EXCHANGE") or data.get("overseas_exchange", "NAS"),
            custtype=env.get("KIS_CUSTTYPE") or data.get("custtype", "P"),
            access_token=env.get("KIS_ACCESS_TOKEN") or data.get("access_token", ""),
        )
        return settings

    def save(self, settings: KisSettings, persist_secret: bool = True) -> Path:
        ensure_dir(self.config_dir)
        data = asdict(settings)
        if not persist_secret:
            data["app_secret"] = ""
            data["access_token"] = ""
        atomic_write_json(self.config_path, data)
        return self.config_path

    def read_cached_token(self) -> Optional[str]:
        payload = load_json(self.token_path, default={}) or {}
        token = payload.get("access_token")
        expires_at = payload.get("expires_at")
        if not token:
            return None
        if expires_at:
            try:
                if datetime.fromisoformat(expires_at) <= datetime.now(timezone.utc) + timedelta(minutes=5):
                    return None
            except Exception:
                return None
        return str(token)

    def write_cached_token(self, access_token: str, expires_in: Optional[int] = None) -> None:
        ensure_dir(self.config_dir)
        expires = datetime.now(timezone.utc) + timedelta(seconds=int(expires_in or 23 * 3600))
        atomic_write_json(self.token_path, {"access_token": access_token, "expires_at": expires.isoformat()})


class KisQuoteProvider:
    """Korea Investment Open API quotation/daily OHLCV provider.

    Implemented scope:
    - OAuth token issuance/cache
    - Domestic daily item chart price lookup
    - Overseas daily price lookup, mainly US tickers
    - Standard OHLCV DataFrame conversion

    Not implemented by design:
    - Order placement/cancel/modify
    - Balance/account trading functions
    - Realtime websocket streaming
    """

    def __init__(self, store: KisCredentialStore, timeout: int = 20):
        self.store = store
        self.timeout = timeout

    @staticmethod
    def _date_yyyymmdd(value: Optional[str]) -> str:
        if not value:
            return datetime.now().strftime("%Y%m%d")
        return pd.to_datetime(value).strftime("%Y%m%d")

    @staticmethod
    def _is_domestic_ticker(ticker: str) -> bool:
        value = str(ticker).strip()
        return value.isdigit() and len(value) == 6

    @staticmethod
    def _num(value: Any) -> Optional[float]:
        if value is None:
            return None
        try:
            return float(str(value).replace(",", "").strip())
        except Exception:
            return None

    @staticmethod
    def _first(row: Dict[str, Any], names: Iterable[str], default: Any = None) -> Any:
        for name in names:
            if name in row and row.get(name) not in {None, ""}:
                return row.get(name)
        return default

    def status(self) -> Dict[str, Any]:
        st = self.store.load()
        cached = self.store.read_cached_token()
        out = st.redacted()
        out["token_cached"] = bool(cached)
        out["config_access_token_present"] = bool(st.access_token)
        out["config_path"] = str(self.store.config_path)
        out["token_cache_path"] = str(self.store.token_path)
        out["scope"] = "quotation_daily_ohlcv_only"
        out["order_execution"] = False
        return out

    def get_access_token(self, force_refresh: bool = False) -> str:
        st = self.store.load()
        if not st.app_key or not st.app_secret:
            raise RuntimeError("KIS credentials are missing. Set KIS_APP_KEY/KIS_APP_SECRET or save them through /settings/kis/save.")

        # Manual environment token is an explicit override. A token persisted in
        # kis_config.json is intentionally not trusted because it can be stale
        # while still non-empty. The token cache has expiry metadata and is safer.
        env_token = os.environ.get("KIS_ACCESS_TOKEN")
        if env_token and not force_refresh:
            return str(env_token)

        cached = None if force_refresh else self.store.read_cached_token()
        if cached:
            return cached

        url = f"{st.base_url}{KIS_TOKEN_PATH}"
        body = {"grant_type": "client_credentials", "appkey": st.app_key, "appsecret": st.app_secret}
        try:
            res = requests.post(url, json=body, timeout=self.timeout)
        except requests.Timeout as exc:
            raise RuntimeError(f"KIS token request timed out after {self.timeout}s. Check network/API portal status.") from exc
        except requests.RequestException as exc:
            raise RuntimeError(f"KIS token request network error: {type(exc).__name__}: {exc}") from exc

        if res.status_code >= 400:
            msg = f"KIS token request failed with HTTP {res.status_code}"
            if res.status_code == 401:
                msg += ". Likely invalid app_key/app_secret or app approval state."
            elif res.status_code == 429:
                msg += ". Rate limit exceeded; retry later."
            else:
                msg += f". Response: {res.text[:200]}"
            raise RuntimeError(msg)
        try:
            data = res.json()
        except Exception as exc:
            raise RuntimeError(f"KIS token response is not valid JSON: {exc}") from exc
        token = data.get("access_token")
        if not token:
            raise RuntimeError("KIS token response missing access_token field. Check KIS endpoint/API policy.")
        self.store.write_cached_token(str(token), data.get("expires_in"))
        return str(token)

    def _headers(self, tr_id: str, force_refresh_token: bool = False) -> Dict[str, str]:
        st = self.store.load()
        token = self.get_access_token(force_refresh=force_refresh_token)
        return {
            "content-type": "application/json; charset=utf-8",
            "authorization": f"Bearer {token}",
            "appKey": st.app_key,
            "appSecret": st.app_secret,
            "tr_id": tr_id,
            "custtype": st.custtype or "P",
        }

    def _get(self, path: str, tr_id: str, params: Dict[str, Any]) -> Dict[str, Any]:
        st = self.store.load()
        url = f"{st.base_url.rstrip('/')}/{path.lstrip('/')}"
        res = requests.get(url, headers=self._headers(tr_id), params=params, timeout=self.timeout)
        # Token can expire or be revoked between freshness checks. Retry once
        # with a forced token refresh on HTTP 401 before failing the request.
        if res.status_code == 401:
            res = requests.get(url, headers=self._headers(tr_id, force_refresh_token=True), params=params, timeout=self.timeout)
        if res.status_code >= 400:
            raise RuntimeError(f"KIS GET failed: {path} HTTP {res.status_code} {res.text[:500]}")
        try:
            data = res.json()
        except Exception as exc:
            raise RuntimeError(f"KIS GET response is not valid JSON for {path}: {exc}") from exc
        rt_cd = str(data.get("rt_cd", "0"))
        if rt_cd not in {"0", "None", ""}:
            raise RuntimeError(f"KIS API error {data.get('msg_cd')}: {data.get('msg1') or data}")
        return data

    def download_ohlcv(self, ticker: str, start: str = "2013-01-01", end: Optional[str] = None, market: str = "auto") -> pd.DataFrame:
        t = normalize_ticker(ticker)
        if market == "domestic" or (market == "auto" and self._is_domestic_ticker(t)):
            return self.download_domestic_daily(t, start=start, end=end)
        return self.download_overseas_daily(t, start=start, end=end)

    def download_domestic_daily(self, ticker: str, start: str = "2013-01-01", end: Optional[str] = None) -> pd.DataFrame:
        # domestic item chart API: maximum rows can be limited by KIS account/API policy.
        params = {
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_INPUT_ISCD": ticker,
            "FID_INPUT_DATE_1": self._date_yyyymmdd(start),
            "FID_INPUT_DATE_2": self._date_yyyymmdd(end),
            "FID_PERIOD_DIV_CODE": "D",
            "FID_ORG_ADJ_PRC": "0",
        }
        data = self._get("/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice", "FHKST03010100", params)
        rows = data.get("output2") or data.get("output") or []
        return self._rows_to_ohlcv(rows, ticker=ticker)

    def download_overseas_daily(self, ticker: str, start: str = "2013-01-01", end: Optional[str] = None) -> pd.DataFrame:
        st = self.store.load()
        params = {
            "AUTH": "",
            "EXCD": st.overseas_exchange or "NAS",
            "SYMB": ticker,
            "GUBN": "0",       # 0: daily, 1: weekly, 2: monthly in common samples
            "BYMD": self._date_yyyymmdd(end),
            "MODP": "0",       # 0: adjusted/no-adjust policy follows KIS API response
        }
        data = self._get("/uapi/overseas-price/v1/quotations/dailyprice", "HHDFS76240000", params)
        rows = data.get("output2") or data.get("output") or []
        df = self._rows_to_ohlcv(rows, ticker=ticker)
        if not df.empty:
            start_date = pd.to_datetime(start).date()
            df = df[pd.to_datetime(df["Date"]).dt.date >= start_date]
        return df.reset_index(drop=True)

    def _rows_to_ohlcv(self, rows: Any, ticker: str) -> pd.DataFrame:
        if isinstance(rows, dict):
            rows = [rows]
        if not isinstance(rows, list):
            rows = []

        available_fields: List[str] = []
        if rows and isinstance(rows[0], dict):
            available_fields = list(rows[0].keys())
            logging.debug("KIS response fields for %s: %s", ticker, available_fields)

        date_candidates = ["stck_bsop_date", "xymd", "ovrs_bsop_date", "bsop_date", "date", "Date"]
        open_candidates = ["stck_oprc", "open", "ovrs_stck_oprc", "ovrs_nmix_oprc", "oprc"]
        high_candidates = ["stck_hgpr", "high", "ovrs_stck_hgpr", "ovrs_nmix_hgpr", "hgpr"]
        low_candidates = ["stck_lwpr", "low", "ovrs_stck_lwpr", "ovrs_nmix_lwpr", "lwpr"]
        close_candidates = ["stck_clpr", "clos", "close", "last", "ovrs_stck_clpr", "ovrs_nmix_prpr", "clpr"]
        volume_candidates = ["acml_vol", "tvol", "volume", "ovrs_nmix_acml_vol", "trd_vol"]

        out_rows: List[Dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            date_raw = self._first(row, date_candidates)
            if not date_raw:
                continue
            date_str = str(date_raw).replace("-", "")[:8]
            try:
                date_out = pd.to_datetime(date_str).date().isoformat()
            except Exception:
                continue
            open_v = self._num(self._first(row, open_candidates))
            high_v = self._num(self._first(row, high_candidates))
            low_v = self._num(self._first(row, low_candidates))
            close_v = self._num(self._first(row, close_candidates))
            vol_v = self._num(self._first(row, volume_candidates, 0)) or 0.0
            if None in {open_v, high_v, low_v, close_v}:
                continue
            out_rows.append({"Date": date_out, "Open": open_v, "High": high_v, "Low": low_v, "Close": close_v, "Volume": vol_v})
        df = pd.DataFrame(out_rows, columns=["Date", "Open", "High", "Low", "Close", "Volume"])
        if df.empty:
            msg = (
                f"No KIS OHLCV rows parsed for {ticker}. "
                f"Expected date fields={date_candidates}, open={open_candidates}, high={high_candidates}, "
                f"low={low_candidates}, close={close_candidates}. "
            )
            if available_fields:
                msg += f"Available first-row fields={available_fields}. "
            msg += "Check market/exchange/ticker validity, API approval state, and endpoint response format."
            raise RuntimeError(msg)
        return df.drop_duplicates("Date").sort_values("Date").reset_index(drop=True)
