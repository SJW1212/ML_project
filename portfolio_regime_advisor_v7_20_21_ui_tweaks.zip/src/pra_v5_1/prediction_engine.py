from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
import sys
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional

import pandas as pd

from .cache import MarketDataCache
from .feature_schema import validate_prediction_output
from .utils import PraCancelledError, atomic_write_csv, atomic_write_json, config_hash, ensure_dir, normalize_ticker, safe_float, utc_now_iso

SOURCE_TAG = "xgb_recency_weighted_v8_6_41_model_label_fixed"



@dataclass
class PredictionResult:
    ticker: str
    path: Path
    mode: str
    latest_date: Optional[str]
    rows: int
    errors: List[str]


class LocalRunTransaction:
    def __init__(self, root: Path, run_type: str):
        self.root = root
        self.run_type = run_type
        # Keep run ids deliberately short. On Windows, a long project path plus
        # a verbose run id plus the model script's long CSV filename can exceed
        # MAX_PATH and surface as pandas/FileNotFoundError during to_csv().
        prefix = "xgb" if run_type == "external_v8641_xgb" else "run"
        self.run_id = f"{prefix}_{uuid.uuid4().hex[:8]}"
        self.staging_dir = ensure_dir(root / "staging" / self.run_id)
        self.active_dir = ensure_dir(root / "active")
        self.manifest: Dict = {"run_id": self.run_id, "run_type": run_type, "started_at": utc_now_iso(), "items": []}

    def add_item(self, **item) -> None:
        self.manifest["items"].append(item)

    def commit(self) -> Path:
        self.manifest["committed_at"] = utc_now_iso()
        manifest_path = self.staging_dir / "manifest.json"
        atomic_write_json(manifest_path, self.manifest)
        active_manifest = self.active_dir / f"{self.run_id}_manifest.json"
        atomic_write_json(active_manifest, self.manifest)
        return active_manifest

    def cleanup_old_staging(self, keep_last: int = 8) -> None:
        """Keep the newest staging directories and remove older ones.

        Repeated desktop runs can otherwise grow ``storage/runs/staging``
        without bound. Cleanup is best-effort and never fails the analysis.
        """
        staging_root = self.root / "staging"
        if not staging_root.exists():
            return
        dirs = [p for p in staging_root.iterdir() if p.is_dir()]
        dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for old in dirs[int(keep_last):]:
            try:
                shutil.rmtree(old)
            except Exception:
                pass



class PredictionRepository:
    def __init__(self, prediction_dir: Path):
        self.prediction_dir = prediction_dir

    def prediction_path(self, ticker: str) -> Path:
        t = normalize_ticker(ticker).lower()
        return self.prediction_dir / f"{t}_{SOURCE_TAG}_predictions.csv"

    def summary_path(self, ticker: str) -> Path:
        t = normalize_ticker(ticker).lower()
        return self.prediction_dir / f"{t}_{SOURCE_TAG}_summary.json"

    def read_summary(self, ticker: str) -> Dict:
        path = self.summary_path(ticker)
        if not path.exists():
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def summary_engine_mode(self, ticker: str) -> Optional[str]:
        sm = self.read_summary(ticker)
        mode = sm.get("engine_mode")
        return str(mode) if mode else None

    def exists(self, ticker: str) -> bool:
        return self.prediction_path(ticker).exists()

    def read(self, ticker: str) -> pd.DataFrame:
        path = self.prediction_path(ticker)
        if not path.exists():
            raise FileNotFoundError(f"Prediction file not found for {ticker}: {path}")
        df = pd.read_csv(path)
        validate_prediction_output(df)
        return df

    def latest_date(self, ticker: str) -> Optional[str]:
        try:
            df = self.read(ticker)
        except FileNotFoundError:
            return None
        if df.empty:
            return None
        return str(pd.to_datetime(df["Date"]).max().date())


class PredictionGenerationService:
    def __init__(self, cache: MarketDataCache, repo: PredictionRepository, run_root: Path, external_script_path: Path | None = None):
        self.cache = cache
        self.repo = repo
        self.run_root = run_root
        self.external_script_path = external_script_path or Path("src/pra_v5_1/model_engine/xgb_recency_weighted_v8_6_41_model_label_fixed.py")

    @staticmethod
    def _safe_ticker(ticker: str) -> str:
        return "".join(ch.lower() if ch.isalnum() else "_" for ch in str(ticker)).strip("_") or "asset"

    def _should_reuse(self, ticker: str, mode: str, force: bool, signature: Dict[str, object] | None = None) -> bool:
        if force:
            return False
        if not self.repo.prediction_path(ticker).exists():
            return False
        summary = self.repo.read_summary(ticker)
        if summary.get("engine_mode") != mode:
            return False
        for key, expected in (signature or {}).items():
            if str(summary.get(key)) != str(expected):
                return False
        return True

    @staticmethod
    def _short_xgb_base_root() -> Path:
        """Choose a short, writable OS-managed output root for model runs.

        The previous project-local ``.pra_xgb`` directory still inherited the
        user's extraction depth. On Windows, a deeply nested desktop folder plus
        the model script's long prediction filename can still cross legacy path
        limits. This function removes the project extraction depth from the
        equation by preferring short OS locations and verifying write access with
        a small probe file.
        """
        candidates: List[Path] = []
        local_appdata = os.environ.get("LOCALAPPDATA")
        if local_appdata:
            candidates.append(Path(local_appdata) / "pra_xgb")
        candidates.append(Path(tempfile.gettempdir()) / "pra_xgb")
        candidates.append(Path.cwd().resolve() / ".pra_xgb")

        errors: List[str] = []
        for base in candidates:
            try:
                base.mkdir(parents=True, exist_ok=True)
                probe = base / ".write_test"
                probe.write_text("ok", encoding="utf-8")
                probe.unlink(missing_ok=True)
                return base.resolve()
            except Exception as exc:
                errors.append(f"{base}: {exc}")
                try:
                    if 'probe' in locals():
                        probe.unlink(missing_ok=True)
                except Exception:
                    pass
        raise RuntimeError("No writable short model output root found. " + " | ".join(errors))

    @staticmethod
    def _cleanup_short_xgb_runs(base_root: Path, keep_last: int = 8) -> None:
        """Keep only the newest short model run directories.

        The base root is usually ``%LOCALAPPDATA%/pra_xgb`` or
        ``%TEMP%/pra_xgb``. Cleanup is best-effort and never fails analysis.
        """
        if not base_root.exists():
            return
        dirs = [p for p in base_root.iterdir() if p.is_dir()]
        dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for old in dirs[int(keep_last):]:
            try:
                shutil.rmtree(old)
            except Exception:
                pass

    @staticmethod
    def _xgb_timeout_seconds(speed_profile: str) -> int:
        """Per-ticker safety timeout for the external model worker.

        This is not intended to make a valid run artificially fail in normal
        conditions. It prevents the desktop UI from waiting forever when the
        child process is blocked by package/native-library issues or a stalled
        data/model step.
        """
        profile = str(speed_profile or "balanced").lower().strip()
        if profile == "fast":
            return 15 * 60
        if profile == "full":
            return 60 * 60
        return 30 * 60

    @staticmethod
    def _tail_text(path: Path, lines: int = 60) -> str:
        try:
            if not path.exists():
                return ""
            data = path.read_text(encoding="utf-8", errors="replace").splitlines()
            return "\n".join(data[-int(lines):])
        except Exception as exc:
            return f"<failed to read {path}: {exc}>"

    @staticmethod
    def _fast_extra_args(speed_profile: str) -> List[str]:
        """Extra CLI switches for practical desktop fast mode.

        The original v8.6.41 fast profile still performs full walk-forward
        retraining. For a GUI app this can be too slow. These overrides keep the
        same prediction schema but reduce retraining frequency and cap rolling
        train windows.
        """
        if str(speed_profile or "").lower().strip() != "fast":
            return []
        return [
            "--retrain-every", "60",
            "--max-train-rows", "756",
            "--horizon-train-max-cap", "756",
            "--no-diagnostics",
        ]

    @staticmethod
    def _cancel_requested(cancel_event: object | None) -> bool:
        return bool(cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)())

    def _raise_if_cancelled(self, cancel_event: object | None, ticker: str | None = None) -> None:
        if self._cancel_requested(cancel_event):
            suffix = f" ({ticker})" if ticker else ""
            raise PraCancelledError(f"사용자가 모델 예측을 취소했습니다{suffix}.")


    def generate_external_v8641_xgb(
        self,
        tickers: Iterable[str],
        provider: str = "yahoo",
        force: bool = False,
        speed_profile: str = "balanced",
        start: str = "1999-03-10",
        end: str | None = None,
        transaction_cost_bps: float = 10.0,
        prediction_run_mode: str = "latest",
        latest_train_rows: int = 756,
        backtest_start_date: str | None = None,
        cancel_event: object | None = None,
        progress_callback: Callable[[float, str, str | None], None] | None = None,
        progress_start: float = 0.44,
        progress_end: float = 0.64,
    ) -> List[PredictionResult]:
        """Run the included v8.6.41 model walk-forward script and import its predictions.

        This is the real script-based model path, not the lightweight reference engine.
        It still is not a locked artifact loader: the script retrains walk-forward models
        when predictions are regenerated.
        """
        tx = LocalRunTransaction(self.run_root, "external_v8641_xgb")
        results: List[PredictionResult] = []
        mode = "external_v8641_xgb"
        script = Path(self.external_script_path)
        if not script.is_absolute():
            script = Path.cwd() / script
        script = script.resolve()
        if not script.exists():
            err = f"external v8.6.41 script not found: {script}"
            for raw in tickers:
                t = normalize_ticker(raw)
                results.append(PredictionResult(t, self.repo.prediction_path(t), mode, None, 0, [err]))
            return results

        ticker_list = [normalize_ticker(raw) for raw in tickers]

        def emit_progress(percent: float, stage: str, message: str | None = None) -> None:
            if progress_callback is None:
                return
            try:
                pct = max(0.0, min(1.0, float(percent)))
                progress_callback(pct, stage, message)
            except Exception:
                pass

        self._raise_if_cancelled(cancel_event)
        project_root = Path.cwd().resolve()
        base_root = self._short_xgb_base_root()
        total = max(1, len(ticker_list))
        run_mode = "walk_forward" if str(prediction_run_mode or "latest").lower().strip() == "walk_forward" else "latest"
        latest_train_rows = int(latest_train_rows or 756)
        run_signature = {
            "prediction_run_mode": run_mode,
            "latest_train_rows": latest_train_rows if run_mode == "latest" else "walk_forward",
            "source_cache_provider": provider,
            "speed_profile": str(speed_profile or "balanced"),
            "start_date": str(start or "1999-03-10"),
        }
        backtest_start_date = str(backtest_start_date).strip() if backtest_start_date else ""
        if run_mode == "walk_forward" and backtest_start_date:
            run_signature["backtest_start_date"] = backtest_start_date
        if run_mode == "latest":
            emit_progress(progress_start, "모델 실행 준비", f"최근 {latest_train_rows}개 거래일 윈도우 기반 최신 예측 대상 {len(ticker_list)}개: {', '.join(ticker_list)}")
        else:
            emit_progress(progress_start, "모델 실행 준비", f"정밀 walk-forward 대상 {len(ticker_list)}개: {', '.join(ticker_list)}")

        for idx, t in enumerate(ticker_list):
            dest_path = self.repo.prediction_path(t)
            errors: List[str] = []
            try:
                self._raise_if_cancelled(cancel_event, t)
                ticker_start = progress_start + (progress_end - progress_start) * (idx / total)
                ticker_end = progress_start + (progress_end - progress_start) * ((idx + 1) / total)
                ticker_span = max(0.001, ticker_end - ticker_start)
                emit_progress(ticker_start, "모델 종목 준비", f"{idx + 1}/{total} {t}: 캐시/기존 예측 파일을 확인합니다.")
                if self._should_reuse(t, mode, force, run_signature):
                    df_old = self.repo.read(t)
                    results.append(PredictionResult(t, dest_path, mode, self.repo.latest_date(t), len(df_old), []))
                    emit_progress(ticker_end, "모델 종목 재사용", f"{idx + 1}/{total} {t}: 기존 prediction CSV 재사용, rows={len(df_old)}")
                    continue

                safe = self._safe_ticker(t)
                out_dir_abs = ensure_dir(base_root / tx.run_id / safe).resolve()
                emit_progress(ticker_start + ticker_span * 0.08, "모델 출력 폴더 준비", f"{idx + 1}/{total} {t}: 임시 출력 폴더를 준비했습니다.")
                # Pass a short absolute OS-managed output path. The important
                # invariant is not relative-vs-absolute; it is that the resolved
                # path is independent of the user's deep project extraction path.
                cmd = [
                    sys.executable,
                    str(script),
                    "--target-ticker", t,
                    "--result-dir", str(out_dir_abs),
                    "--speed-profile", str(speed_profile or "balanced"),
                    "--start-date", str(start or "1999-03-10"),
                    "--h10-down-only",
                    "--transaction-cost-rate", str(float(transaction_cost_bps) / 10000.0),
                ]
                if run_mode == "latest":
                    cmd.extend(["--latest-only", "--latest-train-rows", str(int(latest_train_rows))])
                elif backtest_start_date:
                    # Prediction (OOS) start date for walk-forward, independent of
                    # --start-date (training-data start).
                    cmd.extend(["--backtest-start-date", backtest_start_date])
                cmd.extend(self._fast_extra_args(speed_profile))
                if end:
                    cmd.extend(["--end-date", str(end)])
                emit_progress(ticker_start + ticker_span * 0.14, "모델 명령 구성", f"{idx + 1}/{total} {t}: mode={run_mode}, speed={speed_profile}, start={start}, provider={provider}")
                env = os.environ.copy()
                env["PRA_MARKET_CACHE_DIR"] = str(self.cache.root.resolve())
                env["PRA_MARKET_CACHE_PROVIDER"] = provider
                env["PYTHONPATH"] = str(script.parent) + os.pathsep + env.get("PYTHONPATH", "")
                emit_progress(ticker_start + ticker_span * 0.20, "모델 프로세스 시작", f"{idx + 1}/{total} {t}: 외부 모델 스크립트를 실행합니다.")
                stdout_path = out_dir_abs / "xgb_stdout.log"
                stderr_path = out_dir_abs / "xgb_stderr.log"
                timeout_seconds = self._xgb_timeout_seconds(speed_profile)
                stdout_f = open(stdout_path, "w", encoding="utf-8", errors="replace")
                stderr_f = open(stderr_path, "w", encoding="utf-8", errors="replace")
                try:
                    proc = subprocess.Popen(
                        cmd,
                        cwd=str(project_root),
                        env=env,
                        text=True,
                        stdout=stdout_f,
                        stderr=stderr_f,
                    )
                    process_started_at = time.monotonic()
                    last_progress_emit = 0.0
                    while True:
                        if self._cancel_requested(cancel_event):
                            try:
                                proc.terminate()
                                proc.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                proc.kill()
                                proc.wait(timeout=5)
                            except Exception:
                                try:
                                    proc.kill()
                                except Exception:
                                    pass
                            raise PraCancelledError(f"사용자가 모델 예측을 취소했습니다. 진행 중이던 {t} 프로세스를 종료했습니다.")
                        if proc.poll() is not None:
                            break
                        now = time.monotonic()
                        elapsed = max(0.0, now - process_started_at)
                        if elapsed > timeout_seconds:
                            try:
                                proc.terminate()
                                proc.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                proc.kill()
                                proc.wait(timeout=5)
                            raise TimeoutError(
                                f"{t} 모델 작업이 {int(timeout_seconds/60)}분 제한을 초과해 중단되었습니다. "
                                f"speed_profile={speed_profile}, start={start}. "
                                f"stdout={stdout_path}, stderr={stderr_path}"
                            )
                        if now - last_progress_emit >= 2.0:
                            # The model script does not expose exact per-fold progress.
                            # Use a capped elapsed-time estimate so the UI keeps showing
                            # useful liveness instead of staying frozen at one percentage.
                            elapsed_factor = min(0.88, elapsed / max(60.0, timeout_seconds * 0.60))
                            live_pct = ticker_start + ticker_span * (0.20 + 0.62 * elapsed_factor)
                            if run_mode == "latest":
                                live_msg = f"{idx + 1}/{total} {t}: 최근 윈도우 학습 및 최신 예측 진행 중, 경과 {int(elapsed)}초, 제한 {int(timeout_seconds/60)}분"
                            else:
                                live_msg = f"{idx + 1}/{total} {t}: 모델 학습/워크포워드 진행 중, 경과 {int(elapsed)}초, 제한 {int(timeout_seconds/60)}분"
                            emit_progress(live_pct, "모델 실행 중", live_msg)
                            last_progress_emit = now
                        time.sleep(0.25)
                finally:
                    try:
                        stdout_f.close()
                    except Exception:
                        pass
                    try:
                        stderr_f.close()
                    except Exception:
                        pass
                emit_progress(ticker_start + ticker_span * 0.86, "모델 출력 수집", f"{idx + 1}/{total} {t}: 프로세스 종료 후 결과 파일을 확인합니다.")
                if proc.returncode != 0:
                    tail = (self._tail_text(stderr_path, 40) or self._tail_text(stdout_path, 40))
                    raise RuntimeError(f"external_v8641_model failed for {t} with code {proc.returncode}:\n{tail}")

                external_pred_path = out_dir_abs / f"{safe}_{SOURCE_TAG}_predictions.csv"
                external_summary_path = out_dir_abs / f"{safe}_{SOURCE_TAG}_summary.json"
                if not external_pred_path.exists():
                    raise FileNotFoundError(f"external prediction file not found: {external_pred_path}")
                emit_progress(ticker_start + ticker_span * 0.92, "모델 예측 파일 검증", f"{idx + 1}/{total} {t}: prediction CSV를 읽고 schema를 검증합니다.")
                pred = pd.read_csv(external_pred_path, encoding="utf-8-sig")
                if "ticker" not in pred.columns:
                    pred["ticker"] = t
                pred["ticker"] = t
                validate_prediction_output(pred)
                atomic_write_csv(dest_path, pred)

                external_summary: Dict = {}
                if external_summary_path.exists():
                    with open(external_summary_path, "r", encoding="utf-8") as f:
                        external_summary = json.load(f)
                summary = {
                    "ticker": t,
                    "model_version": "v8.6.41_model_label_fixed_xgboost_script",
                    "engine_mode": mode,
                    "created_at": utc_now_iso(),
                    "rows": int(len(pred)),
                    "latest_date": str(pd.to_datetime(pred["Date"]).max().date()) if len(pred) else None,
                    "source_cache_provider": provider,
                    "prediction_run_mode": run_mode,
                    "latest_train_rows": int(latest_train_rows) if run_mode == "latest" else None,
                    "speed_profile": str(speed_profile or "balanced"),
                    "start_date": str(start or "1999-03-10"),
                    "external_result_dir": str(out_dir_abs),
                    "external_stdout_log": str(stdout_path),
                    "external_stderr_log": str(stderr_path),
                    "external_summary": external_summary,
                }
                atomic_write_json(self.repo.summary_path(t), summary)
                tx.add_item(ticker=t, prediction_path=str(dest_path), external_result_dir=str(out_dir_abs), rows=len(pred), latest_date=summary["latest_date"], engine_mode=mode)
                results.append(PredictionResult(t, dest_path, mode, summary["latest_date"], len(pred), []))
                emit_progress(ticker_end, "모델 종목 완료", f"{idx + 1}/{total} {t}: rows={len(pred)}, latest={summary['latest_date']}")
            except PraCancelledError:
                raise
            except Exception as exc:
                errors.append(str(exc))
                results.append(PredictionResult(t, dest_path, mode, None, 0, errors))
        emit_progress(progress_end, "모델 결과 정리", "manifest 저장과 임시 폴더 정리를 수행합니다.")
        tx.commit()
        tx.cleanup_old_staging(keep_last=8)
        self._cleanup_short_xgb_runs(base_root, keep_last=8)
        emit_progress(progress_end, "모델 예측 생성 완료", f"완료 종목 {len(results)}/{len(ticker_list)}")
        return results
