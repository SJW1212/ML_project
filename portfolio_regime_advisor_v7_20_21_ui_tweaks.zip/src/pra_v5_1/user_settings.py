from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict

from .utils import atomic_write_json, ensure_dir, load_json


SETTINGS_PATH = Path("storage/config/user_settings.json")


@dataclass
class UserSettings:
    """Local-only personal settings for the CustomTkinter app.

    These values are not account data and are not sent anywhere. They are stored
    under ``storage/config/user_settings.json`` so the personal desktop app can
    remember defaults between runs.
    """

    base_currency: str = "KRW"
    operating_capital: float = 10_000_000.0
    risk_profile: str = "balanced"
    provider: str = "auto"
    speed_profile: str = "balanced"
    prediction_run_mode: str = "latest"
    latest_train_rows: int = 756
    model_start_date: str = "1999-03-10"
    model_end_date: str = ""
    model_backtest_start_date: str = ""
    capital_mode: str = "current_weight"
    auto_cash_enabled: bool = True
    force_update_default: bool = False
    force_prediction_default: bool = False
    transaction_cost_bps: float = 10.0
    min_cash_pct: float = 0.0
    max_asset_pct: float = 100.0
    risk_sensitivity: float = 1.0

    def normalized(self) -> "UserSettings":
        self.base_currency = (self.base_currency or "KRW").upper()
        if self.risk_profile not in {"conservative", "balanced", "aggressive"}:
            self.risk_profile = "balanced"
        if self.provider not in {"auto", "yahoo", "kis", "hybrid"}:
            self.provider = "auto"
        if self.speed_profile not in {"fast", "balanced", "full"}:
            self.speed_profile = "balanced"
        if self.capital_mode not in {"current_weight", "equal", "inverse_vol"}:
            self.capital_mode = "current_weight"
        if self.prediction_run_mode not in {"latest", "walk_forward"}:
            self.prediction_run_mode = "latest"
        try:
            self.latest_train_rows = int(self.latest_train_rows or 756)
        except Exception:
            self.latest_train_rows = 756
        self.latest_train_rows = min(max(int(self.latest_train_rows), 504), 2520)
        self.model_start_date = str(self.model_start_date or "1999-03-10").strip() or "1999-03-10"
        # Empty string means "not set" -> the model/engine uses its own default
        # (end = latest available; backtest/prediction start = model default).
        self.model_end_date = str(self.model_end_date or "").strip()
        self.model_backtest_start_date = str(self.model_backtest_start_date or "").strip()
        self.auto_cash_enabled = bool(self.auto_cash_enabled)
        self.operating_capital = max(float(self.operating_capital or 0.0), 0.0)
        self.transaction_cost_bps = min(max(float(self.transaction_cost_bps or 0.0), 0.0), 200.0)
        self.min_cash_pct = min(max(float(self.min_cash_pct or 0.0), 0.0), 100.0)
        self.max_asset_pct = min(max(float(self.max_asset_pct or 100.0), 1.0), 100.0)
        self.risk_sensitivity = min(max(float(self.risk_sensitivity or 1.0), 0.1), 3.0)
        return self

    def to_json_dict(self) -> Dict[str, Any]:
        return asdict(self.normalized())


def load_user_settings(path: Path = SETTINGS_PATH) -> UserSettings:
    data = load_json(path, default={}) or {}
    if not isinstance(data, dict):
        data = {}
    # Backward compatibility: older versions used total_funds / available_cash.
    # v7.14 keeps one source of truth: operating_capital.
    if "operating_capital" not in data and "total_funds" in data:
        data["operating_capital"] = data.get("total_funds")
    data.pop("total_funds", None)
    data.pop("available_cash", None)
    allowed = set(UserSettings.__dataclass_fields__.keys())
    clean = {k: v for k, v in data.items() if k in allowed}
    return UserSettings(**clean).normalized()


def save_user_settings(settings: UserSettings, path: Path = SETTINGS_PATH) -> Path:
    ensure_dir(path.parent)
    atomic_write_json(path, settings.to_json_dict())
    return path
