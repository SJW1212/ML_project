from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional

import pandas as pd

from .cache import MarketDataCache
from .config import AppConfig
from .kis_provider import KisCredentialStore, KisQuoteProvider
from .ohlcv import normalize_ohlcv_frame
from .utils import PraCancelledError, normalize_ticker


MIN_MODEL_HISTORY_ROWS = 1000


@dataclass
class UpdateStatus:
    provider: str
    updated: List[str]
    skipped: List[str]
    errors: Dict[str, str]
    notes: List[str] | None = None


class YahooMarketDataProvider:
    def download_ohlcv(self, ticker: str, start: str, end: Optional[str] = None) -> pd.DataFrame:
        try:
            import yfinance as yf
        except Exception as exc:
            raise RuntimeError("yfinance is not installed. Run: python -m pip install yfinance") from exc
        t = normalize_ticker(ticker)
        try:
            df = yf.download(t, start=start, end=end, auto_adjust=True, progress=False, threads=False, timeout=20)
        except TypeError:
            # Older yfinance versions may not expose ``timeout``. Keep backward
            # compatibility rather than failing setup-time smoke tests.
            df = yf.download(t, start=start, end=end, auto_adjust=True, progress=False, threads=False)
        if df is None or df.empty:
            raise RuntimeError(f"No OHLCV data returned for {t}")
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
        return df.reset_index()


class DailyMarketDataUpdater:
    def __init__(self, cache: MarketDataCache, config: AppConfig | None = None):
        self.cache = cache
        self.config = config or AppConfig.from_json()
        self.kis_store = KisCredentialStore(self.config.config_dir)

    def kis_status(self) -> Dict:
        return KisQuoteProvider(self.kis_store).status()

    @staticmethod
    def _normalize_provider_frame(df: pd.DataFrame | None) -> pd.DataFrame | None:
        """Normalize provider output before Yahoo/KIS hybrid concatenation.

        Hybrid cache is source data for the model path, so Date dtype, numeric
        dtype, duplicate rows, and sort order must be deterministic before write.
        """
        return normalize_ohlcv_frame(
            df,
            empty_policy="none",
            rename_columns_title=False,
            allow_datetime_index=True,
            missing_error_prefix="Provider output missing OHLCV column",
            volume_default=0.0,
            date_errors="coerce",
            date_format="strftime",
            duplicate_keep="last",
        )

    @staticmethod
    def _history_quality(df: pd.DataFrame | None, start: str | None = None, min_rows: int = MIN_MODEL_HISTORY_ROWS) -> Dict[str, object]:
        norm = DailyMarketDataUpdater._normalize_provider_frame(df)
        if norm is None or norm.empty:
            return {"ok": False, "rows": 0, "first_date": None, "last_date": None, "reason": "empty"}
        view = norm.copy()
        if start:
            try:
                view = view[pd.to_datetime(view["Date"], errors="coerce") >= pd.to_datetime(start)]
            except Exception:
                pass
        rows = int(len(view))
        first_date = str(view["Date"].iloc[0]) if rows else None
        last_date = str(view["Date"].iloc[-1]) if rows else None
        if rows < int(min_rows):
            return {"ok": False, "rows": rows, "first_date": first_date, "last_date": last_date, "reason": f"rows<{min_rows}"}
        return {"ok": True, "rows": rows, "first_date": first_date, "last_date": last_date, "reason": "ok"}

    def _cached_history_is_usable(self, ticker: str, provider: str, start: str | None, min_rows: int = MIN_MODEL_HISTORY_ROWS) -> bool:
        try:
            df = self.cache.read_ohlcv(ticker, provider)
        except Exception:
            return False
        return bool(self._history_quality(df, start=start, min_rows=min_rows).get("ok"))

    def update_daily(
        self,
        tickers: Iterable[str],
        provider: str = "yahoo",
        start: str = "2013-01-01",
        end: Optional[str] = None,
        force: bool = False,
        cancel_event: object | None = None,
        progress_callback: Callable[[int, int, str, str], None] | None = None,
    ) -> UpdateStatus:
        provider = provider.lower()
        updated: List[str] = []
        skipped: List[str] = []
        errors: Dict[str, str] = {}
        notes: List[str] = []

        if provider not in {"auto", "yahoo", "kis", "hybrid"}:
            return UpdateStatus(provider=provider, updated=[], skipped=[], errors={"provider": f"Unsupported provider: {provider}"}, notes=[])

        def check_cancel() -> None:
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                raise PraCancelledError("사용자가 데이터 갱신을 취소했습니다.")

        def emit(idx: int, total: int, ticker: str, message: str) -> None:
            if progress_callback is not None:
                try:
                    progress_callback(idx, total, ticker, message)
                except Exception:
                    pass
            check_cancel()

        yf_provider = YahooMarketDataProvider()
        kis_provider = KisQuoteProvider(self.kis_store, timeout=8)
        ticker_list = [normalize_ticker(raw) for raw in tickers]
        total = max(len(ticker_list), 1)
        kis_configured = bool((self.kis_store.load().app_key or "").strip() and (self.kis_store.load().app_secret or "").strip())

        for idx, t in enumerate(ticker_list, start=1):
            check_cancel()
            try:
                emit(idx, total, t, f"{idx}/{total} {t}: provider={provider}, cache freshness 확인")
                target_provider = provider
                if not force and self.cache.has_ohlcv(t, target_provider):
                    fresh = self.cache.freshness([t], target_provider)[0]
                    if fresh.get("is_fresh_daily") and self._cached_history_is_usable(t, target_provider, start):
                        skipped.append(t)
                        continue
                    if fresh.get("is_fresh_daily"):
                        notes.append(f"{t}: cached {target_provider} data is fresh but too short for walk-forward; refreshing/fallback will be attempted.")

                if provider == "yahoo":
                    emit(idx, total, t, f"{idx}/{total} {t}: Yahoo OHLCV 다운로드 중")
                    df = yf_provider.download_ohlcv(t, start=start, end=end)
                    check_cancel()
                    self.cache.write_ohlcv(t, df, provider)
                elif provider == "kis":
                    emit(idx, total, t, f"{idx}/{total} {t}: KIS OHLCV 다운로드 중")
                    df = kis_provider.download_ohlcv(t, start=start, end=end)
                    check_cancel()
                    self.cache.write_ohlcv(t, df, provider)
                    notes.append(f"{t}: KIS daily quotation cache updated. Long historical range can be limited by KIS endpoint/account policy.")
                elif provider == "auto":
                    # Personal-app default: prefer KIS only when it has enough
                    # history for the walk-forward model. KIS quotation endpoints
                    # can return only a short recent window for some overseas
                    # symbols; using that as model input causes "백테스트 가능한
                    # 데이터가 부족합니다" during prediction generation. In that
                    # case auto must fall back to Yahoo historical data, not treat
                    # the short KIS response as success.
                    kis_exc: Exception | None = None
                    try:
                        if not kis_configured:
                            raise RuntimeError("KIS credentials are not configured; auto provider skips KIS and uses Yahoo directly.")
                        emit(idx, total, t, f"{idx}/{total} {t}: auto 모드 KIS 우선 시도")
                        kis_df = kis_provider.download_ohlcv(t, start=start, end=end)
                        check_cancel()
                        self.cache.write_ohlcv(t, kis_df, "kis")
                        q = self._history_quality(kis_df, start=start)
                        if not q.get("ok"):
                            raise RuntimeError(
                                f"KIS OHLCV history is insufficient for model walk-forward "
                                f"({q.get('rows')} rows, {q.get('first_date')}~{q.get('last_date')}, {q.get('reason')})."
                            )
                        self.cache.write_ohlcv(t, kis_df, "auto")
                        notes.append(f"{t}: auto provider used KIS ({q.get('rows')} rows) and saved caches under kis/ and auto/.")
                    except Exception as exc:
                        kis_exc = exc
                        emit(idx, total, t, f"{idx}/{total} {t}: Yahoo fallback 다운로드 중")
                        yahoo_df = yf_provider.download_ohlcv(t, start=start, end=end)
                        check_cancel()
                        yq = self._history_quality(yahoo_df, start=start)
                        if not yq.get("ok"):
                            raise RuntimeError(
                                f"Yahoo fallback also has insufficient history for {t}: "
                                f"{yq.get('rows')} rows, {yq.get('first_date')}~{yq.get('last_date')}, {yq.get('reason')}. "
                                f"Original KIS issue: {kis_exc}"
                            )
                        self.cache.write_ohlcv(t, yahoo_df, "yahoo")
                        self.cache.write_ohlcv(t, yahoo_df, "auto")
                        notes.append(
                            f"{t}: auto provider fell back to Yahoo historical data "
                            f"({yq.get('rows')} rows) because KIS was unavailable or too short: {kis_exc}"
                        )
                else:  # hybrid: Yahoo backfill + KIS latest rows, saved under provider=hybrid.
                    yahoo_df = None
                    kis_df = None
                    yahoo_error = None
                    kis_error = None
                    try:
                        if self.cache.has_ohlcv(t, "yahoo") and not force:
                            yahoo_df = self.cache.read_ohlcv(t, "yahoo")
                        else:
                            emit(idx, total, t, f"{idx}/{total} {t}: hybrid Yahoo backfill 다운로드 중")
                            yahoo_df = yf_provider.download_ohlcv(t, start=start, end=end)
                            check_cancel()
                            self.cache.write_ohlcv(t, yahoo_df, "yahoo")
                    except Exception as exc:
                        yahoo_error = exc
                    try:
                        if not kis_configured:
                            raise RuntimeError("KIS credentials are not configured; hybrid uses Yahoo without KIS overlay.")
                        emit(idx, total, t, f"{idx}/{total} {t}: hybrid KIS overlay 다운로드 중")
                        kis_df = kis_provider.download_ohlcv(t, start=start, end=end)
                        check_cancel()
                        self.cache.write_ohlcv(t, kis_df, "kis")
                    except Exception as exc:
                        kis_error = exc
                    if yahoo_df is None and kis_df is None:
                        raise RuntimeError(f"hybrid update failed. yahoo={yahoo_error}; kis={kis_error}")

                    yahoo_df = self._normalize_provider_frame(yahoo_df)
                    kis_df = self._normalize_provider_frame(kis_df)
                    parts = [df for df in [yahoo_df, kis_df] if df is not None and not df.empty]
                    if not parts:
                        raise RuntimeError(f"hybrid update failed: all provider frames were empty after normalization for {t}")
                    # KIS rows are placed after Yahoo rows, so duplicate dates keep KIS
                    # as the latest/overlay source. Date is already ISO string.
                    merged = pd.concat(parts, ignore_index=True)
                    merged = merged.drop_duplicates(subset=["Date"], keep="last").sort_values("Date").reset_index(drop=True)
                    self.cache.write_ohlcv(t, merged, "hybrid")
                    if kis_error:
                        notes.append(f"{t}: hybrid used Yahoo data; KIS overlay failed: {kis_error}")
                    else:
                        notes.append(f"{t}: hybrid cache = Yahoo historical backfill + KIS latest quotation rows. Data normalized and deduplicated by Date.")
                updated.append(t)
                emit(idx, total, t, f"{idx}/{total} {t}: 데이터 갱신 완료")
            except PraCancelledError:
                raise
            except Exception as exc:
                errors[t] = str(exc)
        return UpdateStatus(provider=provider, updated=updated, skipped=skipped, errors=errors, notes=notes)
