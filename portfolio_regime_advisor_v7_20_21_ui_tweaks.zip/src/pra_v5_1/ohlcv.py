from __future__ import annotations

from typing import Literal

import pandas as pd

OHLCV_COLUMNS = ["Date", "Open", "High", "Low", "Close", "Volume"]


def empty_ohlcv_frame() -> pd.DataFrame:
    return pd.DataFrame(columns=OHLCV_COLUMNS)


def normalize_ohlcv_frame(
    df: pd.DataFrame | None,
    *,
    empty_policy: Literal["empty_frame", "none"] = "empty_frame",
    rename_columns_title: bool = True,
    allow_datetime_index: bool = True,
    missing_error_prefix: str = "Missing OHLCV column",
    volume_default: float = 0.0,
    date_errors: Literal["raise", "coerce"] = "raise",
    date_format: Literal["date_str", "strftime"] = "date_str",
    duplicate_keep: Literal["first", "last"] = "first",
) -> pd.DataFrame | None:
    """Normalize OHLCV frames from cache/provider layers.

    The project used to have two near-identical normalizers:
    ``MarketDataCache.normalize_ohlcv`` and
    ``DailyMarketDataUpdater._normalize_provider_frame``.  They intentionally
    differed in a few edge policies, especially duplicate-date keep mode:
    cache keeps the first row, provider keeps the last row before hybrid merge.

    This function centralizes the shared mechanics while preserving those caller
    policies through explicit parameters.
    """
    if df is None or df.empty:
        return None if empty_policy == "none" else empty_ohlcv_frame()

    out = df.copy()

    if rename_columns_title:
        out = out.rename(columns={c: str(c).strip().title() for c in out.columns})

    if "Date" not in out.columns and allow_datetime_index and isinstance(out.index, pd.DatetimeIndex):
        out = out.reset_index().rename(columns={out.index.name or "index": "Date"})

    if "Adj Close" in out.columns and "Close" not in out.columns:
        out["Close"] = out["Adj Close"]

    for col in OHLCV_COLUMNS:
        if col not in out.columns:
            if col == "Volume":
                out[col] = volume_default
            else:
                raise ValueError(f"{missing_error_prefix}: {col}")

    out = out[OHLCV_COLUMNS].copy()

    if date_format == "strftime":
        out["Date"] = pd.to_datetime(out["Date"], errors=date_errors).dt.strftime("%Y-%m-%d")
    else:
        out["Date"] = pd.to_datetime(out["Date"], errors=date_errors).dt.date.astype(str)

    for col in ["Open", "High", "Low", "Close", "Volume"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    out = out.dropna(subset=["Date", "Open", "High", "Low", "Close"])
    out = out.drop_duplicates(subset=["Date"], keep=duplicate_keep).sort_values("Date")
    return out.reset_index(drop=True)
