from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import pandas as pd

from .ohlcv import normalize_ohlcv_frame
from .utils import atomic_write_csv, ensure_dir, normalize_ticker


CACHE_FRESHNESS_DAYS = 4


class MarketDataCache:
    def __init__(self, root: Path):
        self.root = root

    def ohlcv_path(self, ticker: str, provider: str = "yahoo") -> Path:
        t = normalize_ticker(ticker)
        return self.root / "ohlcv" / provider / f"{t}.csv"

    def has_ohlcv(self, ticker: str, provider: str = "yahoo") -> bool:
        return self.ohlcv_path(ticker, provider).exists()

    def write_ohlcv(self, ticker: str, df: pd.DataFrame, provider: str = "yahoo") -> Path:
        path = self.ohlcv_path(ticker, provider)
        out = self.normalize_ohlcv(df)
        # Explicit float precision avoids platform/pandas-version dependent CSV
        # formatting drift in cached OHLCV data. 10 decimals is more than enough
        # for daily price data and keeps model features reproducible.
        atomic_write_csv(path, out, float_format="%.10f")
        return path

    def read_ohlcv(self, ticker: str, provider: str = "yahoo") -> pd.DataFrame:
        path = self.ohlcv_path(ticker, provider)
        if not path.exists():
            raise FileNotFoundError(f"OHLCV cache not found: {path}")
        df = pd.read_csv(
            path,
            dtype={
                "Date": str,
                "Open": float,
                "High": float,
                "Low": float,
                "Close": float,
                "Volume": float,
            },
        )
        return self.normalize_ohlcv(df)

    def latest_date(self, ticker: str, provider: str = "yahoo") -> Optional[str]:
        try:
            df = self.read_ohlcv(ticker, provider)
        except FileNotFoundError:
            return None
        if df.empty:
            return None
        return str(pd.to_datetime(df["Date"]).max().date())

    def freshness(self, tickers: Iterable[str], provider: str = "yahoo") -> List[Dict]:
        rows = []
        today = pd.Timestamp.utcnow().date()
        for raw in tickers:
            t = normalize_ticker(raw)
            latest = self.latest_date(t, provider)
            age_days = None
            is_fresh_daily = False
            if latest:
                d = pd.to_datetime(latest).date()
                age_days = (today - d).days
                is_fresh_daily = age_days <= CACHE_FRESHNESS_DAYS
            rows.append({"ticker": t, "provider": provider, "latest_date": latest, "age_days": age_days, "is_fresh_daily": is_fresh_daily})
        return rows

    @staticmethod
    def normalize_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
        out = normalize_ohlcv_frame(
            df,
            empty_policy="empty_frame",
            rename_columns_title=True,
            allow_datetime_index=True,
            missing_error_prefix="Missing OHLCV column",
            volume_default=0,
            date_errors="raise",
            date_format="date_str",
            duplicate_keep="first",
        )
        assert out is not None
        return out
