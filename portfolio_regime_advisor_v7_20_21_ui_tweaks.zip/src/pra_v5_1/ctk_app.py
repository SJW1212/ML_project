from __future__ import annotations

import json
import queue
import threading
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

import tkinter as tk
from tkinter import messagebox

import customtkinter as ctk

from .config import AppConfig
from .kis_provider import KisCredentialStore, KisSettings
from .schemas import EvaluateSettings, PortfolioAssetInput, PortfolioEvaluateRequest
from .service import PortfolioRegimeAdvisorService
from .utils import PraCancelledError, atomic_write_json, normalize_ticker, safe_float
from .user_settings import UserSettings, load_user_settings, save_user_settings
from .portfolio_slots import (
    MAX_PORTFOLIO_SLOTS,
    PortfolioSlot,
    PortfolioSlotAsset,
    load_portfolio_slots,
    save_portfolio_slots,
    utc_now_iso as slot_utc_now_iso,
)


APP_VERSION = "7.20.21"
ASSET_TYPES = ["stock", "etf", "risk_asset", "bond_bucket", "cash"]
PROVIDERS = ["auto", "yahoo", "kis", "hybrid"]
RISK_PROFILES = ["conservative", "balanced", "aggressive"]
SPEED_PROFILES = ["fast", "balanced", "full"]
CAPITAL_MODES = ["current_weight", "equal", "inverse_vol"]
PREDICTION_RUN_MODES = ["latest", "walk_forward"]
ACTION_BUTTON_HEIGHT = 46
ACTION_BUTTON_FONT_SIZE = 15
ACTION_BUTTON_CORNER_RADIUS = 10
CANCEL_BUTTON_WIDTH = 112

EXAMPLE_ROWS = [
    ("QQQ", "Nasdaq 100 ETF", "etf", "3000000"),
    ("AAPL", "Apple", "stock", "2000000"),
    ("NVDA", "NVIDIA", "stock", "1500000"),
    ("LLY", "Eli Lilly", "stock", "1000000"),
    ("BOND_BUCKET", "채권", "bond_bucket", "1500000"),
]
EXAMPLE_BASE_OPERATING_CAPITAL = 10_000_000.0

PIE_COLORS = ["#50ffaf", "#a6c8ff", "#c6c6cc", "#ffcc66", "#ff8a80", "#b388ff", "#80cbc4", "#f48fb1"]


@dataclass
class HoldingRowState:
    ticker: ctk.StringVar
    name: ctk.StringVar
    asset_type: ctk.StringVar
    amount: ctk.StringVar
    weight: ctk.StringVar
    frame: ctk.CTkFrame


class PieChart(ctk.CTkFrame):
    def __init__(self, master, title: str, **kwargs):
        super().__init__(master, corner_radius=18, fg_color="#111c2d", **kwargs)
        self.title = title
        self.label = ctk.CTkLabel(self, text=title, font=ctk.CTkFont(size=16, weight="bold"))
        self.label.pack(anchor="w", padx=18, pady=(16, 4))
        self.canvas = tk.Canvas(self, width=360, height=260, bg="#111c2d", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=(0, 14))
        self.data: List[Tuple[str, float]] = []
        self.bind("<Configure>", lambda _e: self.draw())

    def set_data(self, data: List[Tuple[str, float]]) -> None:
        self.data = [(str(k), float(v)) for k, v in data if float(v) > 0]
        self.draw()

    def draw(self) -> None:
        self.canvas.delete("all")
        w = max(self.canvas.winfo_width(), 320)
        h = max(self.canvas.winfo_height(), 240)
        total = sum(v for _k, v in self.data)
        if total <= 0:
            self.canvas.create_text(w / 2, h / 2, text="데이터 없음", fill="#909095", font=("Segoe UI", 12))
            return
        cx, cy = min(w * 0.34, 170), h * 0.48
        r = min(w * 0.24, h * 0.36, 92)
        box = (cx - r, cy - r, cx + r, cy + r)
        start = 90.0
        for idx, (_label, value) in enumerate(self.data):
            extent = -360.0 * value / total
            self.canvas.create_arc(box, start=start, extent=extent, fill=PIE_COLORS[idx % len(PIE_COLORS)], outline="#091324", width=2)
            start += extent
        # donut hole: keep the chart clean. The legend already shows that
        # portfolio weights sum to 100%, so no center "100%" label is needed.
        self.canvas.create_oval(cx - r * 0.52, cy - r * 0.52, cx + r * 0.52, cy + r * 0.52, fill="#111c2d", outline="#111c2d")

        lx = w * 0.62
        ly = max(38, cy - min(84, 16 * len(self.data)))
        for idx, (label, value) in enumerate(self.data):
            pct = value / total * 100.0
            color = PIE_COLORS[idx % len(PIE_COLORS)]
            y = ly + idx * 28
            self.canvas.create_rectangle(lx, y - 7, lx + 12, y + 5, fill=color, outline=color)
            display = label if len(label) <= 12 else label[:11] + "…"
            self.canvas.create_text(lx + 20, y, text=f"{display}  {pct:.1f}%", fill="#d9e3fb", anchor="w", font=("Segoe UI", 10))



class LineChart(ctk.CTkFrame):
    def __init__(self, master, title: str, **kwargs):
        super().__init__(master, corner_radius=18, fg_color="#111c2d", **kwargs)
        self.title = title
        self.label = ctk.CTkLabel(self, text=title, font=ctk.CTkFont(size=16, weight="bold"))
        self.label.pack(anchor="w", padx=18, pady=(16, 4))
        self.canvas = tk.Canvas(self, width=420, height=220, bg="#111c2d", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=(0, 14))
        self.points: List[Tuple[str, float]] = []
        self.bind("<Configure>", lambda _e: self.draw())

    def set_data(self, points: List[Tuple[str, float]]) -> None:
        clean: List[Tuple[str, float]] = []
        for label, value in points:
            try:
                clean.append((str(label), float(value)))
            except Exception:
                pass
        self.points = clean
        self.draw()

    def draw(self) -> None:
        self.canvas.delete("all")
        w = max(self.canvas.winfo_width(), 320)
        h = max(self.canvas.winfo_height(), 190)
        if len(self.points) < 2:
            self.canvas.create_text(w / 2, h / 2, text="성과 곡선 데이터 없음", fill="#909095", font=("Segoe UI", 12))
            return
        values = [v for _d, v in self.points]
        mn, mx = min(values), max(values)
        if abs(mx - mn) < 1e-12:
            mn -= 0.01
            mx += 0.01
        left, right, top, bottom = 34, w - 20, 24, h - 34
        # axes / grid
        for i in range(4):
            y = top + (bottom - top) * i / 3
            self.canvas.create_line(left, y, right, y, fill="#1f2a3c")
        coords = []
        for i, (_d, value) in enumerate(self.points):
            x = left + (right - left) * i / max(len(self.points) - 1, 1)
            y = bottom - (value - mn) / (mx - mn) * (bottom - top)
            coords.extend([x, y])
        self.canvas.create_line(*coords, fill="#50ffaf", width=3, smooth=True)
        self.canvas.create_text(left, bottom + 16, text=self.points[0][0], fill="#909095", anchor="w", font=("Segoe UI", 9))
        self.canvas.create_text(right, bottom + 16, text=self.points[-1][0], fill="#909095", anchor="e", font=("Segoe UI", 9))
        self.canvas.create_text(left, top + 2, text=f"{mx:.3f}", fill="#909095", anchor="w", font=("Consolas", 9))
        self.canvas.create_text(left, bottom - 2, text=f"{mn:.3f}", fill="#909095", anchor="w", font=("Consolas", 9))


class PortfolioInputRow:
    def __init__(self, app: "MinimalCTkApp", parent: ctk.CTkFrame):
        self.app = app
        self.frame = ctk.CTkFrame(parent, fg_color="#162031", corner_radius=12)
        self.ticker = ctk.StringVar()
        self.name = ctk.StringVar()
        self.asset_type = ctk.StringVar(value="stock")
        self.amount = ctk.StringVar()
        self.weight = ctk.StringVar(value="0.00%")
        self.widgets: list[Any] = []

        self.ticker_entry = ctk.CTkEntry(self.frame, textvariable=self.ticker, placeholder_text="AAPL", width=90)
        self.name_entry = ctk.CTkEntry(self.frame, textvariable=self.name, placeholder_text="종목명", width=130)
        self.type_menu = ctk.CTkOptionMenu(self.frame, values=ASSET_TYPES, variable=self.asset_type, width=120, command=lambda _v: self.app.recalculate_current())
        self.amount_entry = ctk.CTkEntry(self.frame, textvariable=self.amount, placeholder_text="보유금액", width=130, justify="right")
        self.weight_label = ctk.CTkLabel(self.frame, textvariable=self.weight, width=76, anchor="e", font=ctk.CTkFont(family="Consolas", size=13))
        self.delete_btn = ctk.CTkButton(self.frame, text="삭제", width=58, fg_color="#2b3548", command=self.delete)
        for i, w in enumerate([self.ticker_entry, self.name_entry, self.type_menu, self.amount_entry, self.weight_label, self.delete_btn]):
            w.grid(row=0, column=i, padx=5, pady=7, sticky="ew")
        self.frame.grid_columnconfigure(1, weight=1)
        for var in [self.ticker, self.name, self.amount]:
            var.trace_add("write", lambda *_: self.app.recalculate_current())

    def pack(self) -> None:
        self.frame.pack(fill="x", padx=8, pady=4)

    def delete(self) -> None:
        self.frame.destroy()
        self.app.rows.remove(self)
        self.app.recalculate_current()

    def set_values(self, ticker: str, name: str, asset_type: str, amount: str, recalc: bool = True) -> None:
        self.ticker.set(ticker)
        self.name.set(name)
        self.asset_type.set(asset_type)
        self.amount.set(amount)
        if recalc:
            self.app.recalculate_current()

    def set_locked_cash(self, locked: bool = True) -> None:
        state = "disabled" if locked else "normal"
        for widget in [self.ticker_entry, self.name_entry, self.type_menu, self.amount_entry, self.delete_btn]:
            try:
                widget.configure(state=state)
            except Exception:
                pass
        if locked:
            self.frame.configure(fg_color="#102a38")
            self.weight_label.configure(text_color="#50ffaf")
        else:
            self.frame.configure(fg_color="#162031")
            self.weight_label.configure(text_color="#d9e3fb")

    def amount_value(self) -> float:
        raw = (self.amount.get() or "0").replace(",", "").strip()
        if not raw:
            return 0.0
        return float(raw)

    def to_asset(self) -> PortfolioAssetInput:
        ticker = normalize_ticker(self.ticker.get().strip())
        if not ticker:
            raise ValueError("비어 있는 티커가 있습니다.")
        amount = self.amount_value()
        if amount <= 0:
            raise ValueError(f"{ticker}: 보유금액은 0보다 커야 합니다.")
        return PortfolioAssetInput(
            ticker=ticker,
            name=(self.name.get().strip() or None),
            asset_type=self.asset_type.get(),
            current_value=amount,
            enabled=True,
        )


class MinimalCTkApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")
        self.title(f"Portfolio Regime Advisor v{APP_VERSION} - Minimal CustomTkinter")
        self.geometry("1380x780")
        self.minsize(1200, 680)
        self.rows: List[PortfolioInputRow] = []
        self.worker_queue: queue.Queue[Tuple[str, Any]] = queue.Queue()
        self.total_value = 0.0
        self.latest_payload: Dict[str, Any] | None = None
        self.cancel_event: threading.Event | None = None
        self.worker_thread: threading.Thread | None = None
        self._auto_cash_syncing = False
        self.user_settings = load_user_settings()
        self.portfolio_slots = load_portfolio_slots()
        self.portfolio_slot_labels: List[str] = self.portfolio_slots.labels()
        self.portfolio_slot_var = ctk.StringVar(value=self.portfolio_slot_labels[0])
        self.portfolio_slot_name = ctk.StringVar(value="")

        self.provider = ctk.StringVar(value=self.user_settings.provider)
        self.risk_profile = ctk.StringVar(value=self.user_settings.risk_profile)
        self.force_update = ctk.BooleanVar(value=self.user_settings.force_update_default)
        self.force_prediction = ctk.BooleanVar(value=self.user_settings.force_prediction_default)
        self.auto_cash_enabled = ctk.BooleanVar(value=bool(getattr(self.user_settings, "auto_cash_enabled", True)))
        self.setting_currency = ctk.StringVar(value=self.user_settings.base_currency)
        self.setting_operating_capital = ctk.StringVar(value=f"{self.user_settings.operating_capital:.0f}")
        self.setting_speed_profile = ctk.StringVar(value=self.user_settings.speed_profile)
        self.setting_prediction_run_mode = ctk.StringVar(value=getattr(self.user_settings, "prediction_run_mode", "latest"))
        self.setting_latest_train_rows = ctk.StringVar(value=str(getattr(self.user_settings, "latest_train_rows", 756)))
        self.setting_model_start_date = ctk.StringVar(value=getattr(self.user_settings, "model_start_date", "1999-03-10"))
        self.setting_model_end_date = ctk.StringVar(value=getattr(self.user_settings, "model_end_date", ""))
        self.setting_model_backtest_start_date = ctk.StringVar(value=getattr(self.user_settings, "model_backtest_start_date", ""))
        self.setting_capital_mode = ctk.StringVar(value=self.user_settings.capital_mode)
        self.setting_transaction_cost_pct = ctk.StringVar(value=f"{self.user_settings.transaction_cost_bps / 100.0:.3f}".rstrip("0").rstrip("."))
        self.setting_min_cash_pct = ctk.StringVar(value=f"{self.user_settings.min_cash_pct:.1f}")
        self.setting_max_asset_pct = ctk.StringVar(value=f"{self.user_settings.max_asset_pct:.1f}")
        self.setting_risk_sensitivity = ctk.StringVar(value=f"{self.user_settings.risk_sensitivity:.2f}")
        self.setting_operating_capital.trace_add("write", lambda *_: self.recalculate_current())
        self.kis_store = KisCredentialStore(AppConfig.from_json().config_dir)
        kis = self.kis_store.load()
        self.kis_app_key = ctk.StringVar(value=kis.app_key)
        self.kis_app_secret = ctk.StringVar(value="")
        self.kis_account_no = ctk.StringVar(value=kis.account_no)
        self.kis_account_product_code = ctk.StringVar(value=kis.account_product_code or "01")
        self.kis_overseas_exchange = ctk.StringVar(value=kis.overseas_exchange or "NAS")
        self.kis_virtual_trade = ctk.BooleanVar(value=bool(kis.virtual_trade))
        self.kis_persist_secret = ctk.BooleanVar(value=True)
        self.kis_status_text = ctk.StringVar(value=self._kis_status_text(kis))
        self.status_text = ctk.StringVar(value="대기 중")
        self.summary_text = ctk.StringVar(value="포트폴리오를 입력한 뒤 분석을 실행하세요.")
        self.progress_text = ctk.StringVar(value="진행 상태: 대기 중")

        self._build_ui()
        self.recalculate_current()
        self.after(200, self._poll_worker_queue)

    def _build_ui(self) -> None:
        self.configure(fg_color="#091324")
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=22, pady=(18, 8))
        ctk.CTkLabel(header, text="Portfolio Regime Advisor", font=ctk.CTkFont(size=24, weight="bold"), text_color="#ceffdf").pack(side="left")
        ctk.CTkLabel(header, textvariable=self.status_text, text_color="#a6c8ff").pack(side="right")

        self.tabs = ctk.CTkTabview(self, fg_color="#0f192a", segmented_button_fg_color="#162031")
        self.tabs.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        self.tab_current = self.tabs.add("현재 포트폴리오")
        self.tab_result = self.tabs.add("모델 추천")
        self.tab_perf = self.tabs.add("포트폴리오 성과")
        self.tab_model_eval = self.tabs.add("모델 평가")
        self.tab_settings = self.tabs.add("사용자 설정")

        self._build_current_tab()
        self._build_result_tab()
        self._build_portfolio_performance_tab()
        self._build_model_evaluation_tab()
        self._build_settings_tab()

    def _build_current_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_current, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)
        left = ctk.CTkFrame(container, fg_color="#111c2d", corner_radius=18)
        right = ctk.CTkFrame(container, fg_color="transparent")
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))
        right.pack(side="right", fill="both", expand=False, padx=(10, 0))

        top = ctk.CTkFrame(left, fg_color="transparent")
        top.pack(fill="x", padx=16, pady=(16, 8))
        ctk.CTkLabel(top, text="보유 포트폴리오 입력", font=ctk.CTkFont(size=18, weight="bold")).pack(side="left")
        ctk.CTkButton(top, text="자산 추가", width=86, command=self.add_row).pack(side="right", padx=(6, 0))
        ctk.CTkButton(top, text="전체 비우기", width=96, fg_color="#2b3548", command=self.clear_rows).pack(side="right", padx=(6, 0))
        self.sort_order_var = ctk.StringVar(value="비중 내림차순")
        ctk.CTkComboBox(
            top,
            values=["비중 내림차순", "비중 오름차순"],
            variable=self.sort_order_var,
            width=128,
            state="readonly",
            command=self.on_sort_order_changed,
        ).pack(side="right", padx=(6, 0))
        ctk.CTkButton(top, text="예시", width=64, fg_color="#2b3548", command=self.load_example).pack(side="right")

        cash_mode = ctk.CTkFrame(left, fg_color="#162031", corner_radius=12)
        cash_mode.pack(fill="x", padx=18, pady=(0, 8))
        ctk.CTkCheckBox(
            cash_mode,
            text="잔여 현금 자동 반영",
            variable=self.auto_cash_enabled,
            command=self.on_auto_cash_toggle,
        ).pack(side="left", padx=12, pady=9)
        ctk.CTkLabel(
            cash_mode,
            text="ON: 운용자금에서 주식/채권 입력액을 뺀 금액을 CASH로 자동 계산 · OFF: CASH를 직접 입력",
            text_color="#909095",
            font=ctk.CTkFont(size=12),
        ).pack(side="left", padx=8, pady=9)

        header = ctk.CTkFrame(left, fg_color="transparent")
        header.pack(fill="x", padx=18, pady=(4, 0))
        labels = [("티커", 90), ("종목명", 130), ("유형", 120), ("보유금액", 130), ("비중", 76), ("", 58)]
        for i, (text, width) in enumerate(labels):
            ctk.CTkLabel(header, text=text, width=width, text_color="#909095").grid(row=0, column=i, padx=5, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        self.rows_frame = ctk.CTkScrollableFrame(left, fg_color="transparent", height=325)
        self.rows_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        slot_box = ctk.CTkFrame(left, fg_color="#162031", corner_radius=12)
        slot_box.pack(fill="x", padx=18, pady=(2, 10))
        ctk.CTkLabel(slot_box, text="포트폴리오 저장", text_color="#d9e3fb", font=ctk.CTkFont(size=13, weight="bold")).grid(row=0, column=0, padx=(12, 8), pady=8, sticky="w")
        self.slot_menu = ctk.CTkOptionMenu(slot_box, values=self.portfolio_slot_labels, variable=self.portfolio_slot_var, width=220)
        self.slot_menu.grid(row=0, column=1, padx=5, pady=8, sticky="ew")
        ctk.CTkEntry(slot_box, textvariable=self.portfolio_slot_name, placeholder_text="저장 이름 선택 입력", width=150).grid(row=0, column=2, padx=5, pady=8, sticky="ew")
        ctk.CTkButton(slot_box, text="저장", width=62, command=self.save_current_portfolio_slot).grid(row=0, column=3, padx=4, pady=8)
        ctk.CTkButton(slot_box, text="불러오기", width=72, fg_color="#2b3548", command=self.load_selected_portfolio_slot).grid(row=0, column=4, padx=4, pady=8)
        ctk.CTkButton(slot_box, text="삭제", width=58, fg_color="#5a1f2a", command=self.clear_selected_portfolio_slot).grid(row=0, column=5, padx=(4, 12), pady=8)
        slot_box.grid_columnconfigure(1, weight=1)
        slot_box.grid_columnconfigure(2, weight=1)

        compact_note = ctk.CTkLabel(
            left,
            text="데이터 소스·위험 성향·실행 기본값은 5번 사용자 설정에서 관리합니다. 포트폴리오는 최대 5개 슬롯에 저장할 수 있습니다.",
            text_color="#909095",
            font=ctk.CTkFont(size=12),
        )
        compact_note.pack(fill="x", padx=18, pady=(0, 16))

        self.current_pie = PieChart(right, "현재 포트폴리오 구성", width=420, height=360)
        self.current_pie.pack(fill="x", pady=(0, 14))
        self.current_summary = ctk.CTkFrame(right, fg_color="#111c2d", corner_radius=18)
        self.current_summary.pack(fill="x")
        self.current_summary_label = ctk.CTkLabel(self.current_summary, text="총 평가금액: 0\n주식 0.00% · 채권 0.00% · 현금 0.00%", justify="left", font=ctk.CTkFont(size=15))
        self.current_summary_label.pack(anchor="w", padx=18, pady=18)
        button_row = ctk.CTkFrame(right, fg_color="transparent")
        button_row.pack(fill="x", pady=(14, 0))
        action_button_font = ctk.CTkFont(size=ACTION_BUTTON_FONT_SIZE, weight="bold")
        self.run_button = ctk.CTkButton(
            button_row,
            text="모델 실행",
            height=ACTION_BUTTON_HEIGHT,
            font=action_button_font,
            corner_radius=ACTION_BUTTON_CORNER_RADIUS,
            command=self.run_pipeline,
        )
        self.run_button.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.cancel_button = ctk.CTkButton(
            button_row,
            text="실행 취소",
            height=ACTION_BUTTON_HEIGHT,
            width=CANCEL_BUTTON_WIDTH,
            font=action_button_font,
            corner_radius=ACTION_BUTTON_CORNER_RADIUS,
            fg_color="#93000a",
            hover_color="#690005",
            state="disabled",
            command=self.cancel_pipeline,
        )
        self.cancel_button.pack(side="right", padx=(6, 0))

    def _build_result_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_result, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)
        top = ctk.CTkFrame(container, fg_color="transparent")
        top.pack(fill="x")
        self.recommended_pie = PieChart(top, "모델 추천 구성", width=420, height=340)
        self.recommended_pie.pack(side="left", fill="both", expand=True, padx=(0, 10))
        summary = ctk.CTkFrame(top, fg_color="#111c2d", corner_radius=18)
        summary.pack(side="right", fill="both", expand=True, padx=(10, 0))
        ctk.CTkLabel(summary, text="요약", font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=18, pady=(18, 8))
        self.summary_label = ctk.CTkLabel(summary, textvariable=self.summary_text, justify="left", anchor="nw", wraplength=430)
        self.summary_label.pack(anchor="nw", fill="both", expand=True, padx=18, pady=(0, 8))
        progress_box = ctk.CTkFrame(summary, fg_color="#162031", corner_radius=12)
        progress_box.pack(fill="x", padx=18, pady=(0, 18))
        ctk.CTkLabel(progress_box, textvariable=self.progress_text, anchor="w", text_color="#a6c8ff", justify="left").pack(fill="x", padx=12, pady=(10, 6))
        self.progress_bar = ctk.CTkProgressBar(progress_box, height=12, progress_color="#50ffaf")
        self.progress_bar.pack(fill="x", padx=12, pady=(0, 10))
        self.progress_bar.set(0)

        result_actions = ctk.CTkFrame(summary, fg_color="transparent")
        result_actions.pack(fill="x", padx=18, pady=(0, 18))
        self.apply_recommendation_button = ctk.CTkButton(
            result_actions,
            text="추천 포트폴리오를 현재 포트폴리오에 적용",
            height=38,
            fg_color="#2b3548",
            state="disabled",
            command=self.apply_recommended_portfolio_to_current,
        )
        self.apply_recommendation_button.pack(fill="x")

        lower = ctk.CTkFrame(container, fg_color="transparent")
        lower.pack(fill="both", expand=True, pady=(16, 0))
        changes = ctk.CTkFrame(lower, fg_color="#111c2d", corner_radius=18)
        signals = ctk.CTkFrame(lower, fg_color="#111c2d", corner_radius=18)
        changes.pack(side="left", fill="both", expand=True, padx=(0, 8))
        signals.pack(side="right", fill="both", expand=True, padx=(8, 0))
        ctk.CTkLabel(changes, text="종목별 늘릴/줄일 금액", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=16, pady=(14, 6))
        ctk.CTkLabel(signals, text="모델 확률", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=16, pady=(14, 6))
        self.changes_frame = ctk.CTkScrollableFrame(changes, fg_color="transparent")
        self.changes_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.signals_frame = ctk.CTkScrollableFrame(signals, fg_color="transparent")
        self.signals_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _build_portfolio_performance_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_perf, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)

        top = ctk.CTkFrame(container, fg_color="#111c2d", corner_radius=18)
        top.pack(fill="both", expand=True)
        ctk.CTkLabel(top, text="포트폴리오 성과", font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=18, pady=(16, 8))
        ctk.CTkLabel(
            top,
            text="기본 실행(latest)에서는 포트폴리오 추천/현재 포트폴리오 비교 중심으로 표시합니다. 정밀 백테스트 모드에서는 과거 검증 성과까지 함께 해석할 수 있습니다.",
            text_color="#909095",
            wraplength=900,
            justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 8))
        self.portfolio_perf_frame = ctk.CTkScrollableFrame(top, fg_color="transparent", height=285)
        self.portfolio_perf_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.equity_chart = LineChart(container, "추천 포트폴리오 성과 곡선", height=260)
        self.equity_chart.pack(fill="x", pady=(16, 0))

    def _build_model_evaluation_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_model_eval, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)

        box = ctk.CTkFrame(container, fg_color="#111c2d", corner_radius=18)
        box.pack(fill="both", expand=True)
        ctk.CTkLabel(box, text="모델 평가", font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=18, pady=(16, 8))
        ctk.CTkLabel(
            box,
            text="모델 성능 지표는 예측 방식이 walk_forward일 때 표시합니다. latest 모드는 최신 추천 비중 산출용이므로 백테스트 성능 지표를 만들지 않습니다.",
            text_color="#909095",
            wraplength=900,
            justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 8))
        self.model_perf_frame = ctk.CTkScrollableFrame(box, fg_color="transparent", height=520)
        self.model_perf_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _build_settings_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_settings, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=10, pady=10)

        left = ctk.CTkFrame(container, fg_color="#111c2d", corner_radius=18)
        right = ctk.CTkFrame(container, fg_color="#111c2d", corner_radius=18)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right.pack(side="right", fill="both", expand=True, padx=(8, 0))

        ctk.CTkLabel(left, text="기본 사용자 설정", font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=18, pady=(16, 8))
        form = ctk.CTkFrame(left, fg_color="transparent")
        form.pack(fill="x", padx=18, pady=(0, 10))
        self._settings_entry(form, 0, "기준 통화", self.setting_currency, "KRW")
        self._settings_entry(form, 1, "운용자금", self.setting_operating_capital, "10000000")
        self._settings_option(form, 2, "위험 성향", self.risk_profile, RISK_PROFILES)
        self._settings_option(form, 3, "데이터 소스", self.provider, PROVIDERS)
        self._settings_option(form, 4, "실행 속도", self.setting_speed_profile, SPEED_PROFILES)
        self._settings_option(form, 5, "예측 방식", self.setting_prediction_run_mode, PREDICTION_RUN_MODES)
        self._settings_option(form, 6, "자본 배분 방식", self.setting_capital_mode, CAPITAL_MODES)
        self._settings_entry(form, 7, "최근 학습 윈도우(일)", self.setting_latest_train_rows, "504~2520, 기본 756")
        self._settings_entry(form, 8, "학습 시작일", self.setting_model_start_date, "1999-03-10")
        self._settings_entry(form, 9, "예측 시작일", self.setting_model_backtest_start_date, "비우면 기본값 (예: 2020-01-02)")
        self._settings_entry(form, 10, "예측 종료일", self.setting_model_end_date, "비우면 최신일까지 (예: 2026-06-09)")
        self._settings_entry(form, 11, "거래비용 %", self.setting_transaction_cost_pct, "0.1")
        self._settings_entry(form, 12, "최소 현금 비중 %", self.setting_min_cash_pct, "0")
        self._settings_entry(form, 13, "종목 최대 비중 %", self.setting_max_asset_pct, "100")
        self._settings_entry(form, 14, "위험 민감도", self.setting_risk_sensitivity, "1.0")

        check_row = ctk.CTkFrame(left, fg_color="#162031", corner_radius=12)
        check_row.pack(fill="x", padx=18, pady=(0, 12))
        ctk.CTkCheckBox(check_row, text="잔여 현금 자동 반영", variable=self.auto_cash_enabled, command=self.on_auto_cash_toggle).pack(side="left", padx=12, pady=10)
        ctk.CTkCheckBox(check_row, text="기본값: 최신 주가 다시 받기", variable=self.force_update).pack(side="left", padx=12, pady=10)
        ctk.CTkCheckBox(check_row, text="기본값: 예측 결과 새로 만들기", variable=self.force_prediction).pack(side="left", padx=12, pady=10)

        btns = ctk.CTkFrame(left, fg_color="transparent")
        btns.pack(fill="x", padx=18, pady=(0, 18))
        ctk.CTkButton(btns, text="설정 저장", command=self.save_settings_from_ui).pack(side="left", padx=(0, 8))
        ctk.CTkButton(btns, text="설정 다시 불러오기", fg_color="#2b3548", command=self.reload_settings_to_ui).pack(side="left", padx=8)
        ctk.CTkButton(btns, text="기본값 복원", fg_color="#2b3548", command=self.reset_user_settings).pack(side="left", padx=8)

        ctk.CTkLabel(right, text="KIS API 설정", font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=18, pady=(16, 8))
        kis_form = ctk.CTkFrame(right, fg_color="transparent")
        kis_form.pack(fill="x", padx=18, pady=(0, 10))
        self._settings_entry(kis_form, 0, "KIS App Key", self.kis_app_key, "app key")
        self._settings_entry(kis_form, 1, "KIS App Secret", self.kis_app_secret, "비워두면 기존 secret 유지", show="*")
        self._settings_entry(kis_form, 2, "계좌번호 선택", self.kis_account_no, "선택: 시세조회만 할 경우 공란 가능")
        self._settings_entry(kis_form, 3, "상품코드", self.kis_account_product_code, "01")
        self._settings_entry(kis_form, 4, "해외거래소", self.kis_overseas_exchange, "NAS")
        ctk.CTkCheckBox(kis_form, text="모의투자 서버 사용", variable=self.kis_virtual_trade).grid(row=5, column=0, columnspan=2, sticky="w", pady=5)
        ctk.CTkCheckBox(kis_form, text="로컬 설정 파일에 secret 저장", variable=self.kis_persist_secret).grid(row=6, column=0, columnspan=2, sticky="w", pady=5)
        ctk.CTkLabel(kis_form, textvariable=self.kis_status_text, text_color="#a6c8ff", wraplength=420, justify="left").grid(row=7, column=0, columnspan=2, sticky="w", pady=(6, 8))
        kis_btns = ctk.CTkFrame(right, fg_color="transparent")
        kis_btns.pack(fill="x", padx=18, pady=(0, 12))
        ctk.CTkButton(kis_btns, text="KIS 키 저장", command=self.save_kis_settings_from_ui).pack(side="left", padx=(0, 8))
        ctk.CTkButton(kis_btns, text="KIS 상태 새로고침", fg_color="#2b3548", command=self.refresh_kis_status).pack(side="left", padx=8)
        ctk.CTkButton(kis_btns, text="KIS 키 삭제", fg_color="#5a1f2a", command=self.clear_kis_settings).pack(side="left", padx=8)

        ctk.CTkLabel(right, text="포트폴리오 반영 도구", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=18, pady=(4, 8))
        actions = ctk.CTkFrame(right, fg_color="transparent")
        actions.pack(fill="x", padx=18, pady=(0, 12))
        ctk.CTkButton(actions, text="현재 입력 합계를 운용자금으로 저장", fg_color="#2b3548", command=self.save_current_total_as_setting).pack(fill="x", pady=5)
        ctk.CTkButton(actions, text="운용자금 기준 예시 포트폴리오 로드", fg_color="#2b3548", command=self.load_example).pack(fill="x", pady=5)
        ctk.CTkButton(actions, text="잔여 현금 다시 계산", fg_color="#2b3548", command=self.recalculate_current).pack(fill="x", pady=5)

        help_box = ctk.CTkTextbox(right, height=230, fg_color="#162031", wrap="word")
        help_box.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        help_box.insert("1.0", (
            "설정 설명\n\n"
            "· 데이터 소스 auto: KIS API를 우선 시도하고 실패하면 Yahoo Finance로 전환합니다.\n"
            "· KIS 키는 storage/config/kis_config.json에 로컬 저장됩니다. 공유·깃 커밋·캡처 전송을 피하세요.\n"
            "· App Secret을 비워두고 저장하면 기존 secret을 유지합니다. 삭제 버튼을 누르면 저장된 키와 토큰 캐시를 제거합니다.\n"
            "· 위험 성향: 모델 확률은 바꾸지 않고 추천 비중 변환 단계에서만 보수/균형/공격 성향을 반영합니다.\n"
            "· 운용자금은 전체 투자 가능 금액입니다. 잔여 현금 자동 반영이 켜져 있으면 주식/채권 금액을 뺀 잔액을 CASH 행에 자동 반영합니다.\n"
            "· 잔여 현금 자동 반영을 끄면 CASH 행을 사용자가 직접 입력할 수 있습니다. 이 경우 주식/채권 입력액이 운용자금을 넘어도 자동 차단하지 않습니다.\n"
        ))
        help_box.configure(state="disabled")

    def _settings_entry(self, parent: ctk.CTkFrame, row: int, label: str, variable: ctk.StringVar, placeholder: str, show: str | None = None) -> None:
        ctk.CTkLabel(parent, text=label, text_color="#909095", width=140, anchor="w").grid(row=row, column=0, sticky="w", padx=(0, 8), pady=5)
        ctk.CTkEntry(parent, textvariable=variable, placeholder_text=placeholder, show=show).grid(row=row, column=1, sticky="ew", pady=5)
        parent.grid_columnconfigure(1, weight=1)

    def _settings_option(self, parent: ctk.CTkFrame, row: int, label: str, variable: ctk.StringVar, values: List[str]) -> None:
        ctk.CTkLabel(parent, text=label, text_color="#909095", width=140, anchor="w").grid(row=row, column=0, sticky="w", padx=(0, 8), pady=5)
        ctk.CTkOptionMenu(parent, values=values, variable=variable).grid(row=row, column=1, sticky="ew", pady=5)
        parent.grid_columnconfigure(1, weight=1)

    def add_row(self) -> PortfolioInputRow:
        row = PortfolioInputRow(self, self.rows_frame)
        row.pack()
        self.rows.append(row)
        self.recalculate_current()
        return row

    def clear_rows(self) -> None:
        for row in list(self.rows):
            row.frame.destroy()
        self.rows.clear()
        self.latest_payload = None
        self.recalculate_current()
        self.clear_result_view()

    def _destroy_all_input_rows(self) -> None:
        """Remove current input rows without clearing the latest model result view."""
        for row in list(self.rows):
            try:
                row.frame.destroy()
            except Exception:
                pass
        self.rows.clear()

    def _append_input_row(self, ticker: str, name: str, asset_type: str, amount: float | str, recalc: bool = False) -> PortfolioInputRow:
        row = PortfolioInputRow(self, self.rows_frame)
        row.pack()
        self.rows.append(row)
        row.set_values(str(ticker), str(name or ""), str(asset_type or "stock"), f"{float(amount):.0f}", recalc=recalc)
        return row

    def on_sort_order_changed(self, choice: str) -> None:
        """Sort handler for the combined ascending/descending combobox."""
        descending = str(choice).strip() != "비중 오름차순"
        self.sort_current_portfolio_by_weight(descending=descending)

    def sort_current_portfolio_by_weight(self, show_message: bool = True, descending: bool = True) -> None:
        """Sort visible portfolio rows by current amount.

        ``descending=True`` sorts large positions first. ``descending=False``
        sorts small positions first. When auto cash is enabled, the calculated
        CASH row remains at the bottom. When auto cash is disabled, CASH is
        treated as a user-managed row and sorted by amount like the other rows.
        """
        if not self.rows:
            return
        if self._auto_cash_enabled_value():
            sortable_rows = [row for row in self.rows if not self._is_cash_row(row)]
            tail_rows = [row for row in self.rows if self._is_cash_row(row)]
        else:
            sortable_rows = list(self.rows)
            tail_rows = []
        if not sortable_rows:
            if show_message:
                messagebox.showinfo("비중 정렬", "정렬할 자산이 없습니다.")
            return
        sortable_rows.sort(key=lambda r: self._safe_row_amount(r), reverse=bool(descending))
        self.rows = sortable_rows + tail_rows
        for row in self.rows:
            try:
                row.frame.pack_forget()
            except Exception:
                pass
            row.pack()
        self.recalculate_current()
        if hasattr(self, "sort_order_var"):
            try:
                self.sort_order_var.set("비중 내림차순" if descending else "비중 오름차순")
            except Exception:
                pass
        if show_message:
            direction = "내림차순" if descending else "오름차순"
            self.status_text.set(f"비중 {direction} 정렬 완료")

    def load_example(self) -> None:
        self.clear_rows()
        try:
            target_total = max(float((self.setting_operating_capital.get() or "0").replace(",", "")), 0.0)
        except Exception:
            target_total = 10_000_000.0
        base_total = EXAMPLE_BASE_OPERATING_CAPITAL
        scale = target_total / base_total if target_total > 0 else 1.0
        for ticker, name, asset_type, amount in EXAMPLE_ROWS:
            row = self.add_row()
            row.set_values(ticker, name, asset_type, f"{float(amount) * scale:.0f}")
        self.recalculate_current()

    def _selected_slot_id(self) -> int:
        label = self.portfolio_slot_var.get() or ""
        try:
            if label.startswith("슬롯 "):
                return int(label.split(":", 1)[0].replace("슬롯", "").strip())
        except Exception:
            pass
        # Fallback to current menu index if label parsing failed.
        try:
            return self.portfolio_slot_labels.index(label) + 1
        except Exception:
            return 1

    def _refresh_portfolio_slot_menu(self, keep_slot_id: int | None = None) -> None:
        self.portfolio_slots = load_portfolio_slots()
        self.portfolio_slot_labels = self.portfolio_slots.labels()
        if hasattr(self, "slot_menu"):
            self.slot_menu.configure(values=self.portfolio_slot_labels)
        sid = int(keep_slot_id or min(max(self._selected_slot_id(), 1), MAX_PORTFOLIO_SLOTS))
        self.portfolio_slot_var.set(self.portfolio_slot_labels[sid - 1])

    def _collect_slot_assets(self) -> List[PortfolioSlotAsset]:
        assets: List[PortfolioSlotAsset] = []
        for row in self.rows:
            if self._auto_cash_enabled_value() and self._is_cash_row(row):
                continue
            raw_ticker = self._row_ticker_text(row)
            amount = row.amount_value()
            if not raw_ticker and amount <= 0:
                continue
            if not raw_ticker:
                raise ValueError("저장할 수 없는 빈 티커 행이 있습니다. 필요 없는 행은 삭제하세요.")
            if amount <= 0:
                continue
            try:
                ticker = normalize_ticker(raw_ticker)
            except Exception as exc:
                raise ValueError(f"저장할 수 없는 티커 형식입니다: {raw_ticker}") from exc
            assets.append(PortfolioSlotAsset(
                ticker=ticker,
                name=row.name.get().strip(),
                asset_type=row.asset_type.get(),
                amount=amount,
            ))
        return assets

    def save_current_portfolio_slot(self) -> None:
        try:
            self.recalculate_current()
            sid = self._selected_slot_id()
            assets = self._collect_slot_assets()
            if not assets:
                raise ValueError("저장할 자산이 없습니다. 자동 현금 반영이 켜진 경우 CASH는 저장하지 않습니다.")
            name = (self.portfolio_slot_name.get() or "").strip()
            if not name:
                name = "/".join([a.ticker for a in assets[:3]])
                if len(assets) > 3:
                    name += "..."
            slot = PortfolioSlot(
                slot_id=sid,
                name=name,
                operating_capital=self._operating_capital_value(),
                assets=assets,
                saved_at=slot_utc_now_iso(),
            )
            self.portfolio_slots.set(slot)
            path = save_portfolio_slots(self.portfolio_slots)
            self._refresh_portfolio_slot_menu(keep_slot_id=sid)
            messagebox.showinfo("포트폴리오 저장", f"슬롯 {sid}에 포트폴리오를 저장했습니다.\n{path}")
        except Exception as exc:
            messagebox.showerror("포트폴리오 저장 오류", str(exc))

    def load_selected_portfolio_slot(self) -> None:
        sid = self._selected_slot_id()
        self._refresh_portfolio_slot_menu(keep_slot_id=sid)
        slot = self.portfolio_slots.get(sid)
        if slot.is_empty():
            messagebox.showinfo("포트폴리오 불러오기", f"슬롯 {sid}은 비어 있습니다.")
            return
        if not messagebox.askyesno("포트폴리오 불러오기", f"현재 입력값을 슬롯 {sid}의 저장 포트폴리오로 교체할까요?"):
            return
        self.clear_rows()
        if slot.operating_capital > 0:
            self.setting_operating_capital.set(f"{slot.operating_capital:.0f}")
            try:
                self.save_settings_from_ui(silent=True)
            except Exception:
                pass
        for asset in slot.assets:
            row = self.add_row()
            row.set_values(asset.ticker, asset.name, asset.asset_type, f"{asset.amount:.0f}", recalc=False)
        self.portfolio_slot_name.set(slot.name)
        self.recalculate_current()
        messagebox.showinfo("포트폴리오 불러오기", f"슬롯 {sid} 포트폴리오를 불러왔습니다.")

    def clear_selected_portfolio_slot(self) -> None:
        sid = self._selected_slot_id()
        self._refresh_portfolio_slot_menu(keep_slot_id=sid)
        slot = self.portfolio_slots.get(sid)
        if slot.is_empty():
            messagebox.showinfo("포트폴리오 삭제", f"슬롯 {sid}은 이미 비어 있습니다.")
            return
        if not messagebox.askyesno("포트폴리오 삭제", f"슬롯 {sid}의 저장 포트폴리오를 삭제할까요?"):
            return
        self.portfolio_slots.clear(sid)
        path = save_portfolio_slots(self.portfolio_slots)
        self.portfolio_slot_name.set("")
        self._refresh_portfolio_slot_menu(keep_slot_id=sid)
        messagebox.showinfo("포트폴리오 삭제", f"슬롯 {sid}을 비웠습니다.\n{path}")

    def _kis_status_text(self, kis: KisSettings | None = None) -> str:
        try:
            kis = kis or self.kis_store.load()
            redacted = kis.redacted()
            mode = "모의투자" if kis.virtual_trade else "실전투자"
            configured = "설정됨" if redacted.get("configured") else "미설정"
            return f"KIS 상태: {configured} · {mode} · app_key={redacted.get('app_key') or '-'} · exchange={kis.overseas_exchange or '-'}"
        except Exception as exc:
            return f"KIS 상태 확인 실패: {exc}"

    def refresh_kis_status(self) -> None:
        self.kis_status_text.set(self._kis_status_text())

    def save_kis_settings_from_ui(self) -> None:
        try:
            existing = self.kis_store.load()
            app_key = (self.kis_app_key.get() or "").strip()
            app_secret = (self.kis_app_secret.get() or "").strip() or existing.app_secret
            if not app_key:
                raise ValueError("KIS App Key를 입력하세요.")
            if not app_secret and self.kis_persist_secret.get():
                raise ValueError("KIS App Secret을 입력하세요. 기존 secret이 있으면 비워둘 수 있습니다.")
            base_url = "https://openapivts.koreainvestment.com:29443" if self.kis_virtual_trade.get() else "https://openapi.koreainvestment.com:9443"
            settings = KisSettings(
                app_key=app_key,
                app_secret=app_secret,
                base_url=base_url,
                virtual_trade=bool(self.kis_virtual_trade.get()),
                account_no=(self.kis_account_no.get() or "").strip(),
                account_product_code=(self.kis_account_product_code.get() or "01").strip() or "01",
                overseas_exchange=(self.kis_overseas_exchange.get() or "NAS").strip().upper() or "NAS",
                custtype="P",
                access_token="",
            )
            path = self.kis_store.save(settings, persist_secret=bool(self.kis_persist_secret.get()))
            self.kis_app_secret.set("")
            self.refresh_kis_status()
            messagebox.showinfo(
                "KIS 설정 저장",
                "KIS API 설정을 로컬에 저장했습니다.\n"
                f"저장 위치: {path}\n\n"
                "보안 주의: 이 파일을 깃허브/메신저/캡처로 공유하지 마세요.",
            )
        except Exception as exc:
            messagebox.showerror("KIS 설정 오류", str(exc))

    def clear_kis_settings(self) -> None:
        if not messagebox.askyesno("KIS 키 삭제", "저장된 KIS 키와 토큰 캐시를 삭제할까요?"):
            return
        try:
            for path in [self.kis_store.config_path, self.kis_store.token_path]:
                if path.exists():
                    path.unlink()
            self.kis_app_key.set("")
            self.kis_app_secret.set("")
            self.kis_account_no.set("")
            self.kis_account_product_code.set("01")
            self.kis_overseas_exchange.set("NAS")
            self.kis_virtual_trade.set(False)
            self.refresh_kis_status()
            messagebox.showinfo("KIS 키 삭제", "저장된 KIS 설정을 삭제했습니다.")
        except Exception as exc:
            messagebox.showerror("KIS 삭제 오류", str(exc))

    def _collect_user_settings(self) -> UserSettings:
        def f(var: ctk.StringVar, default: float) -> float:
            raw = (var.get() or "").replace(",", "").strip()
            return float(raw) if raw else default
        def transaction_cost_bps_from_percent() -> float:
            # User-facing input is percent, e.g. 0.1 = 0.1 percent = 10 bps.
            raw = (self.setting_transaction_cost_pct.get() or "").replace(",", "").replace("%", "").strip()
            pct = float(raw) if raw else 0.1
            return pct * 100.0
        def i(var: ctk.StringVar, default: int) -> int:
            raw = (var.get() or "").replace(",", "").strip()
            return int(float(raw)) if raw else default
        return UserSettings(
            base_currency=self.setting_currency.get().strip() or "KRW",
            operating_capital=f(self.setting_operating_capital, 10_000_000.0),
            risk_profile=self.risk_profile.get(),
            provider=self.provider.get(),
            speed_profile=self.setting_speed_profile.get(),
            prediction_run_mode=self.setting_prediction_run_mode.get(),
            latest_train_rows=i(self.setting_latest_train_rows, 756),
            model_start_date=self.setting_model_start_date.get().strip() or "1999-03-10",
            model_end_date=self.setting_model_end_date.get().strip(),
            model_backtest_start_date=self.setting_model_backtest_start_date.get().strip(),
            capital_mode=self.setting_capital_mode.get(),
            auto_cash_enabled=bool(self.auto_cash_enabled.get()),
            force_update_default=bool(self.force_update.get()),
            force_prediction_default=bool(self.force_prediction.get()),
            transaction_cost_bps=transaction_cost_bps_from_percent(),
            min_cash_pct=f(self.setting_min_cash_pct, 0.0),
            max_asset_pct=f(self.setting_max_asset_pct, 100.0),
            risk_sensitivity=f(self.setting_risk_sensitivity, 1.0),
        ).normalized()

    def _apply_user_settings_to_vars(self, settings: UserSettings) -> None:
        settings = settings.normalized()
        self.user_settings = settings
        self.setting_currency.set(settings.base_currency)
        self.setting_operating_capital.set(f"{settings.operating_capital:.0f}")
        self.risk_profile.set(settings.risk_profile)
        self.provider.set(settings.provider)
        self.setting_speed_profile.set(settings.speed_profile)
        self.setting_prediction_run_mode.set(getattr(settings, "prediction_run_mode", "latest"))
        self.setting_latest_train_rows.set(str(getattr(settings, "latest_train_rows", 756)))
        self.setting_model_start_date.set(getattr(settings, "model_start_date", "1999-03-10"))
        self.setting_model_end_date.set(getattr(settings, "model_end_date", ""))
        self.setting_model_backtest_start_date.set(getattr(settings, "model_backtest_start_date", ""))
        self.setting_capital_mode.set(settings.capital_mode)
        self.auto_cash_enabled.set(bool(getattr(settings, "auto_cash_enabled", True)))
        self.force_update.set(settings.force_update_default)
        self.force_prediction.set(settings.force_prediction_default)
        self.setting_transaction_cost_pct.set(f"{settings.transaction_cost_bps / 100.0:.3f}".rstrip("0").rstrip("."))
        self.setting_min_cash_pct.set(f"{settings.min_cash_pct:.1f}")
        self.setting_max_asset_pct.set(f"{settings.max_asset_pct:.1f}")
        self.setting_risk_sensitivity.set(f"{settings.risk_sensitivity:.2f}")

    def save_settings_from_ui(self, silent: bool = False) -> None:
        try:
            settings = self._collect_user_settings()
            path = save_user_settings(settings)
            self._apply_user_settings_to_vars(settings)
            self.recalculate_current()
            if not silent:
                messagebox.showinfo("설정 저장", f"사용자 설정을 저장했습니다.\n{path}")
        except Exception as exc:
            if not silent:
                messagebox.showerror("설정 오류", str(exc))
            else:
                raise

    def reload_settings_to_ui(self) -> None:
        self._apply_user_settings_to_vars(load_user_settings())
        self.recalculate_current()
        messagebox.showinfo("설정 불러오기", "저장된 사용자 설정을 다시 불러왔습니다.")

    def reset_user_settings(self) -> None:
        self._apply_user_settings_to_vars(UserSettings())
        save_user_settings(self.user_settings)
        self.recalculate_current()
        messagebox.showinfo("기본값 복원", "사용자 설정을 기본값으로 복원했습니다.")

    def save_current_total_as_setting(self) -> None:
        self.setting_operating_capital.set(f"{self.total_value:.0f}")
        self.save_settings_from_ui(silent=True)
        messagebox.showinfo("운용자금 저장", f"현재 입력 포트폴리오 합계 {self.total_value:,.0f}을 운용자금으로 저장했습니다.")

    def _operating_capital_value(self) -> float:
        try:
            raw = (self.setting_operating_capital.get() or "0").replace(",", "").strip()
            return max(float(raw) if raw else 0.0, 0.0)
        except Exception:
            return 0.0

    def _auto_cash_enabled_value(self) -> bool:
        try:
            return bool(self.auto_cash_enabled.get())
        except Exception:
            return True

    def on_auto_cash_toggle(self) -> None:
        """Switch between automatic residual cash and manually entered cash."""
        if self._auto_cash_enabled_value():
            self.status_text.set("잔여 현금 자동 반영 ON")
        else:
            self.status_text.set("잔여 현금 자동 반영 OFF")
            for row in self.rows:
                if self._is_cash_row(row):
                    row.set_locked_cash(False)
                    if self._row_ticker_text(row) in {"CASH", "CASH_BUCKET"} and (row.name.get() or "").strip() == "자동 현금":
                        row.name.set("현금")
        self.recalculate_current()

    def _row_ticker_text(self, row: PortfolioInputRow) -> str:
        """Return upper-cased ticker text without validation.

        UI callbacks run while a row is still blank or partially typed. Calling
        normalize_ticker() in those paths can raise and break save/load/recalc.
        Validation is intentionally deferred to request building or slot saving.
        """
        try:
            return (row.ticker.get() or "").strip().upper()
        except Exception:
            return ""

    def _safe_row_amount(self, row: PortfolioInputRow) -> float:
        try:
            return max(float(row.amount_value()), 0.0)
        except Exception:
            return 0.0

    def _is_bond_row(self, row: PortfolioInputRow) -> bool:
        ticker = self._row_ticker_text(row)
        asset_type = (row.asset_type.get() or "").strip()
        return ticker == "BOND_BUCKET" or asset_type in {"bond", "bond_etf", "bond_bucket"}

    def _is_cash_row(self, row: PortfolioInputRow) -> bool:
        ticker = self._row_ticker_text(row)
        asset_type = (row.asset_type.get() or "").strip()
        return ticker in {"CASH", "CASH_BUCKET"} or asset_type in {"cash", "cash_bucket"}

    def _ensure_auto_cash_row(self) -> PortfolioInputRow:
        cash_rows = [row for row in self.rows if self._is_cash_row(row)]
        target = cash_rows[0] if cash_rows else None
        for extra in cash_rows[1:]:
            try:
                extra.frame.destroy()
            except Exception:
                pass
            if extra in self.rows:
                self.rows.remove(extra)
        if target is None:
            target = PortfolioInputRow(self, self.rows_frame)
            self.rows.append(target)
        target.set_values("CASH", "자동 현금", "cash", target.amount.get() or "0", recalc=False)
        target.set_locked_cash(True)
        # Keep the calculated CASH row visually at the bottom even after users add
        # new rows or load a saved slot.
        try:
            target.frame.pack_forget()
        except Exception:
            pass
        target.pack()
        return target

    def _non_cash_input_total(self) -> float:
        total = 0.0
        for row in self.rows:
            if self._is_cash_row(row):
                continue
            try:
                total += max(row.amount_value(), 0.0)
            except Exception:
                pass
        return total

    def recalculate_current(self) -> None:
        if getattr(self, "_auto_cash_syncing", False):
            return
        auto_cash_on = self._auto_cash_enabled_value()
        self._auto_cash_syncing = True
        try:
            operating_capital = self._operating_capital_value()
            non_cash_total = self._non_cash_input_total()
            if auto_cash_on:
                auto_cash = max(operating_capital - non_cash_total, 0.0)
                cash_row = self._ensure_auto_cash_row()
                cash_row.amount.set(f"{auto_cash:.0f}")
            else:
                for row in self.rows:
                    if self._is_cash_row(row):
                        row.set_locked_cash(False)
                        if self._row_ticker_text(row) in {"CASH", "CASH_BUCKET"} and (row.name.get() or "").strip() == "자동 현금":
                            row.name.set("현금")
        finally:
            self._auto_cash_syncing = False

        total = 0.0
        rows_and_amounts: List[Tuple[PortfolioInputRow, float]] = []
        for row in self.rows:
            try:
                amount = row.amount_value()
            except Exception:
                amount = 0.0
            rows_and_amounts.append((row, max(amount, 0.0)))
            total += max(amount, 0.0)
        self.total_value = total
        asset_pie: List[Tuple[str, float]] = []
        stock = bond = cash = 0.0
        for row, amount in rows_and_amounts:
            weight = amount / total if total > 0 else 0.0
            row.weight.set(f"{weight * 100:.2f}%")
            raw_ticker = self._row_ticker_text(row)
            try:
                ticker = normalize_ticker(raw_ticker) if raw_ticker else "-"
            except Exception:
                ticker = raw_ticker or "-"
            asset_type = row.asset_type.get()
            asset_pie.append((ticker, weight))
            if asset_type in {"cash", "cash_bucket"} or ticker in {"CASH", "CASH_BUCKET"}:
                cash += weight
            elif asset_type in {"bond", "bond_etf", "bond_bucket"} or ticker == "BOND_BUCKET":
                bond += weight
            else:
                stock += weight
        self.current_pie.set_data(asset_pie)
        operating_capital = self._operating_capital_value()
        non_cash_total = self._non_cash_input_total()
        cash_amount = sum(amount for row, amount in rows_and_amounts if self._is_cash_row(row))
        warning = ""
        cash_mode_text = "자동 현금" if auto_cash_on else "수동 현금"
        if auto_cash_on and operating_capital > 0 and non_cash_total > operating_capital + 1e-6:
            warning = f"\n⚠ 주식/채권 입력금액이 운용자금을 {non_cash_total - operating_capital:,.0f} 초과했습니다."
        elif (not auto_cash_on) and operating_capital > 0 and abs(total - operating_capital) > 1e-6:
            warning = f"\n참고: 입력 합계와 운용자금 차이 {total - operating_capital:,.0f}"
        self.current_summary_label.configure(
            text=(
                f"운용자금: {operating_capital:,.0f}\n"
                f"입력 주식/채권: {non_cash_total:,.0f} · {cash_mode_text}: {cash_amount:,.0f}\n"
                f"분석 기준 총액: {total:,.0f}\n"
                f"주식 {stock*100:.2f}% · 채권 {bond*100:.2f}% · 현금 {cash*100:.2f}%"
                f"{warning}"
            )
        )

    def build_request(self) -> PortfolioEvaluateRequest:
        self.recalculate_current()
        operating_capital = self._operating_capital_value()
        non_cash_total = self._non_cash_input_total()
        if operating_capital <= 0:
            raise ValueError("사용자 설정의 운용자금은 0보다 커야 합니다.")
        if self._auto_cash_enabled_value() and non_cash_total > operating_capital + 1e-6:
            raise ValueError(
                f"주식/채권 입력금액이 운용자금을 초과했습니다. "
                f"운용자금={operating_capital:,.0f}, 입력 주식/채권={non_cash_total:,.0f}"
            )
        assets = [row.to_asset() for row in self.rows]
        if not assets:
            raise ValueError("포트폴리오 자산을 1개 이상 입력해야 합니다.")
        if not any(a.is_risk_asset for a in assets):
            raise ValueError("모델 실행 대상인 주식/ETF/risk_asset 자산이 최소 1개 필요합니다.")
        user_settings = self._collect_user_settings()
        settings = EvaluateSettings(
            start_date=user_settings.model_start_date,
            end_date=(user_settings.model_end_date or None),
            backtest_start_date=(user_settings.model_backtest_start_date or None),
            update_data=True,
            generate_predictions=True,
            force_update=bool(self.force_update.get()),
            force_prediction=bool(self.force_prediction.get()),
            provider=user_settings.provider,
            prediction_engine_mode="external_v8641_xgb",
            prediction_run_mode=user_settings.prediction_run_mode,
            latest_train_rows=user_settings.latest_train_rows,
            speed_profile=user_settings.speed_profile,
            capital_mode=user_settings.capital_mode,
            transaction_cost_bps=user_settings.transaction_cost_bps,
            min_cash_weight=user_settings.min_cash_pct / 100.0,
            max_asset_weight=user_settings.max_asset_pct / 100.0,
            risk_sensitivity=user_settings.risk_sensitivity,
        )
        return PortfolioEvaluateRequest(
            portfolio=assets,
            risk_profile=user_settings.risk_profile,
            user_level="general",
            settings=settings,
        )

    def _current_risk_tickers(self) -> set[str]:
        tickers: set[str] = set()
        for row in self.rows:
            if self._is_cash_row(row) or self._is_bond_row(row):
                continue
            ticker = self._row_ticker_text(row)
            if ticker:
                tickers.add(ticker)
        return tickers

    def apply_recommended_portfolio_to_current(self) -> None:
        """Replace current input amounts with the latest model recommendation.

        The recommendation payload contains stock/risk-asset rows plus aggregate
        bond/cash weights. When auto cash is enabled, CASH is calculated from
        operating capital. When disabled, recommended CASH is written as a
        normal editable row.
        """
        if not self.latest_payload:
            messagebox.showinfo("추천 적용", "먼저 모델 예측을 실행해 추천 포트폴리오를 생성하세요.")
            return
        allocation = self.latest_payload.get("allocation", {}) or {}
        rows = allocation.get("allocation_rows", []) or []
        totals = allocation.get("portfolio_totals", {}) or {}
        if not rows and not totals:
            messagebox.showerror("추천 적용 오류", "적용할 추천 포트폴리오 데이터가 없습니다.")
            return
        target_total = self._operating_capital_value() or self.total_value
        if target_total <= 0:
            messagebox.showerror("추천 적용 오류", "운용자금이 0보다 커야 추천 포트폴리오를 적용할 수 있습니다.")
            return

        existing: Dict[str, PortfolioInputRow] = {self._row_ticker_text(r): r for r in self.rows if self._row_ticker_text(r)}
        rec_tickers = {str(r.get("ticker") or "").upper() for r in rows if r.get("ticker")}
        current_tickers = self._current_risk_tickers()
        mismatch_note = ""
        if current_tickers and rec_tickers and current_tickers != rec_tickers:
            mismatch_note = (
                "\n\n주의: 현재 입력 티커와 최근 추천 결과 티커가 다릅니다. "
                "적용하면 최근 추천 결과 기준으로 현재 포트폴리오 입력값이 교체됩니다."
            )

        stock_weight = float(totals.get("stock_weight") or 0.0)
        bond_weight = float(totals.get("bond_weight") or 0.0)
        cash_weight = float(totals.get("cash_weight") or 0.0)
        ok = messagebox.askyesno(
            "추천 포트폴리오 적용",
            (
                "모델 추천 비중을 현재 포트폴리오 입력값으로 적용할까요?\n\n"
                f"기준 운용자금: {target_total:,.0f}\n"
                f"추천 구성: 주식 {stock_weight*100:.2f}% · 채권 {bond_weight*100:.2f}% · 현금 {cash_weight*100:.2f}%"
                f"{mismatch_note}"
            ),
        )
        if not ok:
            return

        new_assets: List[Tuple[str, str, str, float]] = []
        for r in rows:
            ticker = str(r.get("ticker") or "").upper().strip()
            if not ticker:
                continue
            weight = max(float(r.get("recommended_weight") or 0.0), 0.0)
            amount = round(weight * target_total)
            if amount <= 0:
                continue
            old = existing.get(ticker)
            name = str(r.get("name") or (old.name.get() if old else "") or ticker)
            asset_type = str(r.get("asset_type") or (old.asset_type.get() if old else "stock") or "stock")
            new_assets.append((ticker, name, asset_type, float(amount)))

        bond_amount = round(max(bond_weight, 0.0) * target_total)
        if bond_amount > 0:
            old_bond = next((r for r in self.rows if self._is_bond_row(r)), None)
            bond_name = old_bond.name.get() if old_bond else "채권"
            new_assets.append(("BOND_BUCKET", bond_name or "채권", "bond_bucket", float(bond_amount)))

        if not self._auto_cash_enabled_value():
            cash_amount = round(max(cash_weight, 0.0) * target_total)
            if cash_amount > 0:
                new_assets.append(("CASH", "현금", "cash", float(cash_amount)))

        self._auto_cash_syncing = True
        try:
            self._destroy_all_input_rows()
            for ticker, name, asset_type, amount in new_assets:
                self._append_input_row(ticker, name, asset_type, amount, recalc=False)
        finally:
            self._auto_cash_syncing = False
        self.recalculate_current()
        self.sort_current_portfolio_by_weight(show_message=False, descending=True)
        self.tabs.set("현재 포트폴리오")
        self.status_text.set("추천 적용 완료")
        messagebox.showinfo("추천 적용 완료", "모델 추천 포트폴리오를 현재 포트폴리오 입력값에 적용했습니다. 현금 반영 방식은 현재 CASH 자동반영 설정을 따릅니다.")

    def run_pipeline(self) -> None:
        try:
            req = self.build_request()
        except Exception as exc:
            messagebox.showerror("입력 오류", str(exc))
            return
        if req.settings.prediction_run_mode == "walk_forward":
            ok = messagebox.askyesno(
                "정밀 백테스트 실행 확인",
                (
                    "현재 예측 방식이 walk_forward입니다.\n\n"
                    "이 모드는 과거 전체 구간을 여러 시점으로 나누어 반복 학습하므로 "
                    "종목 수와 학습 시작일에 따라 오래 걸릴 수 있습니다.\n\n"
                    "현재 추천 비중만 계산하려면 사용자 설정에서 예측 방식을 latest로 바꾸세요.\n\n"
                    "그래도 정밀 백테스트를 실행할까요?"
                ),
            )
            if not ok:
                self.status_text.set("실행 취소")
                return
        try:
            self.save_settings_from_ui(silent=True)
        except Exception:
            pass
        self.status_text.set("실행 중")
        self.cancel_event = threading.Event()
        self.run_button.configure(state="disabled")
        self.cancel_button.configure(state="normal")
        self.summary_text.set("실행 중입니다. 기본값은 최근 학습 윈도우 기반 최신 예측이며, 정밀 백테스트는 설정에서 별도로 선택할 수 있습니다.")
        self._set_progress(0.02, "입력 검증 완료", "포트폴리오 요청을 생성했습니다.")
        self.tabs.set("모델 추천")
        self.worker_thread = threading.Thread(target=self._worker_run, args=(req, self.cancel_event), daemon=True)
        self.worker_thread.start()

    def cancel_pipeline(self) -> None:
        if self.cancel_event is None:
            return
        self.cancel_event.set()
        self.cancel_button.configure(state="disabled")
        self.status_text.set("취소 요청")
        self.summary_text.set("모델 예측 취소를 요청했습니다. 진행 중인 모델 프로세스를 종료하는 중입니다.")
        self._set_progress(0.0, "취소 요청", "현재 실행 중인 작업이 안전하게 중단될 때까지 잠시 기다려 주세요.")

    def _set_progress(self, percent: float, stage: str, message: str | None = None) -> None:
        pct = max(0.0, min(float(percent), 1.0))
        if hasattr(self, "progress_bar"):
            self.progress_bar.set(pct)
        detail = f"진행 상태: {stage} · {pct * 100:.0f}%"
        if message:
            detail += "\n" + str(message)
        self.progress_text.set(detail)
        if stage:
            self.status_text.set(stage)

    def _worker_run(self, req: PortfolioEvaluateRequest, cancel_event: threading.Event | None) -> None:
        try:
            def progress(percent: float, stage: str, message: str | None = None) -> None:
                self.worker_queue.put(("progress", {"percent": percent, "stage": stage, "message": message or ""}))

            progress(0.03, "작업 스레드 시작", "백엔드 서비스를 초기화합니다.")
            if cancel_event is not None and cancel_event.is_set():
                raise PraCancelledError("사용자가 분석을 취소했습니다.")
            service = PortfolioRegimeAdvisorService()
            progress(0.035, "백엔드 초기화 완료", "요청 처리를 시작합니다.")
            if cancel_event is not None and cancel_event.is_set():
                raise PraCancelledError("사용자가 분석을 취소했습니다.")
            payload = service.evaluate(req, progress_callback=progress, cancel_event=cancel_event)
            atomic_write_json(Path("storage/latest_customtkinter_result.json"), payload)
            self.worker_queue.put(("success", payload))
        except PraCancelledError as exc:
            self.worker_queue.put(("cancelled", {"message": str(exc), "traceback": traceback.format_exc()}))
        except Exception as exc:
            self.worker_queue.put(("error", {"message": str(exc), "traceback": traceback.format_exc()}))

    def _poll_worker_queue(self) -> None:
        try:
            while True:
                kind, data = self.worker_queue.get_nowait()
                if kind == "progress":
                    self._set_progress(data.get("percent", 0.0), data.get("stage", "실행 중"), data.get("message", ""))
                elif kind == "success":
                    self.run_button.configure(state="normal")
                    self.cancel_button.configure(state="disabled")
                    self.cancel_event = None
                    self.latest_payload = data
                    try:
                        self.render_payload(data)
                    except Exception as exc:
                        err = {"message": str(exc), "traceback": traceback.format_exc()}
                        atomic_write_json(Path("storage/latest_customtkinter_render_error.json"), err)
                        self.status_text.set("표시 오류")
                        self.summary_text.set(f"모델 실행은 완료됐지만 화면 표시 중 오류가 발생했습니다. storage/latest_customtkinter_render_error.json 확인 필요: {exc}")
                        messagebox.showerror("결과 표시 오류", str(exc))
                        continue
                    self._set_progress(1.0, "완료", "추천 비중과 포트폴리오 성과를 갱신했습니다.")
                    if str(data.get("prediction_run_mode") or "").lower().strip() == "walk_forward":
                        self.tabs.set("포트폴리오 성과")
                    self.status_text.set("완료")
                elif kind == "cancelled":
                    self.run_button.configure(state="normal")
                    self.cancel_button.configure(state="disabled")
                    self.cancel_event = None
                    self.status_text.set("취소됨")
                    self._set_progress(0.0, "취소됨", "사용자 요청으로 모델 예측을 중단했습니다.")
                    self.summary_text.set(data.get("message", "사용자가 분석을 취소했습니다."))
                    atomic_write_json(Path("storage/latest_customtkinter_cancelled.json"), data)
                    messagebox.showinfo("실행 취소", "모델 예측을 취소했습니다.")
                else:
                    self.run_button.configure(state="normal")
                    self.cancel_button.configure(state="disabled")
                    self.cancel_event = None
                    self.status_text.set("실패")
                    self._set_progress(1.0, "실패", "상세 오류는 storage/latest_customtkinter_error.json에 저장됩니다.")
                    self.summary_text.set(data.get("message", "실행 실패"))
                    atomic_write_json(Path("storage/latest_customtkinter_error.json"), data)
                    messagebox.showerror("실행 실패", f"{data.get('message', '')}\n\n상세 로그: storage/latest_customtkinter_error.json")
        except queue.Empty:
            pass
        self.after(200, self._poll_worker_queue)

    @staticmethod
    def pct(v: Any) -> str:
        try:
            return f"{float(v) * 100:.2f}%"
        except Exception:
            return "-"

    @staticmethod
    def money(v: float) -> str:
        sign = "+" if v > 0 else ""
        return f"{sign}{v:,.0f}"

    def clear_result_view(self) -> None:
        if hasattr(self, "apply_recommendation_button"):
            self.apply_recommendation_button.configure(state="disabled")
        self.recommended_pie.set_data([])
        self.summary_text.set("포트폴리오를 입력한 뒤 분석을 실행하세요.")
        self._set_progress(0.0, "대기 중", "분석을 실행하면 단계별 진행 상황이 표시됩니다.")
        for frame in [self.changes_frame, self.signals_frame, self.portfolio_perf_frame, self.model_perf_frame]:
            for child in frame.winfo_children():
                child.destroy()
        self.equity_chart.set_data([])

    def render_payload(self, payload: Dict[str, Any]) -> None:
        self.clear_result_view()
        if hasattr(self, "apply_recommendation_button"):
            self.apply_recommendation_button.configure(state="normal")
        allocation = payload.get("allocation", {}) or {}
        totals = allocation.get("portfolio_totals", {}) or {}
        validation = payload.get("validation", {}) or {}
        as_of = payload.get("as_of_date") or "-"
        total_value = self.total_value or 0.0
        stock_w = float(totals.get("stock_weight") or 0.0)
        bond_w = float(totals.get("bond_weight") or 0.0)
        cash_w = float(totals.get("cash_weight") or 0.0)
        self.recommended_pie.set_data([
            ("주식", stock_w),
            ("채권", bond_w),
            ("현금", cash_w),
        ])
        self.summary_text.set(
            "\n".join([
                f"상태: {'정상' if payload.get('ok') else '주의/실패'}",
                f"기준일: {as_of}",
                f"추천 구성: 주식 {stock_w*100:.2f}% · 채권 {bond_w*100:.2f}% · 현금 {cash_w*100:.2f}%",
                f"추천 금액: 주식 {stock_w*total_value:,.0f} · 채권 {bond_w*total_value:,.0f} · 현금 {cash_w*total_value:,.0f}",
                f"검증: fail={validation.get('fail_count', 0)} · warn={validation.get('warn_count', 0)}",
                "결과 저장: storage/latest_customtkinter_result.json",
            ])
        )
        self._render_change_rows(allocation.get("allocation_rows", []) or [], stock_w, bond_w, cash_w)
        self._render_signal_rows(payload.get("latest_signals", []) or [])
        self._safe_render_performance_page(payload)

    @staticmethod
    def metric_pct(v: Any) -> str:
        try:
            if v is None:
                return "-"
            return f"{float(v) * 100:.2f}%"
        except Exception:
            return "-"

    @staticmethod
    def metric_num(v: Any, digits: int = 3) -> str:
        try:
            if v is None:
                return "-"
            return f"{float(v):,.{digits}f}"
        except Exception:
            return "-"

    def _add_perf_line(self, parent: ctk.CTkFrame, label: str, value: str, color: str = "#d9e3fb") -> None:
        line = ctk.CTkFrame(parent, fg_color="#162031", corner_radius=10)
        line.pack(fill="x", pady=3)
        ctk.CTkLabel(line, text=label, anchor="w", text_color="#909095", width=160).pack(side="left", padx=10, pady=7)
        ctk.CTkLabel(line, text=value, anchor="e", text_color=color, font=ctk.CTkFont(family="Consolas", size=12)).pack(side="right", padx=10, pady=7)

    def _add_perf_error_line(self, parent: ctk.CTkFrame, title: str, exc: Exception) -> None:
        self._add_perf_line(parent, title, f"{type(exc).__name__}: {exc}", "#ffb4ab")

    def _safe_render_performance_page(self, payload: Dict[str, Any]) -> None:
        try:
            self._render_performance_page(payload)
        except Exception as exc:
            err = {"message": str(exc), "traceback": traceback.format_exc()}
            atomic_write_json(Path("storage/latest_customtkinter_render_error.json"), err)
            self._add_perf_error_line(self.portfolio_perf_frame, "성과 표시 오류", exc)
            self._add_perf_error_line(self.model_perf_frame, "모델 평가 표시 오류", exc)

    def _summary_path_for_ticker(self, ticker: str) -> Path:
        safe = normalize_ticker(ticker).lower()
        return Path("storage/predictions/v8_6_41") / f"{safe}_xgb_recency_weighted_v8_6_41_model_label_fixed_summary.json"

    def _load_model_summary(self, ticker: str) -> Dict[str, Any]:
        path = self._summary_path_for_ticker(ticker)
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _pick_model_metric(self, summary: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
        external = summary.get("external_summary") if isinstance(summary.get("external_summary"), dict) else summary
        cls = external.get("classification", {}) if isinstance(external, dict) else {}
        preferred = [
            "stage1_ensemble_vs_primary",
            "overall_risk_vs_highvol_primary",
            "overall_risk_vs_down_primary",
            "direction_strength_up_score_vs_20d",
            "direction_strength_up_strengthening",
            "up_h20",
            "down_h20",
            "stage1_h20",
        ]
        for key in preferred:
            val = cls.get(key)
            if isinstance(val, dict) and any(k in val for k in ["roc_auc", "pr_auc", "brier", "f1", "recall"]):
                return key, val
        for key, val in cls.items():
            if isinstance(val, dict) and any(k in val for k in ["roc_auc", "pr_auc", "brier", "f1", "recall"]):
                return str(key), val
        return "요약 없음", {}

    def _render_performance_page(self, payload: Dict[str, Any]) -> None:
        # Portfolio performance: model recommendation vs user's current buy-and-hold.
        perf = payload.get("performance") or {}
        metrics = perf.get("metrics") or {}
        bh = perf.get("buy_and_hold_metrics") or {}
        run_mode = str(payload.get("prediction_run_mode") or "latest").lower().strip()
        latest_train_rows = payload.get("latest_train_rows")

        self._add_perf_line(self.portfolio_perf_frame, "비교 기준", "모델 추천 vs 현재 포트폴리오 Buy & Hold", "#a6c8ff")
        if run_mode == "walk_forward":
            self._add_perf_line(self.portfolio_perf_frame, "예측 방식", "walk_forward · 정밀 백테스트 결과 포함", "#50ffaf")
        else:
            self._add_perf_line(self.portfolio_perf_frame, "예측 방식", f"latest · 최근 {latest_train_rows or '-'}개 거래일 기반 최신 예측", "#a6c8ff")
        if not metrics:
            self._add_perf_line(self.portfolio_perf_frame, "성과 상태", "performance.metrics 없음 또는 비어 있음", "#ffb4ab")
        if not bh:
            self._add_perf_line(self.portfolio_perf_frame, "B&H 상태", "buy_and_hold_metrics 없음 또는 비어 있음", "#ffb4ab")
        compare_rows = [
            ("거래일 수", f"추천 {int(metrics.get('n_days') or 0):,}일 / B&H {int(bh.get('n_days') or 0):,}일", "#d9e3fb"),
            ("최종 자본", f"추천 {float(metrics.get('final_capital') or 0):,.0f} / B&H {float(bh.get('final_capital') or 0):,.0f}", "#d9e3fb"),
            ("CAGR", f"추천 {self.metric_pct(metrics.get('cagr'))} / B&H {self.metric_pct(bh.get('cagr'))}", "#50ffaf"),
            ("MDD", f"추천 {self.metric_pct(metrics.get('mdd'))} / B&H {self.metric_pct(bh.get('mdd'))}", "#ffb4ab"),
            ("Sharpe", f"추천 {self.metric_num(metrics.get('sharpe'))} / B&H {self.metric_num(bh.get('sharpe'))}", "#d9e3fb"),
            ("Sortino", f"추천 {self.metric_num(metrics.get('sortino'))} / B&H {self.metric_num(bh.get('sortino'))}", "#d9e3fb"),
            ("Calmar", f"추천 {self.metric_num(metrics.get('calmar'))} / B&H {self.metric_num(bh.get('calmar'))}", "#d9e3fb"),
            ("연환산 변동성", f"추천 {self.metric_pct(metrics.get('annual_vol'))} / B&H {self.metric_pct(bh.get('annual_vol'))}", "#d9e3fb"),
            ("상승일 비율", f"추천 {self.metric_pct(metrics.get('win_rate'))} / B&H {self.metric_pct(bh.get('win_rate'))}", "#d9e3fb"),
        ]
        for label, value, color in compare_rows:
            self._add_perf_line(self.portfolio_perf_frame, label, value, color)

        eq_tail = (perf.get("equity_curve_tail") or [])
        points: List[Tuple[str, float]] = []
        for item in eq_tail:
            date_label = str(item.get("Date") or "-")[-10:]
            try:
                points.append((date_label, float(item.get("equity"))))
            except Exception:
                pass
        self.equity_chart.set_data(points)

        # Model evaluation is intentionally separated from portfolio performance.
        # latest mode is for current allocation only, so it should not present
        # backtest-style model metrics as if they were full validation results.
        if run_mode != "walk_forward":
            self._add_perf_line(self.model_perf_frame, "표시 상태", "latest 모드: 모델 평가는 표시하지 않음", "#a6c8ff")
            self._add_perf_line(self.model_perf_frame, "평가 조건", "예측 방식을 walk_forward로 바꿔 정밀 백테스트를 실행하면 모델 성능 지표가 표시됩니다.", "#d9e3fb")
            self._add_perf_line(self.model_perf_frame, "현재 용도", "최신 추천 비중 산출용", "#d9e3fb")
            return

        # Model execution and classification performance for walk-forward mode.
        self._add_perf_line(self.model_perf_frame, "표시 상태", "walk_forward 모드: 모델 평가 표시", "#50ffaf")
        gen = payload.get("prediction_generation_status") or {}
        gen_results = gen.get("results") or []
        if not gen_results:
            self._add_perf_line(self.model_perf_frame, "예측 생성", "캐시 재사용 또는 정보 없음", "#a6c8ff")
        for item in gen_results:
            ticker = str(item.get("ticker") or "-")
            errs = item.get("errors") or []
            status = "실패" if errs else "성공"
            color = "#ffb4ab" if errs else "#50ffaf"
            self._add_perf_line(self.model_perf_frame, f"{ticker} 생성", f"{status} · rows {item.get('rows', 0)} · {item.get('latest_date') or '-'}", color)

        signals = payload.get("latest_signals") or []
        for sig in signals:
            ticker = str(sig.get("ticker") or "-")
            summary = self._load_model_summary(ticker)
            metric_name, metric = self._pick_model_metric(summary)
            if not metric:
                latest = sig.get("Date") or "-"
                self._add_perf_line(self.model_perf_frame, f"{ticker} 모델", f"요약 없음 · latest {latest}", "#a6c8ff")
                continue
            value = (
                f"{metric_name} | "
                f"ROC {self.metric_num(metric.get('roc_auc'))} · "
                f"PR {self.metric_num(metric.get('pr_auc'))} · "
                f"Brier {self.metric_num(metric.get('brier'))} · "
                f"F1 {self.metric_num(metric.get('f1'))}"
            )
            self._add_perf_line(self.model_perf_frame, f"{ticker} 성능", value, "#d9e3fb")

        validation = payload.get("validation") or {}
        self._add_perf_line(self.model_perf_frame, "검증 상태", f"fail {validation.get('fail_count', 0)} · warn {validation.get('warn_count', 0)}", "#ffb4ab" if validation.get("fail_count", 0) else "#50ffaf")

    def _current_bucket_values(self) -> tuple[float, float]:
        bond = cash = 0.0
        for row in self.rows:
            try:
                amount = max(row.amount_value(), 0.0)
            except Exception:
                amount = 0.0
            raw_ticker = self._row_ticker_text(row)
            try:
                ticker = normalize_ticker(raw_ticker) if raw_ticker else "-"
            except Exception:
                ticker = raw_ticker or "-"
            at = row.asset_type.get()
            if at in {"cash", "cash_bucket"} or ticker in {"CASH", "CASH_BUCKET"}:
                cash += amount
            elif at in {"bond", "bond_etf", "bond_bucket"} or ticker == "BOND_BUCKET":
                bond += amount
        return bond, cash

    def _render_change_rows(self, rows: List[Dict[str, Any]], stock_w: float, bond_w: float, cash_w: float) -> None:
        total = self.total_value or 0.0
        header = ctk.CTkFrame(self.changes_frame, fg_color="transparent")
        header.pack(fill="x", pady=(0, 4))
        for text, width in [("자산", 80), ("현재", 95), ("추천", 95), ("증감", 95), ("점수", 70), ("판정", 120)]:
            ctk.CTkLabel(header, text=text, width=width, text_color="#909095").pack(side="left", padx=3)
        for r in rows:
            ticker = r.get("ticker", "-")
            current = float(r.get("current_weight") or 0.0) * total
            recommended = float(r.get("recommended_weight") or 0.0) * total
            diff = recommended - current
            score_mult = float(r.get("score_multiplier") or 1.0)
            action = r.get("action", "-")
            reason = r.get("allocation_reason") or ""
            display_action = f"{action} · {reason}" if reason else action
            self._add_change_line(ticker, current, recommended, diff, display_action, score_mult)
        cur_bond, cur_cash = self._current_bucket_values()
        rec_bond = bond_w * total
        rec_cash = cash_w * total
        self._add_change_line("BOND", cur_bond, rec_bond, rec_bond - cur_bond, "DEFENSIVE_BUCKET")
        self._add_change_line("CASH", cur_cash, rec_cash, rec_cash - cur_cash, "DEFENSIVE_BUCKET")

    def _add_change_line(self, ticker: str, current: float, recommended: float, diff: float, action: str, score_mult: float = 1.0) -> None:
        line = ctk.CTkFrame(self.changes_frame, fg_color="#162031", corner_radius=10)
        line.pack(fill="x", pady=3)
        color = "#50ffaf" if diff > 0 else "#ffb4ab" if diff < 0 else "#d9e3fb"
        score_color = "#50ffaf" if score_mult > 1.05 else "#ffb4ab" if score_mult < 0.95 else "#d9e3fb"
        values = [ticker, f"{current:,.0f}", f"{recommended:,.0f}", self.money(diff), f"{score_mult:.2f}x", action]
        widths = [80, 95, 95, 95, 70, 190]
        for i, (text, width) in enumerate(zip(values, widths)):
            text_color = color if i == 3 else score_color if i == 4 else "#d9e3fb"
            ctk.CTkLabel(line, text=text, width=width, anchor="e" if i in {1,2,3,4} else "w", text_color=text_color, font=ctk.CTkFont(family="Consolas" if i in {1,2,3,4} else "Segoe UI", size=12)).pack(side="left", padx=4, pady=6)

    def _composite_risk_probability(self, signal: Dict[str, Any]) -> float:
        """Return the user-facing combined risk probability.

        HighVol and overall risk can be identical in the current model output.
        The recommendation screen therefore shows a single Composite Risk value
        using the more conservative of the two probabilities.
        """
        return max(
            safe_float(signal.get("prob_high_vol"), 0.0),
            safe_float(signal.get("prob_overall_risk"), 0.0),
        )

    def _render_signal_rows(self, signals: List[Dict[str, Any]]) -> None:
        header = ctk.CTkFrame(self.signals_frame, fg_color="transparent")
        header.pack(fill="x", pady=(0, 4))
        columns = [("Asset", 70), ("Normal", 76), ("Composite Risk", 116), ("Up", 76), ("Down", 76)]
        for text, width in columns:
            ctk.CTkLabel(header, text=text, width=width, text_color="#909095").pack(side="left", padx=2)
        for s in signals:
            line = ctk.CTkFrame(self.signals_frame, fg_color="#162031", corner_radius=10)
            line.pack(fill="x", pady=3)
            values = [
                (s.get("ticker", "-"), 70),
                (self.pct(s.get("prob_normal")), 76),
                (self.pct(self._composite_risk_probability(s)), 116),
                (self.pct(s.get("prob_up_strengthening_score")), 76),
                (self.pct(s.get("prob_down_strengthening_score")), 76),
            ]
            for text, width in values:
                ctk.CTkLabel(line, text=text, width=width, font=ctk.CTkFont(family="Consolas", size=12)).pack(side="left", padx=2, pady=6)


def main() -> None:
    app = MinimalCTkApp()
    app.mainloop()


if __name__ == "__main__":
    main()
