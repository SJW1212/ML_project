from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List

from .utils import atomic_write_json, ensure_dir, load_json, normalize_ticker, utc_now_iso as _utc_now_iso

SLOTS_PATH = Path("storage/config/portfolio_slots.json")
MAX_PORTFOLIO_SLOTS = 5


@dataclass
class PortfolioSlotAsset:
    ticker: str
    name: str = ""
    asset_type: str = "stock"
    amount: float = 0.0

    def normalized(self) -> "PortfolioSlotAsset":
        self.ticker = normalize_ticker(self.ticker)
        self.name = str(self.name or "")
        self.asset_type = str(self.asset_type or "stock")
        self.amount = max(float(self.amount or 0.0), 0.0)
        return self

    def to_json_dict(self) -> Dict[str, Any]:
        s = self.normalized()
        return asdict(s)


@dataclass
class PortfolioSlot:
    slot_id: int
    name: str = ""
    operating_capital: float = 0.0
    assets: List[PortfolioSlotAsset] = field(default_factory=list)
    saved_at: str = ""

    def is_empty(self) -> bool:
        return not self.assets

    def normalized(self) -> "PortfolioSlot":
        self.slot_id = int(self.slot_id)
        if self.slot_id < 1 or self.slot_id > MAX_PORTFOLIO_SLOTS:
            raise ValueError(f"slot_id must be 1..{MAX_PORTFOLIO_SLOTS}: {self.slot_id}")
        self.name = str(self.name or "").strip()
        self.operating_capital = max(float(self.operating_capital or 0.0), 0.0)
        clean_assets: List[PortfolioSlotAsset] = []
        for asset in self.assets:
            if isinstance(asset, dict):
                asset = PortfolioSlotAsset(**asset)
            asset = asset.normalized()
            if asset.amount > 0:
                clean_assets.append(asset)
        self.assets = clean_assets
        self.saved_at = str(self.saved_at or "")
        return self

    def display_label(self) -> str:
        if self.is_empty():
            return f"슬롯 {self.slot_id}: 비어 있음"
        label = self.name or self._auto_name()
        return f"슬롯 {self.slot_id}: {label}"

    def _auto_name(self) -> str:
        tickers = [a.ticker for a in self.assets[:3]]
        suffix = "..." if len(self.assets) > 3 else ""
        return "/".join(tickers) + suffix

    def to_json_dict(self) -> Dict[str, Any]:
        s = self.normalized()
        data = asdict(s)
        data["assets"] = [a.to_json_dict() for a in s.assets]
        return data


@dataclass
class PortfolioSlotsStore:
    slots: Dict[int, PortfolioSlot]

    @classmethod
    def empty(cls) -> "PortfolioSlotsStore":
        return cls(slots={i: PortfolioSlot(slot_id=i) for i in range(1, MAX_PORTFOLIO_SLOTS + 1)})

    def normalized(self) -> "PortfolioSlotsStore":
        clean = PortfolioSlotsStore.empty().slots
        for k, slot in list(self.slots.items()):
            try:
                sid = int(k)
                if 1 <= sid <= MAX_PORTFOLIO_SLOTS:
                    if isinstance(slot, dict):
                        slot = PortfolioSlot(**slot)
                    clean[sid] = slot.normalized()
            except Exception:
                continue
        self.slots = clean
        return self

    def get(self, slot_id: int) -> PortfolioSlot:
        self.normalized()
        return self.slots[int(slot_id)]

    def set(self, slot: PortfolioSlot) -> None:
        slot = slot.normalized()
        self.slots[slot.slot_id] = slot

    def clear(self, slot_id: int) -> None:
        self.slots[int(slot_id)] = PortfolioSlot(slot_id=int(slot_id))

    def labels(self) -> List[str]:
        self.normalized()
        return [self.slots[i].display_label() for i in range(1, MAX_PORTFOLIO_SLOTS + 1)]

    def to_json_dict(self) -> Dict[str, Any]:
        self.normalized()
        return {"slots": {str(i): self.slots[i].to_json_dict() for i in range(1, MAX_PORTFOLIO_SLOTS + 1)}}


def utc_now_iso() -> str:
    return _utc_now_iso(timespec="seconds")


def load_portfolio_slots(path: Path = SLOTS_PATH) -> PortfolioSlotsStore:
    data = load_json(path, default={}) or {}
    raw_slots = data.get("slots", {}) if isinstance(data, dict) else {}
    store = PortfolioSlotsStore.empty()
    for key, value in raw_slots.items():
        try:
            sid = int(key)
            assets = [PortfolioSlotAsset(**a) for a in value.get("assets", [])]
            store.slots[sid] = PortfolioSlot(
                slot_id=sid,
                name=value.get("name", ""),
                operating_capital=float(value.get("operating_capital") or 0.0),
                assets=assets,
                saved_at=value.get("saved_at", ""),
            )
        except Exception:
            continue
    return store.normalized()


def save_portfolio_slots(store: PortfolioSlotsStore, path: Path = SLOTS_PATH) -> Path:
    ensure_dir(path.parent)
    atomic_write_json(path, store.to_json_dict())
    return path
