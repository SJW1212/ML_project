from __future__ import annotations

from typing import Dict, Iterable, List, Optional

import pandas as pd

from .feature_schema import REQUIRED_PREDICTION_COLUMNS


class ValidationService:
    def validate_predictions(self, prediction_frames: Dict[str, pd.DataFrame], cache_freshness: List[Dict]) -> List[Dict]:
        checks: List[Dict] = []
        cache_latest = {x["ticker"]: x.get("latest_date") for x in cache_freshness}
        for ticker, df in prediction_frames.items():
            if df is None or df.empty:
                checks.append({"check_name": "prediction_not_empty", "ticker": ticker, "status": "FAIL", "detail": "Prediction frame is empty"})
                continue
            missing = [c for c in REQUIRED_PREDICTION_COLUMNS if c not in df.columns]
            checks.append({"check_name": "required_prediction_columns", "ticker": ticker, "status": "FAIL" if missing else "PASS", "detail": f"missing={missing}"})
            pred_latest = str(pd.to_datetime(df["Date"]).max().date()) if "Date" in df.columns else None
            c_latest = cache_latest.get(ticker)
            if c_latest and pred_latest and c_latest > pred_latest:
                checks.append({"check_name": "prediction_date_vs_cache_date", "ticker": ticker, "status": "WARN", "detail": f"cache_latest={c_latest}, prediction_latest={pred_latest}"})
            else:
                checks.append({"check_name": "prediction_date_vs_cache_date", "ticker": ticker, "status": "PASS", "detail": f"cache_latest={c_latest}, prediction_latest={pred_latest}"})
        ranges = {}
        for ticker, df in prediction_frames.items():
            if df is not None and not df.empty and "Date" in df.columns:
                d = pd.to_datetime(df["Date"])
                ranges[ticker] = (str(d.min().date()), str(d.max().date()))
        if len(set(ranges.values())) > 1:
            checks.append({"check_name": "asset_date_range_mismatch", "status": "WARN", "detail": str(ranges)})
        else:
            checks.append({"check_name": "asset_date_range_mismatch", "status": "PASS", "detail": str(ranges)})
        return checks

    def validate_allocation(self, allocation_payload: Dict) -> List[Dict]:
        checks: List[Dict] = []
        totals = allocation_payload.get("portfolio_totals", {}) or {}
        stock = float(totals.get("stock_weight", 0) or 0)
        bond = float(totals.get("bond_weight", 0) or 0)
        cash = float(totals.get("cash_weight", 0) or 0)
        s = stock + bond + cash
        checks.append({"check_name": "portfolio_weight_sum", "status": "PASS" if abs(s - 1.0) <= 1e-3 else "FAIL", "detail": f"sum={s:.6f}"})

        rows = allocation_payload.get("allocation_rows", []) or []
        diag = allocation_payload.get("allocation_diagnostics", {}) or {}
        if rows and stock <= 1e-8 and all(float(r.get("recommended_weight", 0) or 0) <= 1e-8 for r in rows):
            checks.append({
                "check_name": "risk_asset_recommendation_not_degenerate",
                "status": "WARN",
                "detail": "all risk-asset recommended weights are zero; confirm this is an intended defensive allocation, not a model-output collapse",
            })
        else:
            checks.append({
                "check_name": "risk_asset_recommendation_not_degenerate",
                "status": "PASS",
                "detail": f"risk_rows={len(rows)}, stock_weight={stock:.6f}",
            })

        fallback_count = int(diag.get("fallback_default_count", 0) or 0)
        zero_sum_count = int(diag.get("zero_sum_fallback_count", 0) or 0)
        risk_asset_count = int(diag.get("risk_asset_count", len(rows)) or 0)
        if risk_asset_count > 0 and fallback_count == risk_asset_count:
            checks.append({
                "check_name": "model_weight_fallback_default_all_assets",
                "status": "WARN",
                "detail": "all risk assets used default model weights because stock/bond/cash weights were missing or invalid",
            })
        elif fallback_count > 0:
            checks.append({
                "check_name": "model_weight_fallback_default_partial",
                "status": "WARN",
                "detail": f"{fallback_count}/{risk_asset_count} risk assets used default model weights",
            })
        else:
            checks.append({"check_name": "model_weight_fallback_default", "status": "PASS", "detail": "no default model-weight fallback used"})

        if risk_asset_count > 0 and zero_sum_count == risk_asset_count:
            checks.append({
                "check_name": "model_weight_zero_sum_fallback_all_assets",
                "status": "WARN",
                "detail": "all risk assets had zero-sum model weights and were converted to defensive fallback weights",
            })
        elif zero_sum_count > 0:
            checks.append({
                "check_name": "model_weight_zero_sum_fallback_partial",
                "status": "WARN",
                "detail": f"{zero_sum_count}/{risk_asset_count} risk assets used zero-sum fallback weights",
            })
        else:
            checks.append({"check_name": "model_weight_zero_sum_fallback", "status": "PASS", "detail": "no zero-sum fallback used"})
        return checks

    @staticmethod
    def summarize(checks: List[Dict]) -> Dict:
        return {
            "fail_count": sum(1 for c in checks if c.get("status") == "FAIL"),
            "warn_count": sum(1 for c in checks if c.get("status") == "WARN"),
            "pass_count": sum(1 for c in checks if c.get("status") == "PASS"),
            "checks": checks,
        }
