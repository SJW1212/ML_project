from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from .schemas import PortfolioAssetInput, PortfolioEvaluateRequest
from .utils import normalize_ticker, safe_float

FALLBACK_DEFAULT_STOCK_WEIGHT = 0.82
FALLBACK_DEFAULT_BOND_WEIGHT = 0.117
FALLBACK_DEFAULT_CASH_WEIGHT = 0.063
FALLBACK_ZERO_STOCK_WEIGHT = 0.0
FALLBACK_ZERO_BOND_WEIGHT = 0.65
FALLBACK_ZERO_CASH_WEIGHT = 0.35


@dataclass
class AllocationRow:
    ticker: str
    name: str | None
    asset_type: str
    current_weight: float
    model_stock_weight: float
    model_bond_weight: float
    model_cash_weight: float
    recommended_asset_weight: float
    defensive_to_bond: float
    defensive_to_cash: float
    action: str
    model_weight_source: str = "model"
    relative_score: float = 1.0
    score_multiplier: float = 1.0
    allocation_reason: str = "model_weight"


class PortfolioAllocationService:
    def _initial_weights(
        self,
        request: PortfolioEvaluateRequest,
        risk_assets: List[PortfolioAssetInput],
        risk_vols: Optional[Dict[str, float]] = None,
    ) -> Tuple[Dict[str, float], Dict]:
        """Return normalized risk-asset base weights plus diagnostics.

        ``inverse_vol`` used to silently behave like ``current_weight``. That is
        dangerous because the user may think risk-parity-style sizing is active
        when it is not. v7.7 implements inverse-vol from supplied realized
        volatility estimates and raises a clear error when those estimates are
        unavailable.
        """
        mode = request.settings.capital_mode
        diagnostics = {
            "capital_mode_requested": mode,
            "capital_mode_effective": mode,
            "risk_vols": {},
            "warnings": [],
        }
        if not risk_assets:
            return {}, diagnostics
        if mode == "custom":
            raw = {normalize_ticker(k): float(v) for k, v in request.settings.custom_weights.items()}
            s = sum(max(0.0, raw.get(a.ticker, 0.0)) for a in risk_assets)
            if s <= 0:
                raise ValueError("custom_weights must contain positive weights for risk assets")
            return {a.ticker: max(0.0, raw.get(a.ticker, 0.0)) / s for a in risk_assets}, diagnostics
        if mode == "equal":
            w = 1.0 / len(risk_assets)
            return {a.ticker: w for a in risk_assets}, diagnostics
        if mode == "inverse_vol":
            risk_vols = risk_vols or {}
            inv: Dict[str, float] = {}
            for a in risk_assets:
                vol = safe_float(risk_vols.get(a.ticker), 0.0)
                diagnostics["risk_vols"][a.ticker] = vol
                if vol > 1e-8:
                    inv[a.ticker] = 1.0 / vol
            if len(inv) != len(risk_assets):
                missing = [a.ticker for a in risk_assets if a.ticker not in inv]
                raise ValueError(
                    "capital_mode='inverse_vol' requires positive realized volatility for every risk asset; "
                    f"missing_or_invalid={missing}"
                )
            s_inv = sum(inv.values())
            return {t: v / s_inv for t, v in inv.items()}, diagnostics
        # current_weight mode for local real-portfolio analysis.
        raw_vals = {a.ticker: safe_float(a.current_weight, 0.0) for a in risk_assets}
        s = sum(raw_vals.values())
        if s <= 0:
            w = 1.0 / len(risk_assets)
            diagnostics["capital_mode_effective"] = "equal_fallback_due_to_zero_current_weight"
            diagnostics["warnings"].append("current_weight sum was zero; equal risk-asset weights were used")
            return {a.ticker: w for a in risk_assets}, diagnostics
        return {t: v / s for t, v in raw_vals.items()}, diagnostics

    @staticmethod
    def _is_valid_weight_value(value) -> bool:
        try:
            if value is None or pd.isna(value):
                return False
            float(value)
            return True
        except Exception:
            return False

    def _apply_risk_profile_overlay(self, request: PortfolioEvaluateRequest, pred: Dict, sw: float, bw: float, cw: float) -> Tuple[float, float, float, Dict]:
        """Apply user risk profile after model probabilities are produced.

        The model probabilities themselves remain objective. Risk profile only
        changes the translation from model stock/bond/cash weights into final
        allocation weights.
        """
        profile = request.risk_profile
        sensitivity = min(max(safe_float(request.settings.risk_sensitivity, 1.0), 0.1), 3.0)
        risk = max(
            min(max(safe_float(pred.get("prob_overall_risk"), 0.0), 0.0), 1.0),
            min(max(safe_float(pred.get("prob_high_vol"), 0.0), 0.0), 1.0),
        )
        risk = min(risk * sensitivity, 1.0)
        up = min(max(safe_float(pred.get("prob_up_strengthening_score"), 0.0), 0.0), 1.0)
        down = min(max(safe_float(pred.get("prob_down_strengthening_score"), 0.0), 0.0), 1.0)
        info = {"risk_profile": profile, "risk_for_overlay": round(risk, 6), "overlay_applied": "none"}
        if profile == "conservative":
            scale = 0.92 - 0.20 * risk - 0.08 * max(down - up, 0.0)
            scale = min(max(scale, 0.55), 0.92)
            released = sw * (1.0 - scale)
            sw = sw * scale
            bw += released * 0.65
            cw += released * 0.35
            info.update({"overlay_applied": "conservative_stock_reduction", "stock_scale": round(scale, 6)})
        elif profile == "aggressive":
            defensive = bw + cw
            if defensive > 1e-12:
                transfer_rate = 0.20 + 0.15 * max(up - down, 0.0)
                transfer_rate *= max(0.25, 1.0 - 0.50 * risk)
                transfer = min(defensive * transfer_rate, defensive * 0.50)
                bw_share = bw / defensive
                cw_share = cw / defensive
                sw += transfer
                bw -= transfer * bw_share
                cw -= transfer * cw_share
                info.update({"overlay_applied": "aggressive_defensive_transfer", "transfer": round(transfer, 6)})
        total = sw + bw + cw
        if total <= 0:
            return FALLBACK_ZERO_STOCK_WEIGHT, FALLBACK_ZERO_BOND_WEIGHT, FALLBACK_ZERO_CASH_WEIGHT, info | {"overlay_applied": "invalid_after_overlay_fallback"}
        return sw / total, bw / total, cw / total, info

    def _ticker_relative_multiplier(self, request: PortfolioEvaluateRequest, pred: Dict) -> Tuple[float, Dict]:
        """Return a per-ticker relative allocation multiplier from model probabilities.

        Earlier versions applied each ticker's stock_weight independently, so when
        stock_weight values were similar, all risk assets were reduced almost at
        the same ratio. This function makes the stock portion compete across
        tickers using the model's risk/up/down probabilities while leaving the
        total stock/bond/cash budget governed by the model allocation weights.
        """
        profile = request.risk_profile
        sensitivity = min(max(safe_float(request.settings.risk_sensitivity, 1.0), 0.1), 3.0)
        normal = min(max(safe_float(pred.get("prob_normal"), 0.5), 0.0), 1.0)
        high_vol = min(max(safe_float(pred.get("prob_high_vol"), 0.0), 0.0), 1.0)
        overall_risk = min(max(safe_float(pred.get("prob_overall_risk"), 0.0), 0.0), 1.0)
        risk = max(high_vol, overall_risk)
        up = min(max(safe_float(pred.get("prob_up_strengthening_score"), 0.5), 0.0), 1.0)
        down = min(max(safe_float(pred.get("prob_down_strengthening_score"), 0.5), 0.0), 1.0)
        edge = up - down
        normal_edge = normal - 0.5
        excess_risk = max(risk - 0.45, 0.0)
        if profile == "conservative":
            k_edge, k_normal, k_risk, lo, hi = 0.55, 0.20, 1.05, 0.30, 1.35
        elif profile == "aggressive":
            k_edge, k_normal, k_risk, lo, hi = 0.95, 0.18, 0.45, 0.55, 2.00
        else:
            k_edge, k_normal, k_risk, lo, hi = 0.75, 0.20, 0.70, 0.40, 1.70
        raw = 1.0 + sensitivity * (k_edge * edge + k_normal * normal_edge - k_risk * excess_risk)
        multiplier = min(max(raw, lo), hi)
        if risk >= 0.75 and down > up:
            reason = "risk_down_penalty"
        elif up - down >= 0.15 and risk < 0.65:
            reason = "upside_reward"
        elif normal >= 0.60 and risk < 0.55:
            reason = "normal_regime_reward"
        elif multiplier < 0.95:
            reason = "relative_risk_penalty"
        elif multiplier > 1.05:
            reason = "relative_strength_reward"
        else:
            reason = "neutral_relative_score"
        return multiplier, {
            "normal": round(normal, 6),
            "risk": round(risk, 6),
            "up": round(up, 6),
            "down": round(down, 6),
            "edge": round(edge, 6),
            "multiplier": round(multiplier, 6),
            "reason": reason,
        }

    @staticmethod
    def _allocate_budget_by_scores(scores: Dict[str, float], budget: float, max_asset: float) -> Tuple[Dict[str, float], float]:
        """Allocate a total stock budget across tickers by relative scores.

        Returns ``(ticker_weights, leftover_budget)``. Leftover appears only when
        the stock budget cannot be placed because all tickers hit ``max_asset``;
        the caller should move it to cash rather than silently normalizing it
        away.
        """
        tickers = list(scores.keys())
        if not tickers or budget <= 0:
            return {t: 0.0 for t in tickers}, max(0.0, budget)
        max_asset = min(max(float(max_asset or 1.0), 1e-8), 1.0)
        final: Dict[str, float] = {}
        remaining = set(tickers)
        remaining_budget = float(budget)
        while remaining:
            positive_scores = {t: max(float(scores.get(t, 0.0)), 0.0) for t in remaining}
            s = sum(positive_scores.values())
            if s <= 0:
                positive_scores = {t: 1.0 for t in remaining}
                s = float(len(remaining))
            tentative = {t: remaining_budget * positive_scores[t] / s for t in remaining}
            over = [t for t, w in tentative.items() if w > max_asset]
            if not over:
                final.update(tentative)
                remaining.clear()
                remaining_budget = 0.0
                break
            for t in over:
                final[t] = max_asset
                remaining.remove(t)
                remaining_budget -= max_asset
            if remaining_budget <= 1e-12:
                for t in remaining:
                    final[t] = 0.0
                remaining_budget = 0.0
                break
        for t in tickers:
            final.setdefault(t, 0.0)
        return final, max(0.0, remaining_budget)

    def allocate(self, request: PortfolioEvaluateRequest, latest_predictions: Dict[str, Dict], risk_vols: Optional[Dict[str, float]] = None) -> Dict:
        enabled = [a for a in request.portfolio if a.enabled]
        risk_assets = [a for a in enabled if a.is_risk_asset]
        defensive_bond_current = sum(safe_float(a.current_weight, 0.0) for a in enabled if a.is_bond_bucket or a.is_defensive_etf)
        defensive_cash_current = sum(safe_float(a.current_weight, 0.0) for a in enabled if a.is_cash_bucket)
        total_current = sum(safe_float(a.current_weight, 0.0) for a in enabled if a.current_weight is not None)
        if total_current <= 0:
            # if no current weights, allocate only across risk assets initially.
            risk_base_total = 1.0
            defensive_bond_current = 0.0
            defensive_cash_current = 0.0
        else:
            risk_base_total = sum(safe_float(a.current_weight, 0.0) for a in risk_assets) / total_current
            defensive_bond_current /= total_current
            defensive_cash_current /= total_current
        risk_internal_weights, allocation_diagnostics = self._initial_weights(request, risk_assets, risk_vols=risk_vols)
        rows: List[AllocationRow] = []
        raw_items: List[Dict] = []
        total_asset_budget = 0.0
        total_bond = defensive_bond_current
        total_cash = defensive_cash_current
        max_asset = request.settings.max_asset_weight
        min_cash = request.settings.min_cash_weight
        fallback_default_count = 0
        zero_sum_fallback_count = 0
        relative_scores: Dict[str, float] = {}
        relative_score_info: Dict[str, Dict] = {}

        # First pass: determine the total stock/bond/cash budget from each
        # ticker's model stock/bond/cash weights. At this stage, stock budget is
        # not yet assigned back to tickers; it is pooled and redistributed in the
        # second pass using per-ticker probabilities.
        for a in risk_assets:
            pred = latest_predictions.get(a.ticker, {})
            has_model_weights = all(self._is_valid_weight_value(pred.get(k)) for k in ("stock_weight", "bond_weight", "cash_weight"))
            model_weight_source = "model"
            if not has_model_weights:
                fallback_default_count += 1
                model_weight_source = "fallback_default_0.82_0.117_0.063"
            sw = min(max(safe_float(pred.get("stock_weight"), FALLBACK_DEFAULT_STOCK_WEIGHT), 0.0), 1.0)
            bw = min(max(safe_float(pred.get("bond_weight"), FALLBACK_DEFAULT_BOND_WEIGHT), 0.0), 1.0)
            cw = min(max(safe_float(pred.get("cash_weight"), FALLBACK_DEFAULT_CASH_WEIGHT), 0.0), 1.0)
            s = sw + bw + cw
            if s <= 0:
                zero_sum_fallback_count += 1
                model_weight_source = "fallback_zero_sum_0_0.65_0.35"
                sw, bw, cw = FALLBACK_ZERO_STOCK_WEIGHT, FALLBACK_ZERO_BOND_WEIGHT, FALLBACK_ZERO_CASH_WEIGHT
            else:
                sw, bw, cw = sw / s, bw / s, cw / s
            sw, bw, cw, overlay_info = self._apply_risk_profile_overlay(request, pred, sw, bw, cw)
            base_abs = risk_base_total * risk_internal_weights.get(a.ticker, 0.0)
            raw_stock_budget = base_abs * sw
            to_bond = base_abs * bw
            to_cash = base_abs * cw
            total_asset_budget += raw_stock_budget
            total_bond += to_bond
            total_cash += to_cash
            mult, score_info = self._ticker_relative_multiplier(request, pred)
            # Score combines current/internal capital base, model stock budget,
            # and probability quality. This is what prevents all stocks from
            # being cut by the same ratio when their risk/up/down probabilities
            # differ.
            score = max(base_abs, 0.0) * max(sw, 0.0) * max(mult, 0.0)
            relative_scores[a.ticker] = score
            relative_score_info[a.ticker] = score_info | {"base_abs": round(base_abs, 6), "raw_stock_budget": round(raw_stock_budget, 6)}
            raw_items.append({
                "asset": a,
                "pred": pred,
                "base_abs": base_abs,
                "sw": sw,
                "bw": bw,
                "cw": cw,
                "to_bond": to_bond,
                "to_cash": to_cash,
                "model_weight_source": model_weight_source,
                "score_multiplier": mult,
                "score_info": score_info,
            })

        target_stock_by_ticker, stock_budget_leftover = self._allocate_budget_by_scores(relative_scores, total_asset_budget, max_asset)
        if stock_budget_leftover > 0:
            total_cash += stock_budget_leftover
            allocation_diagnostics.setdefault("warnings", []).append(
                f"stock budget leftover moved to cash due to max_asset_weight cap: {stock_budget_leftover:.6f}"
            )

        # Second pass: assign the pooled stock budget to tickers according to
        # relative model quality. Bond/cash bucket budgets remain the aggregate
        # defensive budget from the first pass.
        for item in raw_items:
            a: PortfolioAssetInput = item["asset"]
            rec_asset = target_stock_by_ticker.get(a.ticker, 0.0)
            curr = safe_float(a.current_weight, item["base_abs"]) / (total_current if total_current > 0 else 1.0)
            diff = rec_asset - curr
            if abs(diff) < 0.01:
                action = "HOLD"
            elif diff > 0.03:
                action = "INCREASE"
            elif diff > 0:
                action = "SLIGHT_INCREASE"
            elif diff < -0.03:
                action = "REDUCE"
            else:
                action = "SLIGHT_REDUCE"
            score_info = item["score_info"]
            reason = score_info.get("reason", "relative_score")
            rows.append(AllocationRow(
                a.ticker,
                a.name,
                a.asset_type,
                curr,
                item["sw"],
                item["bw"],
                item["cw"],
                rec_asset,
                item["to_bond"],
                item["to_cash"],
                action,
                item["model_weight_source"],
                relative_score=relative_scores.get(a.ticker, 0.0),
                score_multiplier=item["score_multiplier"],
                allocation_reason=reason,
            ))
        total_asset = sum(r.recommended_asset_weight for r in rows)
        if total_cash < min_cash:
            need = min_cash - total_cash
            # take from bond first, then assets proportionally.
            take_bond = min(total_bond, need)
            total_bond -= take_bond
            total_cash += take_bond
            remain = need - take_bond
            if remain > 0 and total_asset > 0:
                scale = max(0.0, (total_asset - remain) / total_asset)
                for r in rows:
                    r.recommended_asset_weight *= scale
                total_asset *= scale
                total_cash += remain
        total = total_asset + total_bond + total_cash
        if total <= 0:
            total_asset, total_bond, total_cash = 0.0, 0.0, 1.0
            total = 1.0
        payload_rows = []
        for r in rows:
            payload_rows.append({
                "ticker": r.ticker,
                "name": r.name,
                "asset_type": r.asset_type,
                "current_weight": round(r.current_weight, 6),
                "model_stock_weight": round(r.model_stock_weight, 6),
                "model_bond_weight": round(r.model_bond_weight, 6),
                "model_cash_weight": round(r.model_cash_weight, 6),
                "recommended_weight": round(r.recommended_asset_weight / total, 6),
                "defensive_to_bond": round(r.defensive_to_bond / total, 6),
                "defensive_to_cash": round(r.defensive_to_cash / total, 6),
                "action": r.action,
                "model_weight_source": r.model_weight_source,
                "relative_score": round(r.relative_score, 6),
                "score_multiplier": round(r.score_multiplier, 6),
                "allocation_reason": r.allocation_reason,
            })
        allocation_diagnostics.update({
            "risk_profile": request.risk_profile,
            "risk_sensitivity": request.settings.risk_sensitivity,
            "risk_asset_count": len(risk_assets),
            "fallback_default_count": fallback_default_count,
            "zero_sum_fallback_count": zero_sum_fallback_count,
            "relative_scores": {k: round(v, 6) for k, v in relative_scores.items()},
            "relative_score_info": relative_score_info,
            "stock_budget_before_relative_distribution": round(total_asset_budget, 6),
            "stock_budget_leftover_to_cash": round(stock_budget_leftover, 6),
            "rows_all_fallback_default": bool(risk_assets) and fallback_default_count == len(risk_assets),
            "rows_all_zero_sum_fallback": bool(risk_assets) and zero_sum_fallback_count == len(risk_assets),
        })
        return {
            "allocation_rows": payload_rows,
            "portfolio_totals": {
                "stock_weight": round(total_asset / total, 6),
                "bond_weight": round(total_bond / total, 6),
                "cash_weight": round(total_cash / total, 6),
            },
            "defensive_buckets_input": {"bond_weight": defensive_bond_current, "cash_weight": defensive_cash_current},
            "allocation_diagnostics": allocation_diagnostics,
        }
