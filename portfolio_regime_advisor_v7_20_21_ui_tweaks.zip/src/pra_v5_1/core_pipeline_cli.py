from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from .schemas import EvaluateSettings, PortfolioAssetInput, PortfolioEvaluateRequest
from .service import PortfolioRegimeAdvisorService
from .utils import atomic_write_json


def default_request(provider: str = "yahoo", force_prediction: bool = False) -> PortfolioEvaluateRequest:
    assets = [
        PortfolioAssetInput(ticker="AAPL", name="Apple", asset_type="stock", current_value=2500000),
        PortfolioAssetInput(ticker="QQQ", name="Nasdaq 100 ETF", asset_type="etf", current_value=2500000),
        PortfolioAssetInput(ticker="NVDA", name="NVIDIA", asset_type="stock", current_value=2000000),
        PortfolioAssetInput(ticker="LLY", name="Eli Lilly", asset_type="stock", current_value=1500000),
        PortfolioAssetInput(ticker="BOND_BUCKET", name="채권", asset_type="bond_bucket", current_value=1000000),
        PortfolioAssetInput(ticker="CASH", name="현금", asset_type="cash", current_value=500000),
    ]
    return PortfolioEvaluateRequest(
        portfolio=assets,
        risk_profile="balanced",
        user_level="general",
        settings=EvaluateSettings(
            start_date="1999-03-10",
            provider=provider,
            update_data=True,
            generate_predictions=True,
            force_prediction=force_prediction,
            prediction_engine_mode="external_v8641_xgb",
            speed_profile="balanced",
        ),
    )


def load_request(path: Path) -> PortfolioEvaluateRequest:
    with open(path, "r", encoding="utf-8") as f:
        return PortfolioEvaluateRequest.model_validate(json.load(f))


def compact_result(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ok": payload.get("ok"),
        "as_of_date": payload.get("as_of_date"),
        "engine_mode": payload.get("engine_mode"),
        "portfolio_totals": payload.get("allocation", {}).get("portfolio_totals"),
        "tickers": [s.get("ticker") for s in payload.get("latest_signals", [])],
        "validation": payload.get("validation"),
        "output": "storage/latest_dashboard_payload.json",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run PRA v6.8 core pipeline without browser/API server.")
    parser.add_argument("--request", help="PortfolioEvaluateRequest JSON path. If omitted, example request is used.")
    parser.add_argument("--provider", default="auto", choices=["auto", "yahoo", "kis", "hybrid"])
    parser.add_argument("--force-prediction", action="store_true")
    parser.add_argument("--out", default="storage/latest_desktop_result.json")
    args = parser.parse_args()

    req = load_request(Path(args.request)) if args.request else default_request(args.provider, args.force_prediction)
    service = PortfolioRegimeAdvisorService()
    payload = service.evaluate(req)
    atomic_write_json(Path(args.out), payload)
    print(json.dumps(compact_result(payload), ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
