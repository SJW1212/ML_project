from __future__ import annotations

def main() -> None:
    app = open("src/pra_v5_1/ctk_app.py", "r", encoding="utf-8").read()
    init = open("src/pra_v5_1/__init__.py", "r", encoding="utf-8").read()

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert "Composite Risk" in app
    assert '("HighVol", 76)' not in app
    assert '("Risk", 76)' not in app
    assert '("Asset", 70)' in app
    assert "def _composite_risk_probability" in app
    assert 'safe_float(signal.get("prob_high_vol"), 0.0)' in app
    assert 'safe_float(signal.get("prob_overall_risk"), 0.0)' in app
    print("PASS v72012_composite_risk_ui_contract")


if __name__ == "__main__":
    main()
