from __future__ import annotations


def main() -> None:
    app = open("src/pra_v5_1/ctk_app.py", "r", encoding="utf-8").read()
    init = open("src/pra_v5_1/__init__.py", "r", encoding="utf-8").read()

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert 'text="100%"' not in app
    assert 'text="총합"' not in app
    assert "portfolio weights sum to 100%" in app
    assert "create_oval(cx - r * 0.52" in app
    print("PASS v72013_pie_center_cleanup_contract")


if __name__ == "__main__":
    main()
