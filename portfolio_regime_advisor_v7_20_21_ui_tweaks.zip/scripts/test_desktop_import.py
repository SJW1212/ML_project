from pra_v5_1.desktop_app import DesktopApp  # noqa: F401
from pra_v5_1.core_pipeline_cli import default_request

req = default_request(provider="yahoo")
assert req.settings.prediction_engine_mode == "external_v8641_xgb"
assert req.settings.update_data is True
assert req.settings.generate_predictions is True
assert abs(sum(float(a.current_weight or 0) for a in req.portfolio) - 1.0) < 1e-9
print("PASS desktop_import_and_request")
