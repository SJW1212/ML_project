from pra_v5_1.allocation import PortfolioAllocationService
from pra_v5_1.schemas import PortfolioEvaluateRequest


def main():
    req = PortfolioEvaluateRequest(
        portfolio=[
            {"ticker": "QQQ", "name": "QQQ", "asset_type": "etf", "current_value": 250000},
            {"ticker": "NVDA", "name": "NVIDIA", "asset_type": "stock", "current_value": 250000},
            {"ticker": "BOND_BUCKET", "name": "Bond", "asset_type": "bond_bucket", "current_value": 100000},
            {"ticker": "CASH", "name": "Cash", "asset_type": "cash", "current_value": 150000},
        ],
        risk_profile="balanced",
        settings={"capital_mode": "current_weight"},
    )
    # Same stock/bond/cash model weights, different probabilities. Old behavior
    # would cut QQQ and NVDA by nearly the same ratio. New behavior reallocates
    # the pooled stock budget toward stronger/lower-risk names.
    preds = {
        "QQQ": {
            "stock_weight": 0.86,
            "bond_weight": 0.10,
            "cash_weight": 0.04,
            "prob_normal": 0.70,
            "prob_high_vol": 0.20,
            "prob_overall_risk": 0.25,
            "prob_up_strengthening_score": 0.65,
            "prob_down_strengthening_score": 0.35,
        },
        "NVDA": {
            "stock_weight": 0.86,
            "bond_weight": 0.10,
            "cash_weight": 0.04,
            "prob_normal": 0.35,
            "prob_high_vol": 0.75,
            "prob_overall_risk": 0.70,
            "prob_up_strengthening_score": 0.35,
            "prob_down_strengthening_score": 0.65,
        },
    }
    alloc = PortfolioAllocationService().allocate(req, preds)
    rows = {r["ticker"]: r for r in alloc["allocation_rows"]}
    assert rows["QQQ"]["recommended_weight"] > rows["NVDA"]["recommended_weight"], rows
    assert rows["QQQ"]["score_multiplier"] > 1.0, rows
    assert rows["NVDA"]["score_multiplier"] < 1.0, rows
    assert rows["QQQ"]["action"] in {"INCREASE", "SLIGHT_INCREASE"}, rows
    assert rows["NVDA"]["action"] == "REDUCE", rows
    diag = alloc["allocation_diagnostics"]
    assert diag["stock_budget_before_relative_distribution"] > 0, diag
    assert "relative_scores" in diag and set(diag["relative_scores"]) == {"QQQ", "NVDA"}, diag
    print("PASS probability_weighted_allocation")


if __name__ == "__main__":
    main()
