from __future__ import annotations

import tempfile
from pathlib import Path

from pra_v5_1.portfolio_slots import (
    MAX_PORTFOLIO_SLOTS,
    PortfolioSlot,
    PortfolioSlotAsset,
    load_portfolio_slots,
    save_portfolio_slots,
)


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "portfolio_slots.json"
        store = load_portfolio_slots(path)
        assert len(store.slots) == MAX_PORTFOLIO_SLOTS
        assert store.get(1).is_empty()
        slot = PortfolioSlot(
            slot_id=1,
            name="test",
            operating_capital=10_000_000,
            assets=[
                PortfolioSlotAsset("QQQ", "Nasdaq", "etf", 3_000_000),
                PortfolioSlotAsset("CASH", "Cash", "cash", 1_000_000),
            ],
            saved_at="now",
        )
        store.set(slot)
        save_portfolio_slots(store, path)
        loaded = load_portfolio_slots(path)
        loaded_slot = loaded.get(1)
        assert not loaded_slot.is_empty()
        assert loaded_slot.name == "test"
        assert loaded_slot.operating_capital == 10_000_000
        assert len(loaded_slot.assets) == 2
        assert loaded_slot.assets[0].ticker == "QQQ"
        assert loaded_slot.assets[1].ticker == "CASH"
        assert loaded_slot.display_label().startswith("슬롯 1: test")
        loaded.clear(1)
        save_portfolio_slots(loaded, path)
        assert load_portfolio_slots(path).get(1).is_empty()
    print("PASS portfolio_slots")


if __name__ == "__main__":
    main()
