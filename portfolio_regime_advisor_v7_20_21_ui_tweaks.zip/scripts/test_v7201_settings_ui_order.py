from pathlib import Path


def test_settings_ui_order():
    text = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
    pred_mode = text.index('self._settings_option(form, 5, "예측 방식"')
    train_window = text.index('self._settings_entry(form, 6, "최근 학습 윈도우(일)"')
    capital = text.index('self._settings_option(form, 7, "자본 배분 방식"')
    start = text.index('self._settings_entry(form, 8, "학습 시작일"')
    assert pred_mode < train_window < capital < start


def test_ui_file_location_documented():
    text = Path("docs/V7_20_1_SETTINGS_UI_ORDER.md").read_text(encoding="utf-8")
    assert "src/pra_v5_1/ctk_app.py" in text
    assert "_build_settings_tab" in text


if __name__ == "__main__":
    test_settings_ui_order()
    test_ui_file_location_documented()
    print("PASS v7201_settings_ui_order")
