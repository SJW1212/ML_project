from pathlib import Path
import tempfile
import pandas as pd

from pra_v5_1.cache import MarketDataCache
from pra_v5_1.provider import DailyMarketDataUpdater
from pra_v5_1.schemas import EvaluateSettings


def test_schema_default_auto():
    s = EvaluateSettings()
    assert s.provider == "auto"


def test_auto_provider_writes_auto_on_yahoo_fallback(monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        cache = MarketDataCache(Path(td) / "market_cache")
        updater = DailyMarketDataUpdater(cache)

        def fail_kis(self, ticker, start, end=None):
            raise RuntimeError("no kis credentials")

        def ok_yahoo(self, ticker, start, end=None):
            return pd.DataFrame({
                "Date": ["2024-01-02", "2024-01-03"],
                "Open": [1.0, 1.1],
                "High": [1.2, 1.3],
                "Low": [0.9, 1.0],
                "Close": [1.1, 1.2],
                "Volume": [1000, 1200],
            })

        monkeypatch.setattr("pra_v5_1.provider.KisQuoteProvider.download_ohlcv", fail_kis)
        monkeypatch.setattr("pra_v5_1.provider.YahooMarketDataProvider.download_ohlcv", ok_yahoo)
        status = updater.update_daily(["AAPL"], provider="auto", start="2024-01-01", force=True)
        assert status.updated == ["AAPL"]
        assert not status.errors
        assert cache.has_ohlcv("AAPL", "auto")
        assert cache.has_ohlcv("AAPL", "yahoo")
        assert "fell back to Yahoo" in "\n".join(status.notes or [])


if __name__ == "__main__":
    test_schema_default_auto()
    # monkeypatch fixture is pytest-only; this script is intended for pytest.
    print("PASS schema_default_auto")
