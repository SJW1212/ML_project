from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "src" / "pra_v5_1" / "model_engine" / "xgb_recency_weighted_v8_6_41_model_label_fixed.py"
text = MODEL.read_text(encoding="utf-8")

assert "latest_only_prediction_has_no_historical_backtest_series" in text
assert "if not episodes:" in text
assert "pd.DataFrame(columns=[" in text
assert "and not is_latest_only_run" in text
print("PASS v7208_latest_only_diagnostics_guard")
