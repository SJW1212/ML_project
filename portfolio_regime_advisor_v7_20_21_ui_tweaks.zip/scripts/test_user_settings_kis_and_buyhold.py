from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pandas as pd

from pra_v5_1.config import AppConfig
from pra_v5_1.kis_provider import KisCredentialStore, KisSettings
from pra_v5_1.schemas import EvaluateSettings, PortfolioAssetInput, PortfolioEvaluateRequest
from pra_v5_1.service import PortfolioRegimeAdvisorService


def test_kis_store_redaction_and_secret_persistence(tmp: Path) -> None:
    store = KisCredentialStore(tmp / "config")
    settings = KisSettings(app_key="ABCDEFGH1234", app_secret="SECRETKEY9876", account_no="12345678", overseas_exchange="NAS")
    path = store.save(settings, persist_secret=True)
    assert path.exists()
    loaded = store.load()
    assert loaded.app_key == settings.app_key
    assert loaded.app_secret == settings.app_secret
    redacted = loaded.redacted()
    assert redacted["configured"] is True
    assert redacted["app_key"].startswith("ABCD") and redacted["app_key"].endswith("1234")
    assert "SECRETKEY9876" not in json.dumps(redacted)


def test_buy_and_hold_metrics_are_attached(tmp: Path) -> None:
    os.chdir(tmp)
    svc = PortfolioRegimeAdvisorService(AppConfig(storage_root=Path("storage")))
    dates = pd.date_range("2024-01-01", periods=5, freq="D")
    qqq = pd.DataFrame({"Date": dates, "stock_next_return": [0.01, 0.0, -0.01, 0.02, 0.0]})
    nvda = pd.DataFrame({"Date": dates, "stock_next_return": [0.02, -0.01, 0.0, 0.01, -0.005]})
    req = PortfolioEvaluateRequest(
        portfolio=[
            PortfolioAssetInput(ticker="QQQ", asset_type="etf", current_value=250000),
            PortfolioAssetInput(ticker="NVDA", asset_type="stock", current_value=250000),
            PortfolioAssetInput(ticker="BOND_BUCKET", asset_type="bond_bucket", current_value=100000),
            PortfolioAssetInput(ticker="CASH", asset_type="cash", current_value=150000),
        ],
        settings=EvaluateSettings(provider="auto"),
    )
    metrics, df, notes = svc._current_buy_and_hold_performance(req, {"QQQ": qqq, "NVDA": nvda}, provider="auto")
    assert len(df) == 5
    assert metrics["n_days"] == 5
    assert "final_capital" in metrics
    assert isinstance(notes, list)


def test_basic_screen_no_provider_risk_controls() -> None:
    text = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
    current_tab = text[text.index("def _build_current_tab"):text.index("def _build_result_tab")]
    assert "CTkOptionMenu(settings, values=PROVIDERS" not in current_tab
    assert "CTkOptionMenu(settings, values=RISK_PROFILES" not in current_tab
    assert "데이터 소스·위험 성향" in current_tab


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        test_kis_store_redaction_and_secret_persistence(tmp)
    with tempfile.TemporaryDirectory() as d:
        root = Path.cwd()
        try:
            test_buy_and_hold_metrics_are_attached(Path(d))
        finally:
            os.chdir(root)
    test_basic_screen_no_provider_risk_controls()
    print("PASS user_settings_kis_and_buyhold")
