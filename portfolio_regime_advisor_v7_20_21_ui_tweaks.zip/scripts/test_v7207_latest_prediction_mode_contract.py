from pathlib import Path


def main() -> None:
    app = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
    schemas = Path("src/pra_v5_1/schemas.py").read_text(encoding="utf-8")
    pred = Path("src/pra_v5_1/prediction_engine.py").read_text(encoding="utf-8")
    model = Path("src/pra_v5_1/model_engine/xgb_recency_weighted_v8_6_41_model_label_fixed.py").read_text(encoding="utf-8")
    user_settings = Path("src/pra_v5_1/user_settings.py").read_text(encoding="utf-8")

    assert "예측 방식" in app
    assert "최근 학습 윈도우(일)" in app
    assert "prediction_run_mode" in schemas
    assert "latest_train_rows" in schemas
    assert "--latest-only" in pred
    assert "--latest-train-rows" in pred
    assert "run_latest_window_prediction" in model
    assert "latest_only_prediction" in model
    assert "prediction_run_mode: str = \"latest\"" in user_settings
    assert "latest_train_rows: int = 756" in user_settings
    print("PASS v7207_latest_prediction_mode_contract")


if __name__ == "__main__":
    main()
