from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import pandas as pd

# Make src importable when run from project root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from pra_v5_1.cache import MarketDataCache
from pra_v5_1.prediction_engine import PredictionGenerationService, PredictionRepository, SOURCE_TAG


def main() -> None:
    base = Path(tempfile.mkdtemp(prefix="pra_long_root_"))
    # Emulate the user's duplicated long extracted folder structure. The invariant
    # is that XGBoost output is written outside this deep project root, in a short
    # OS-managed path, so the resolved CSV path is independent of extraction depth.
    project = base / ("portfolio_regime_advisor_v7_9_windows_path_fix_" + "x" * 40) / ("portfolio_regime_advisor_v7_9_windows_path_fix_" + "x" * 40)
    project.mkdir(parents=True)
    old_cwd = Path.cwd()
    try:
        os.chdir(project)
        script = project / "mock_xgb.py"
        script.write_text(
            r'''
import argparse
import json
from pathlib import Path
import pandas as pd

SOURCE_TAG = "xgb_recency_weighted_v8_6_41_model_label_fixed"
parser = argparse.ArgumentParser()
parser.add_argument("--target-ticker", required=True)
parser.add_argument("--result-dir", required=True)
parser.add_argument("--speed-profile")
parser.add_argument("--h10-down-only", action="store_true")
parser.add_argument("--transaction-cost-rate")
args = parser.parse_args()
# The application should pass a short absolute OS-managed path, not a path
# under the user's deeply extracted project directory.
out = Path(args.result_dir)
assert out.is_absolute(), args.result_dir
assert "x" * 40 not in str(out), args.result_dir
(project_root_marker := Path.cwd() / "seen_result_dir.txt").write_text(str(out), encoding="utf-8")
out.mkdir(parents=True, exist_ok=True)
safe = ''.join(ch.lower() if ch.isalnum() else '_' for ch in args.target_ticker).strip('_') or 'asset'
prefix = f"{safe}_{SOURCE_TAG}"
df = pd.DataFrame([
    {
        "Date": "2025-01-02",
        "prob_normal": 0.70,
        "prob_high_vol": 0.20,
        "prob_overall_risk": 0.25,
        "prob_up_strengthening_5d": 0.55,
        "prob_up_strengthening_10d": 0.56,
        "prob_up_strengthening_20d": 0.57,
        "prob_up_strengthening_score": 0.56,
        "prob_down_strengthening_5d": 0.20,
        "prob_down_strengthening_10d": 0.21,
        "prob_down_strengthening_20d": 0.22,
        "prob_down_strengthening_score": 0.21,
        "stock_weight": 0.82,
        "bond_weight": 0.117,
        "cash_weight": 0.063,
        "stock_next_return": 0.001,
    }
])
df.to_csv(out / f"{prefix}_predictions.csv", index=False, encoding="utf-8-sig")
(out / f"{prefix}_summary.json").write_text(json.dumps({"ok": True}), encoding="utf-8")
''',
            encoding="utf-8",
        )
        cache = MarketDataCache(project / "storage" / "market_cache")
        repo = PredictionRepository(project / "storage" / "predictions" / "v8_6_41")
        service = PredictionGenerationService(cache, repo, project / "storage" / "runs", script)
        results = service.generate_external_v8641_xgb(["QQQ", "NVDA"], provider="auto", force=True)
        assert all(not r.errors for r in results), results
        assert repo.prediction_path("QQQ").exists()
        assert repo.prediction_path("NVDA").exists()
        seen = (project / "seen_result_dir.txt").read_text(encoding="utf-8")
        assert "x" * 40 not in seen, seen
        assert not (project / ".pra_xgb").exists(), "project-local .pra_xgb should not be used when OS temp/local appdata is writable"
        # Resolve the output prediction path from the captured result dir and
        # assert the final CSV path remains below a conservative Windows limit.
        out = Path(seen)
        pred_path = out / f"qqq_{SOURCE_TAG}_predictions.csv"
        assert len(str(pred_path)) < 240, str(pred_path)
    finally:
        os.chdir(old_cwd)
        shutil.rmtree(base, ignore_errors=True)
    print("PASS windows_short_xgb_output_path")


if __name__ == "__main__":
    main()
