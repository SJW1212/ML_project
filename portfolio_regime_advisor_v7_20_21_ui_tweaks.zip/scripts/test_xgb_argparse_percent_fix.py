from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    script = root / "src" / "pra_v5_1" / "model_engine" / "xgb_recency_weighted_v8_6_41_model_label_fixed.py"
    proc = subprocess.run([sys.executable, str(script), "--help"], cwd=str(root), text=True, capture_output=True)
    if proc.returncode != 0:
        raise SystemExit(proc.stderr or proc.stdout)
    out = proc.stdout + proc.stderr
    assert "100%" in out, "help output should display literal percent signs"
    assert "unsupported format character" not in out
    print("PASS xgb_argparse_percent_fix")


if __name__ == "__main__":
    main()
