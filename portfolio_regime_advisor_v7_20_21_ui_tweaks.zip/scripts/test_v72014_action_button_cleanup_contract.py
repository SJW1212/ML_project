from __future__ import annotations


def main() -> None:
    app = open("src/pra_v5_1/ctk_app.py", "r", encoding="utf-8").read()
    init = open("src/pra_v5_1/__init__.py", "r", encoding="utf-8").read()

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert "ACTION_BUTTON_HEIGHT = 46" in app
    assert "ACTION_BUTTON_FONT_SIZE = 15" in app
    assert "ACTION_BUTTON_CORNER_RADIUS = 10" in app
    assert 'text="모델 실행"' in app
    assert 'text="실행 취소"' in app
    assert "font=action_button_font" in app
    assert "height=ACTION_BUTTON_HEIGHT" in app
    assert "corner_radius=ACTION_BUTTON_CORNER_RADIUS" in app
    assert 'text="예측 취소"' not in app
    print("PASS v72014_action_button_cleanup_contract")


if __name__ == "__main__":
    main()
