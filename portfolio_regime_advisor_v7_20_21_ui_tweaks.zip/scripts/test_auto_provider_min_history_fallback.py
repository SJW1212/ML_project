from pathlib import Path
import tempfile
import pandas as pd

from pra_v5_1.cache import MarketDataCache
from pra_v5_1.provider import DailyMarketDataUpdater


def make_df(rows: int, start="2020-01-01"):
    dates = pd.bdate_range(start=start, periods=rows)
    return pd.DataFrame({
        "Date": dates,
        "Open": range(1, rows+1),
        "High": range(2, rows+2),
        "Low": range(rows),
        "Close": range(1, rows+1),
        "Volume": [1000] * rows,
    })


class FakeKis:
    def __init__(self, rows):
        self.rows = rows
    def download_ohlcv(self, ticker, start, end=None):
        return make_df(self.rows, start=start)


class FakeYahoo:
    def __init__(self, rows):
        self.rows = rows
    def download_ohlcv(self, ticker, start, end=None):
        return make_df(self.rows, start=start)


def main():
    with tempfile.TemporaryDirectory() as td:
        updater = DailyMarketDataUpdater(MarketDataCache(Path(td)))
        updater.kis_status = lambda: {}
        # Monkeypatch module-level provider classes used inside update_daily.
        import pra_v5_1.provider as provider_module
        old_kis = provider_module.KisQuoteProvider
        old_yahoo = provider_module.YahooMarketDataProvider
        try:
            provider_module.KisQuoteProvider = lambda store: FakeKis(100)
            provider_module.YahooMarketDataProvider = lambda: FakeYahoo(1200)
            st = updater.update_daily(["QQQ"], provider="auto", start="2013-01-01", force=True)
            assert not st.errors, st.errors
            auto_df = updater.cache.read_ohlcv("QQQ", "auto")
            yahoo_df = updater.cache.read_ohlcv("QQQ", "yahoo")
            kis_df = updater.cache.read_ohlcv("QQQ", "kis")
            assert len(kis_df) == 100
            assert len(yahoo_df) == 1200
            assert len(auto_df) == 1200, len(auto_df)
            assert any("fell back to Yahoo" in n for n in st.notes or []), st.notes
        finally:
            provider_module.KisQuoteProvider = old_kis
            provider_module.YahooMarketDataProvider = old_yahoo
    print("PASS auto_provider_min_history_fallback")


if __name__ == "__main__":
    main()
