from __future__ import annotations

from pathlib import Path

APP = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
SCHEMAS = Path("src/pra_v5_1/schemas.py").read_text(encoding="utf-8")
SETTINGS = Path("src/pra_v5_1/user_settings.py").read_text(encoding="utf-8")
ENGINE = Path("src/pra_v5_1/prediction_engine.py").read_text(encoding="utf-8")
MODEL = Path("src/pra_v5_1/model_engine/xgb_recency_weighted_v8_6_41_model_label_fixed.py").read_text(encoding="utf-8")


def main() -> None:
    # Req 3: tab labels have no leading "N " number prefix.
    for label in ("현재 포트폴리오", "모델 추천", "포트폴리오 성과", "모델 평가", "사용자 설정"):
        assert f'self.tabs.add("{label}")' in APP, f"tab missing: {label}"
    for n in range(1, 6):
        assert f'self.tabs.add("{n} ' not in APP, f"numbered tab still present: {n}"

    # Req 1 + 2: prediction start/end date settings exist and are wired end-to-end.
    assert '"예측 시작일"' in APP and '"예측 종료일"' in APP
    assert "setting_model_backtest_start_date" in APP and "setting_model_end_date" in APP
    assert "backtest_start_date=(user_settings.model_backtest_start_date or None)" in APP
    assert "end_date=(user_settings.model_end_date or None)" in APP
    assert "model_backtest_start_date" in SETTINGS and "model_end_date" in SETTINGS
    assert "backtest_start_date: Optional[str] = None" in SCHEMAS
    assert "backtest_start_date" in ENGINE and '"--backtest-start-date"' in ENGINE
    assert '"--backtest-start-date"' in MODEL
    assert "cfg.backtest_start_date = str(args.backtest_start_date)" in MODEL

    # Req 4 reverted per later user request: latest_train_rows limit restored.
    assert "latest_train_rows: int = Field(default=756, ge=504, le=2520)" in SCHEMAS
    assert "min(max(int(self.latest_train_rows), 504), 2520)" in SETTINGS
    assert "int(max(504, min(int(latest_train_rows or 756), 2520)))" in MODEL

    print("PASS v72020_prediction_window_and_tab_contract")


if __name__ == "__main__":
    main()
