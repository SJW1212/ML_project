from __future__ import annotations

from pathlib import Path

APP = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")


def main() -> None:
    # Sort consolidated into a single readonly combobox (old 비중↓/비중↑ buttons gone).
    assert 'ctk.CTkComboBox(' in APP
    assert 'values=["비중 내림차순", "비중 오름차순"]' in APP
    assert 'state="readonly"' in APP
    assert "command=self.on_sort_order_changed" in APP
    assert 'text="비중↓"' not in APP and 'text="비중↑"' not in APP

    # Default window widened left-right; settings no longer clipped.
    assert 'self.geometry("1380x780")' in APP
    assert "self.minsize(1200, 680)" in APP

    print("PASS v72021_combo_sort_and_window_contract")


if __name__ == "__main__":
    main()
