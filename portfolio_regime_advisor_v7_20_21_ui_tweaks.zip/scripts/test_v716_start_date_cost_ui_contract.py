from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from pra_v5_1.user_settings import UserSettings
from pra_v5_1.prediction_engine import PredictionGenerationService, PredictionRepository
from pra_v5_1.cache import MarketDataCache
from pra_v5_1.config import AppConfig


def test_user_settings_start_date():
    s = UserSettings(model_start_date='2010-01-04', transaction_cost_bps=10).normalized()
    assert s.model_start_date == '2010-01-04'
    assert abs((s.transaction_cost_bps / 100.0) - 0.1) < 1e-12


def test_prediction_engine_signature_accepts_start_end():
    cfg = AppConfig.from_json()
    repo = PredictionRepository(cfg.storage_root / 'predictions' / 'v8_6_41')
    svc = PredictionGenerationService(MarketDataCache(cfg.storage_root / 'market_cache' / 'ohlcv'), repo, cfg.storage_root / 'runs')
    # Do not run the model. Only verify the new callable contract exists.
    import inspect
    sig = inspect.signature(svc.generate_external_v8641_xgb)
    assert 'start' in sig.parameters
    assert 'end' in sig.parameters


if __name__ == '__main__':
    test_user_settings_start_date()
    test_prediction_engine_signature_accepts_start_end()
    print('PASS v716_start_date_cost_ui_contract')
