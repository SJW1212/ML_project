from pathlib import Path

p = Path("src/pra_v5_1/ctk_app.py")
s = p.read_text(encoding="utf-8")
assert 'self.tab_perf = self.tabs.add("포트폴리오 성과")' in s
assert 'def _build_performance_tab' in s
assert 'def _render_performance_page' in s
assert 'CAGR' in s and 'MDD' in s and 'Sharpe' in s
print("PASS ctk_performance_page")
