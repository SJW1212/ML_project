from __future__ import annotations


def main() -> None:
    app = open("src/pra_v5_1/ctk_app.py", "r", encoding="utf-8").read()
    svc = open("src/pra_v5_1/service.py", "r", encoding="utf-8").read()
    init = open("src/pra_v5_1/__init__.py", "r", encoding="utf-8").read()

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert "def _safe_render_performance_page" in app
    assert "storage/latest_customtkinter_render_error.json" in app
    assert "성과 표시 오류" in app
    assert "모델 평가 표시 오류" in app
    assert 'self.tabs.set("포트폴리오 성과")' in app
    assert 'walk_forward 모드: 모델 평가 표시' in app
    assert 'performance.metrics 없음 또는 비어 있음' in app
    assert '"status": {' in svc
    assert '"recommended_rows"' in svc
    assert '"buy_and_hold_rows"' in svc
    print("PASS v72018_walkforward_render_guard_contract")


if __name__ == "__main__":
    main()
