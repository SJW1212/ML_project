from pra_v5_1.provider import DailyMarketDataUpdater

# Structural check: hybrid code must persist raw KIS data and hybrid merged data.
import inspect
src = inspect.getsource(DailyMarketDataUpdater.update_daily)
assert 'self.cache.write_ohlcv(t, kis_df, "kis")' in src
assert 'self.cache.write_ohlcv(t, merged, "hybrid")' in src
assert 'self.cache.write_ohlcv(t, yahoo_df, "yahoo")' in src
print("PASS kis_cache_policy")
