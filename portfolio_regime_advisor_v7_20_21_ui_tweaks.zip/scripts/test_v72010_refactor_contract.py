from __future__ import annotations

from datetime import datetime, timezone

import pandas as pd

from pra_v5_1.allocation import (
    FALLBACK_DEFAULT_BOND_WEIGHT,
    FALLBACK_DEFAULT_CASH_WEIGHT,
    FALLBACK_DEFAULT_STOCK_WEIGHT,
    FALLBACK_ZERO_BOND_WEIGHT,
    FALLBACK_ZERO_CASH_WEIGHT,
    FALLBACK_ZERO_STOCK_WEIGHT,
)
from pra_v5_1.cache import CACHE_FRESHNESS_DAYS, MarketDataCache
from pra_v5_1.constants import MODEL_VERSION, TRADING_DAYS_PER_YEAR
from pra_v5_1.ohlcv import normalize_ohlcv_frame
from pra_v5_1.portfolio_slots import utc_now_iso as slot_utc_now_iso
from pra_v5_1.provider import DailyMarketDataUpdater
from pra_v5_1.signals import SignalClassifier
from pra_v5_1.utils import utc_now_iso


REQUIRED = ["Date", "Open", "High", "Low", "Close", "Volume"]


def legacy_cache_normalize_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame(columns=REQUIRED)
    out = df.copy()
    rename = {c: str(c).strip().title() for c in out.columns}
    out = out.rename(columns=rename)
    if "Adj Close" in out.columns and "Close" not in out.columns:
        out["Close"] = out["Adj Close"]
    if "Date" not in out.columns:
        if isinstance(out.index, pd.DatetimeIndex):
            out = out.reset_index().rename(columns={out.index.name or "index": "Date"})
        else:
            raise ValueError("OHLCV DataFrame must include Date column or DatetimeIndex")
    for col in REQUIRED:
        if col not in out.columns:
            if col == "Volume":
                out[col] = 0
            else:
                raise ValueError(f"Missing OHLCV column: {col}")
    out = out[REQUIRED].copy()
    out["Date"] = pd.to_datetime(out["Date"]).dt.date.astype(str)
    for col in ["Open", "High", "Low", "Close", "Volume"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["Date", "Open", "High", "Low", "Close"]).drop_duplicates("Date").sort_values("Date")
    return out.reset_index(drop=True)


def legacy_provider_normalize_frame(df: pd.DataFrame | None) -> pd.DataFrame | None:
    if df is None or df.empty:
        return None
    out = df.copy()
    if "Date" not in out.columns and isinstance(out.index, pd.DatetimeIndex):
        out = out.reset_index().rename(columns={out.index.name or "index": "Date"})
    if "Adj Close" in out.columns and "Close" not in out.columns:
        out["Close"] = out["Adj Close"]
    for col in REQUIRED:
        if col not in out.columns:
            if col == "Volume":
                out[col] = 0.0
            else:
                raise ValueError(f"Provider output missing OHLCV column: {col}")
    out = out[REQUIRED].copy()
    out["Date"] = pd.to_datetime(out["Date"], errors="coerce").dt.strftime("%Y-%m-%d")
    for col in ["Open", "High", "Low", "Close", "Volume"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["Date", "Open", "High", "Low", "Close"])
    out = out.drop_duplicates(subset=["Date"], keep="last").sort_values("Date").reset_index(drop=True)
    return out


def assert_frame_bytes_equal(a: pd.DataFrame | None, b: pd.DataFrame | None) -> None:
    assert (a is None) == (b is None)
    if a is None:
        return
    assert a.to_csv(index=False) == b.to_csv(index=False)


def test_ohlcv_normalizer_equivalence() -> None:
    raw_cache = pd.DataFrame(
        {
            " date ": ["2024-01-02", "2024-01-02", "2024-01-03"],
            " open ": ["10", "99", "11"],
            " high ": ["12", "100", "13"],
            " low ": ["9", "98", "10"],
            " adj close ": ["11", "97", "12"],
        }
    )
    assert_frame_bytes_equal(legacy_cache_normalize_ohlcv(raw_cache), MarketDataCache.normalize_ohlcv(raw_cache))

    idx_df = pd.DataFrame(
        {
            "Open": [1, 2],
            "High": [2, 3],
            "Low": [0.5, 1.5],
            "Close": [1.5, 2.5],
        },
        index=pd.to_datetime(["2024-02-01", "2024-02-02"]),
    )
    assert_frame_bytes_equal(legacy_cache_normalize_ohlcv(idx_df), MarketDataCache.normalize_ohlcv(idx_df))

    provider_raw = pd.DataFrame(
        {
            "Date": ["2024-01-02", "2024-01-02", "bad-date", "2024-01-03"],
            "Open": ["10", "99", "1", "11"],
            "High": ["12", "100", "2", "13"],
            "Low": ["9", "98", "0", "10"],
            "Close": ["11", "97", "1", "12"],
        }
    )
    assert_frame_bytes_equal(
        legacy_provider_normalize_frame(provider_raw),
        DailyMarketDataUpdater._normalize_provider_frame(provider_raw),
    )

    # The two original layers intentionally had different duplicate-date keep policies.
    cache_norm = MarketDataCache.normalize_ohlcv(
        pd.DataFrame(
            {
                "Date": ["2024-01-02", "2024-01-02"],
                "Open": [10, 99],
                "High": [12, 100],
                "Low": [9, 98],
                "Close": [11, 97],
                "Volume": [1, 2],
            }
        )
    )
    provider_norm = DailyMarketDataUpdater._normalize_provider_frame(
        pd.DataFrame(
            {
                "Date": ["2024-01-02", "2024-01-02"],
                "Open": [10, 99],
                "High": [12, 100],
                "Low": [9, 98],
                "Close": [11, 97],
                "Volume": [1, 2],
            }
        )
    )
    assert float(cache_norm["Open"].iloc[0]) == 10.0  # keep first
    assert float(provider_norm["Open"].iloc[0]) == 99.0  # keep last


def test_constants_and_signal_boundaries() -> None:
    assert MODEL_VERSION == "v8_6_41"
    assert TRADING_DAYS_PER_YEAR == 252
    assert CACHE_FRESHNESS_DAYS == 4
    assert (FALLBACK_DEFAULT_STOCK_WEIGHT, FALLBACK_DEFAULT_BOND_WEIGHT, FALLBACK_DEFAULT_CASH_WEIGHT) == (0.82, 0.117, 0.063)
    assert (FALLBACK_ZERO_STOCK_WEIGHT, FALLBACK_ZERO_BOND_WEIGHT, FALLBACK_ZERO_CASH_WEIGHT) == (0.0, 0.65, 0.35)

    clf = SignalClassifier()
    assert clf.classify({"prob_overall_risk": 0.65})["risk_class"] == "HIGH_RISK"
    assert clf.classify({"prob_high_vol": 0.40, "prob_overall_risk": 0.0})["risk_class"] == "WATCH"
    assert clf.classify({"prob_down_strengthening_score": 0.55, "prob_up_strengthening_score": 0.10})["direction_class"] == "DOWN_STRENGTH"
    assert clf.classify({"prob_up_strengthening_score": 0.55, "prob_down_strengthening_score": 0.10})["direction_class"] == "UP_STRENGTH"


def test_utc_now_iso_unification() -> None:
    raw = utc_now_iso()
    seconds = utc_now_iso(timespec="seconds")
    slot_raw = slot_utc_now_iso()
    datetime.fromisoformat(raw)
    datetime.fromisoformat(seconds)
    datetime.fromisoformat(slot_raw)
    assert "." not in slot_raw.split("+")[0], slot_raw


def main() -> None:
    test_ohlcv_normalizer_equivalence()
    test_constants_and_signal_boundaries()
    test_utc_now_iso_unification()
    print("PASS v72010_refactor_contract")


if __name__ == "__main__":
    main()
