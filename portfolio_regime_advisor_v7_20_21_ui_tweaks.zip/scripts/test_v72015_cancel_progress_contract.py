from __future__ import annotations


def main() -> None:
    app = open("src/pra_v5_1/ctk_app.py", "r", encoding="utf-8").read()
    provider = open("src/pra_v5_1/provider.py", "r", encoding="utf-8").read()
    service = open("src/pra_v5_1/service.py", "r", encoding="utf-8").read()
    init = open("src/pra_v5_1/__init__.py", "r", encoding="utf-8").read()

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert "정밀 백테스트 실행 확인" in app
    assert "작업 스레드 시작" in app
    assert "백엔드 초기화 완료" in app
    assert "cancel_event: object | None = None" in provider
    assert "progress_callback: Callable[[int, int, str, str], None] | None = None" in provider
    assert "raise PraCancelledError(\"사용자가 데이터 갱신을 취소했습니다.\")" in provider
    assert "KIS credentials are not configured; auto provider skips KIS and uses Yahoo directly." in provider
    assert "timeout=20" in provider
    assert "KisQuoteProvider(self.kis_store, timeout=8)" in provider
    assert "update_progress" in service
    assert "self.update_daily(update_req, cancel_event=cancel_event, progress_callback=update_progress)" in service
    print("PASS v72015_cancel_progress_contract")


if __name__ == "__main__":
    main()
