from __future__ import annotations

from types import SimpleNamespace

from pra_v5_1.ctk_app import MinimalCTkApp


class V:
    def __init__(self, value: str = ""):
        self.value = value
    def get(self):
        return self.value


def row(ticker: str = "", asset_type: str = "stock"):
    return SimpleNamespace(ticker=V(ticker), asset_type=V(asset_type))


def main() -> None:
    # These methods intentionally work on lightweight row-like objects. They
    # should not validate blank tickers during UI recalc/save/load callbacks.
    assert MinimalCTkApp._row_ticker_text(None, row("")) == ""
    assert MinimalCTkApp._is_cash_row(None, row("", "stock")) is False
    assert MinimalCTkApp._is_cash_row(None, row("CASH", "stock")) is True
    assert MinimalCTkApp._is_cash_row(None, row("", "cash")) is True
    assert MinimalCTkApp._is_cash_row(None, row("bad space", "stock")) is False
    print("PASS portfolio_slot_ui_safety")


if __name__ == "__main__":
    main()
