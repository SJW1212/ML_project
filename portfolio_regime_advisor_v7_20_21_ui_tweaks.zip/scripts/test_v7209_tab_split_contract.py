from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CTK = ROOT / "src" / "pra_v5_1" / "ctk_app.py"


def main() -> None:
    text = CTK.read_text(encoding="utf-8")
    assert 'self.tabs.add("포트폴리오 성과")' in text
    assert 'self.tabs.add("모델 평가")' in text
    assert 'self.tabs.add("사용자 설정")' in text
    assert 'def _build_portfolio_performance_tab' in text
    assert 'def _build_model_evaluation_tab' in text
    assert 'latest 모드: 모델 평가는 표시하지 않음' in text
    assert text.index('"자본 배분 방식"') < text.index('"최근 학습 윈도우(일)"')
    print("PASS v7209_tab_split_contract")


if __name__ == "__main__":
    main()
