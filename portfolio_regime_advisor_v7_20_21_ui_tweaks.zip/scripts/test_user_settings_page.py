from pathlib import Path
import tempfile

from pra_v5_1.user_settings import UserSettings, load_user_settings, save_user_settings
from pra_v5_1.allocation import PortfolioAllocationService
from pra_v5_1.schemas import EvaluateSettings, PortfolioAssetInput, PortfolioEvaluateRequest


def test_user_settings_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "user_settings.json"
        s = UserSettings(
            operating_capital=12345678,
            risk_profile="conservative",
            provider="auto",
            speed_profile="fast",
            capital_mode="equal",
            min_cash_pct=5,
            max_asset_pct=35,
            transaction_cost_bps=7.5,
            risk_sensitivity=1.25,
        )
        save_user_settings(s, path)
        loaded = load_user_settings(path)
        assert loaded.operating_capital == 12345678
        assert loaded.risk_profile == "conservative"
        assert loaded.provider == "auto"
        assert loaded.min_cash_pct == 5
        assert loaded.max_asset_pct == 35


def test_user_settings_backward_compatibility():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "user_settings.json"
        path.write_text('{"total_funds": 7770000, "available_cash": 1110000, "risk_profile":"aggressive"}', encoding="utf-8")
        loaded = load_user_settings(path)
        assert loaded.operating_capital == 7770000
        assert not hasattr(loaded, "available_cash")
        assert loaded.risk_profile == "aggressive"


def test_risk_profile_affects_allocation():
    assets = [
        PortfolioAssetInput(ticker="QQQ", asset_type="etf", current_value=1000),
        PortfolioAssetInput(ticker="AAPL", asset_type="stock", current_value=1000),
        PortfolioAssetInput(ticker="CASH", asset_type="cash", current_value=0),
    ]
    preds = {
        "QQQ": {"stock_weight": 0.8, "bond_weight": 0.1, "cash_weight": 0.1, "prob_high_vol": 0.7, "prob_overall_risk": 0.7},
        "AAPL": {"stock_weight": 0.8, "bond_weight": 0.1, "cash_weight": 0.1, "prob_high_vol": 0.7, "prob_overall_risk": 0.7},
    }
    allocator = PortfolioAllocationService()
    base_settings = EvaluateSettings(capital_mode="current_weight")
    cons = PortfolioEvaluateRequest(portfolio=assets, risk_profile="conservative", settings=base_settings)
    aggr = PortfolioEvaluateRequest(portfolio=assets, risk_profile="aggressive", settings=base_settings)
    cons_alloc = allocator.allocate(cons, preds)
    aggr_alloc = allocator.allocate(aggr, preds)
    assert cons_alloc["portfolio_totals"]["stock_weight"] < aggr_alloc["portfolio_totals"]["stock_weight"]
    assert cons_alloc["allocation_diagnostics"]["risk_profile"] == "conservative"
    assert aggr_alloc["allocation_diagnostics"]["risk_profile"] == "aggressive"


def test_auto_cash_ui_contract():
    text = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
    assert "운용자금" in text
    assert "현재 보유 자금" not in text
    assert "현재 현금" not in text
    assert "_ensure_auto_cash_row" in text
    assert "주식/채권 입력금액이 운용자금을 초과" in text


if __name__ == "__main__":
    test_user_settings_roundtrip()
    test_user_settings_backward_compatibility()
    test_risk_profile_affects_allocation()
    test_auto_cash_ui_contract()
    print("PASS user_settings_page")
