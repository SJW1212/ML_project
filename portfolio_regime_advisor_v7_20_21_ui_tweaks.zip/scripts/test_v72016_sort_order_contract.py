from __future__ import annotations


def main() -> None:
    app = open("src/pra_v5_1/ctk_app.py", "r", encoding="utf-8").read()
    init = open("src/pra_v5_1/__init__.py", "r", encoding="utf-8").read()

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert 'values=["비중 내림차순", "비중 오름차순"]' in app
    assert "self.sort_order_var" in app
    assert "def on_sort_order_changed(self, choice: str)" in app
    assert 'descending = str(choice).strip() != "비중 오름차순"' in app
    assert "descending=True" in app
    assert "def sort_current_portfolio_by_weight(self, show_message: bool = True, descending: bool = True)" in app
    assert "reverse=bool(descending)" in app
    assert 'direction = "내림차순" if descending else "오름차순"' in app
    assert "CASH row remains at the bottom" in app
    assert "self.sort_current_portfolio_by_weight(show_message=False, descending=True)" in app
    print("PASS v72016_sort_order_contract")


if __name__ == "__main__":
    main()
