from pra_v5_1.allocation import PortfolioAllocationService
from pra_v5_1.schemas import PortfolioEvaluateRequest
from pra_v5_1.validation import ValidationService


def _request(capital_mode="current_weight"):
    return PortfolioEvaluateRequest(
        portfolio=[
            {"ticker": "AAPL", "name": "Apple", "asset_type": "stock", "current_value": 6000000},
            {"ticker": "QQQ", "name": "QQQ", "asset_type": "etf", "current_value": 4000000},
        ],
        settings={"capital_mode": capital_mode},
    )


def main():
    allocator = PortfolioAllocationService()
    validator = ValidationService()

    # Missing/invalid model weights should no longer pass silently; allocation
    # can still be computed, but validation must expose the fallback.
    req = _request()
    alloc = allocator.allocate(req, latest_predictions={"AAPL": {}, "QQQ": {}})
    checks = validator.validate_allocation(alloc)
    statuses = {(c["check_name"], c["status"]) for c in checks}
    assert ("model_weight_fallback_default_all_assets", "WARN") in statuses, checks
    assert alloc["allocation_diagnostics"]["fallback_default_count"] == 2

    # inverse_vol is now real behavior, not a silent current-weight fallback.
    req_iv = _request(capital_mode="inverse_vol")
    preds = {
        "AAPL": {"stock_weight": 1.0, "bond_weight": 0.0, "cash_weight": 0.0},
        "QQQ": {"stock_weight": 1.0, "bond_weight": 0.0, "cash_weight": 0.0},
    }
    alloc_iv = allocator.allocate(req_iv, latest_predictions=preds, risk_vols={"AAPL": 0.40, "QQQ": 0.20})
    rows = {r["ticker"]: r for r in alloc_iv["allocation_rows"]}
    assert rows["QQQ"]["recommended_weight"] > rows["AAPL"]["recommended_weight"], rows
    assert alloc_iv["allocation_diagnostics"]["capital_mode_effective"] == "inverse_vol"

    # Missing inverse-vol estimate must fail clearly instead of silently using
    # current weights.
    try:
        allocator.allocate(req_iv, latest_predictions=preds, risk_vols={"AAPL": 0.40})
    except ValueError as exc:
        assert "inverse_vol" in str(exc)
    else:
        raise AssertionError("inverse_vol with missing volatility did not raise")

    print("PASS allocation_validation_guards")


if __name__ == "__main__":
    main()
