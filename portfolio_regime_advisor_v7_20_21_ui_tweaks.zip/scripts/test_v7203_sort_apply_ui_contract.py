from pathlib import Path


def main() -> None:
    text = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
    assert 'text="비중순 정렬"' in text
    assert 'def sort_current_portfolio_by_weight' in text
    assert 'def apply_recommended_portfolio_to_current' in text
    assert '추천 포트폴리오를 현재 포트폴리오에 적용' in text
    assert 'BOND_BUCKET' in text
    assert 'CASH는 운용자금 기준으로 자동 재계산' in text
    doc = Path("docs/V7_20_3_SORT_AND_APPLY_RECOMMENDATION.md").read_text(encoding="utf-8")
    assert "비중순 정렬" in doc
    assert "추천 적용" in doc
    print("PASS v7203_sort_apply_ui_contract")


if __name__ == "__main__":
    main()
