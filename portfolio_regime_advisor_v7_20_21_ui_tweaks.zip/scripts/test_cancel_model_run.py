from __future__ import annotations

import argparse
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pra_v5_1.cache import MarketDataCache
from pra_v5_1.prediction_engine import PredictionGenerationService, PredictionRepository
from pra_v5_1.utils import PraCancelledError


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        fake = root / "fake_xgb.py"
        fake.write_text(
            """
from __future__ import annotations
import argparse, time
p = argparse.ArgumentParser()
p.add_argument('--target-ticker', required=True)
p.add_argument('--result-dir', required=True)
p.add_argument('--speed-profile')
p.add_argument('--h10-down-only', action='store_true')
p.add_argument('--transaction-cost-rate')
args = p.parse_args()
time.sleep(30)
""".strip(),
            encoding="utf-8",
        )
        svc = PredictionGenerationService(
            MarketDataCache(root / "cache"),
            PredictionRepository(root / "predictions"),
            root / "runs",
            external_script_path=fake,
        )
        cancel_event = threading.Event()
        holder = {}

        def run():
            try:
                svc.generate_external_v8641_xgb(["QQQ"], force=True, cancel_event=cancel_event)
                holder["result"] = "completed"
            except Exception as exc:
                holder["exc"] = exc

        th = threading.Thread(target=run, daemon=True)
        th.start()
        time.sleep(0.75)
        cancel_event.set()
        th.join(timeout=8)
        assert not th.is_alive(), "cancelled prediction thread did not stop"
        assert isinstance(holder.get("exc"), PraCancelledError), f"expected PraCancelledError, got {holder}"
    print("PASS cancel_model_run")


if __name__ == "__main__":
    main()
