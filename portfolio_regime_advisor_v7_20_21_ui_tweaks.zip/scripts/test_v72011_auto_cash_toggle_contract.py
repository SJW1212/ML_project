from __future__ import annotations

import tempfile
from pathlib import Path

from pra_v5_1.user_settings import UserSettings, load_user_settings, save_user_settings
from pra_v5_1.portfolio_slots import PortfolioSlot, PortfolioSlotAsset, load_portfolio_slots, save_portfolio_slots


def main() -> None:
    app = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")
    init = Path("src/pra_v5_1/__init__.py").read_text(encoding="utf-8")
    settings_src = Path("src/pra_v5_1/user_settings.py").read_text(encoding="utf-8")
    slots_src = Path("src/pra_v5_1/portfolio_slots.py").read_text(encoding="utf-8")

    assert 'APP_VERSION = "7.20.21"' in app
    assert '__version__ = "7.20.21"' in init
    assert "auto_cash_enabled" in settings_src
    assert "잔여 현금 자동 반영" in app
    assert "on_auto_cash_toggle" in app
    assert "if self._auto_cash_enabled_value() and non_cash_total > operating_capital" in app
    assert 'new_assets.append(("CASH", "현금", "cash", float(cash_amount)))' in app
    assert "CASH는 자동 계산 행이므로 저장하지 않습니다" not in app

    with tempfile.TemporaryDirectory() as td:
        settings_path = Path(td) / "user_settings.json"
        s = UserSettings(auto_cash_enabled=False)
        save_user_settings(s, settings_path)
        loaded = load_user_settings(settings_path)
        assert loaded.auto_cash_enabled is False

        slots_path = Path(td) / "portfolio_slots.json"
        store = load_portfolio_slots(slots_path)
        store.set(
            PortfolioSlot(
                slot_id=1,
                name="manual cash",
                operating_capital=10_000_000,
                assets=[
                    PortfolioSlotAsset("QQQ", "Nasdaq", "etf", 3_000_000),
                    PortfolioSlotAsset("CASH", "현금", "cash", 1_000_000),
                ],
            )
        )
        save_portfolio_slots(store, slots_path)
        loaded_slot = load_portfolio_slots(slots_path).get(1)
        assert [a.ticker for a in loaded_slot.assets] == ["QQQ", "CASH"]

    print("PASS v72011_auto_cash_toggle_contract")


if __name__ == "__main__":
    main()
