from __future__ import annotations

import ast
from pathlib import Path

CTK = Path("src/pra_v5_1/ctk_app.py")


def _find_method(tree: ast.AST, name: str) -> ast.FunctionDef:
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    raise AssertionError(f"method not found: {name}")


def _self_method_calls(fn: ast.FunctionDef) -> set[str]:
    calls: set[str] = set()
    for node in ast.walk(fn):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "self"
        ):
            calls.add(node.func.attr)
    return calls


def main() -> None:
    src = CTK.read_text(encoding="utf-8")
    tree = ast.parse(src)

    # Bug #1 regression: safe_float must be imported because the result-display
    # path (_composite_risk_probability) uses it. Missing import previously
    # raised NameError -> "결과 표시 오류".
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                imported.add(alias.asname or alias.name)
    assert "safe_float" in imported, "safe_float must be imported in ctk_app.py"

    # Bug #2 regression: the performance render guard must delegate to the real
    # renderer and must NOT call itself (previous code caused infinite
    # recursion, so the performance/model tabs never rendered).
    guard = _find_method(tree, "_safe_render_performance_page")
    guard_calls = _self_method_calls(guard)
    assert "_render_performance_page" in guard_calls, (
        "_safe_render_performance_page must call _render_performance_page"
    )
    assert "_safe_render_performance_page" not in guard_calls, (
        "_safe_render_performance_page must not call itself (infinite recursion)"
    )

    print("PASS v72018_render_regression_guard")


if __name__ == "__main__":
    main()
