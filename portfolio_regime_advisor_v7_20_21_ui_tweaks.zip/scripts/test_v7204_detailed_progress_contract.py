from pathlib import Path


def main() -> None:
    pred = Path("src/pra_v5_1/prediction_engine.py").read_text(encoding="utf-8")
    svc = Path("src/pra_v5_1/service.py").read_text(encoding="utf-8")
    init = Path("src/pra_v5_1/__init__.py").read_text(encoding="utf-8")
    app = Path("src/pra_v5_1/ctk_app.py").read_text(encoding="utf-8")

    assert "progress_callback" in pred
    assert "progress_start" in pred
    assert "progress_end" in pred
    assert "모델 종목 준비" in pred
    assert "모델 실행 중" in pred
    assert "경과 {int(elapsed)}초" in pred
    assert "progress_callback=progress" in svc
    assert "모델 예측 생성 준비" in svc or "최신 예측 생성 준비" in svc
    assert '__version__ = "7.20.21"' in init
    assert 'APP_VERSION = "7.20.21"' in app
    print("PASS v7204_detailed_progress_contract")


if __name__ == "__main__":
    main()
