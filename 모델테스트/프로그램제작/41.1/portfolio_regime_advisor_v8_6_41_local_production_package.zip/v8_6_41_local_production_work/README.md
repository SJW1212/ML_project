# Portfolio Regime Advisor v8.6.41 Local Production API

이 패키지는 `v8.6.41_model_label_fixed`를 운영 기준으로 고정한 로컬 실행형 API입니다.
모델 튜닝이나 v0.3.x runtime 실험을 포함하지 않고, v8.6.41 prediction file 결과를 API/UI에서 사용할 수 있게 정리합니다.

## 범위

포함:

- v8.6.41 prediction CSV 로딩
- latest signal / portfolio allocation / dashboard JSON 제공
- equal/custom/inverse-vol 자본 배분
- 하루 1회 OHLCV 캐시 업데이트
- 로컬 FastAPI 실행

제외:

- 실시간 주문
- 자동매매
- 실시간 데이터 스트리밍
- DB 저장
- 사용자 계정별 포트폴리오 저장
- 알림 기능
- Pixso 화면 설계 반영

## 설치

```bat
cd v8_6_41_local_production_work
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## 환경변수

```bat
set V8641_INPUT_DIR=C:\path\to\v8_6_41_prediction_files
set V8641_OUT_DIR=v8_6_41_local_ops
set V8641_ASSETS=QQQ,SPY,AAPL,SOXX,NVDA
set V8641_ALLOCATION_SOURCE=executed
set V8641_CAPITAL_MODE=equal
set V8641_CACHE_DIR=storage\market_cache
set V8641_UPDATE_PROVIDER=yahoo
set V8641_DAILY_UPDATE_HOUR_KST=8
```

## API 실행

```bat
run_v8_6_41_local_api.bat
```

Swagger:

```text
http://127.0.0.1:8000/docs
```

## 주요 API

```text
GET  /health
GET  /assets
GET  /dashboard
POST /dashboard
GET  /latest
POST /portfolio/custom-weights
GET  /validation
GET  /performance
GET  /schema
GET  /data/freshness
POST /data/update-daily
GET  /data/update-status
```

## 하루 1회 데이터 갱신

이 패키지는 실시간 스트리밍을 하지 않습니다. 하루 1회 OHLCV 캐시만 갱신합니다.

```bat
run_daily_update_once.bat
```

또는 Swagger에서 `POST /data/update-daily` 실행:

```json
{
  "tickers": ["QQQ", "SPY", "AAPL", "SOXX", "NVDA"],
  "provider": "yahoo",
  "start": "2013-01-01",
  "end": null,
  "force": false
}
```

캐시 신선도 확인:

```text
GET /data/freshness?tickers=QQQ,SPY,AAPL,SOXX,NVDA&provider=yahoo
```

## 주의

- `/data/update-daily`는 raw OHLCV 캐시 업데이트입니다.
- 포트폴리오 비중 산출은 여전히 v8.6.41 prediction files를 기준으로 합니다.
- KIS는 향후 “시세/일봉 조회 전용”으로만 붙입니다. 주문 기능은 구현하지 않습니다.
