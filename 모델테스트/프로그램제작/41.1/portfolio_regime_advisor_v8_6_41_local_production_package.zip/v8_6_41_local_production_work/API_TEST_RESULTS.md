# v8.6.41 Local Production API Test Results

## Result

- `compileall`: PASS
- equal-weight dashboard payload test: PASS
- custom-weight portfolio test: PASS
- daily cache freshness test: PASS

## Equal-weight latest result

- `as_of_date`: 2026-05-07
- stock: 82.00%
- bond: 11.70%
- cash: 6.30%
- validation fail count: 0

## Custom-weight latest result

- stock: 82.60%
- bond: 11.31%
- cash: 6.09%

## Scope check

Confirmed by package design:

- no order API
- no automated trading
- no DB dependency
- no user-account portfolio storage
- no notification service
- no Pixso-specific mapping
- no realtime market streaming
- daily OHLCV cache update only
