@echo off
setlocal
REM One-shot daily OHLCV cache update. This is not realtime streaming.
if "%V8641_ASSETS%"=="" set V8641_ASSETS=QQQ,SPY,AAPL,SOXX,NVDA
curl -X POST "http://127.0.0.1:8000/data/update-daily" ^
  -H "accept: application/json" ^
  -H "Content-Type: application/json" ^
  -d "{\"tickers\":[\"QQQ\",\"SPY\",\"AAPL\",\"SOXX\",\"NVDA\"],\"provider\":\"yahoo\",\"force\":false}"
