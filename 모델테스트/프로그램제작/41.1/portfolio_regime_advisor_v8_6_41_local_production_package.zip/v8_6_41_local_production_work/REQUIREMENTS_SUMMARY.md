# Portfolio Regime Advisor v8.6.41 Local Production 요구사항 정리

## 1. 채택 모델

- 운영 기준 모델: `v8.6.41_model_label_fixed`
- 실행 방식: `prediction_file` 기반
- v0.3.x runtime 모델, context head gate, horizon ensemble, soft family gate는 운영 기본값에서 제외
- v8.6.42/adaptive/confidence/logit/loss-guard 계열도 운영 기본값에서 제외

## 2. 포함 범위

- 로컬 FastAPI 서버
- v8.6.41 prediction CSV 로딩
- latest signal JSON 제공
- 포트폴리오 주식/채권/현금 비중 계산
- 동일가중, 사용자 지정 비중, inverse-vol 자본 배분
- 사용자 지정 종목 리스트 입력
- performance/chart payload 제공
- validation check 제공
- 하루 1회 OHLCV/시세 캐시 업데이트 API
- CSV/JSON export. 단, UI 기본은 JSON

## 3. 제외 범위

- 실시간 주문
- 자동매매
- broker execution flow
- 실시간 데이터 스트리밍
- DB 저장
- 사용자 계정별 포트폴리오 저장
- 로그인/권한/사용자 계정 관리
- 알림 기능
- Pixso 화면 설계 반영
- 클라우드 배포 전제 구조

## 4. 데이터 갱신 정책

- 실시간 업데이트 없음
- 하루 1회 일봉/OHLCV 캐시 업데이트
- 권장 시점: 한국 시간 오전 8시
- KIS/Yahoo는 주문이 아니라 시세/일봉 데이터 조회와 캐시 업데이트 용도
- 현재 패키지의 Yahoo 업데이트는 `yfinance` 기반
- KIS 데이터 조회 어댑터는 후속 패치 후보이며 주문 API는 구현하지 않음

## 5. 주요 API

- `GET /health`
- `GET /assets`
- `GET /dashboard`
- `POST /dashboard`
- `GET /latest`
- `POST /portfolio/custom-weights`
- `GET /validation`
- `GET /performance`
- `GET /schema`
- `GET /data/freshness`
- `POST /data/update-daily`
- `GET /data/update-status`

## 6. 주요 환경변수

- `V8641_INPUT_DIR`: v8.6.41 prediction/summary 파일 위치
- `V8641_OUT_DIR`: JSON/CSV 출력 위치
- `V8641_ASSETS`: 기본 종목 목록. 예: `QQQ,SPY,AAPL,SOXX,NVDA`
- `V8641_ALLOCATION_SOURCE`: `executed` 또는 `signal`
- `V8641_CAPITAL_MODE`: `equal`, `custom`, `inverse_vol`
- `V8641_CACHE_DIR`: 하루 1회 데이터 캐시 저장 위치
- `V8641_UPDATE_PROVIDER`: `yahoo` 또는 `kis`
- `V8641_DAILY_UPDATE_HOUR_KST`: 권장 일일 갱신 시간
- `V8641_DAILY_FRESHNESS_TOLERANCE_DAYS`: 캐시 신선도 허용 일수

## 7. 산출물 기본 구조

- `dashboard_payload.json`: UI/프론트엔드용 전체 payload
- `latest_state.json`: latest signal + portfolio summary
- optional CSV: 디버깅/export 용도
- raw OHLCV cache: `storage/market_cache/ohlcv/<provider>/<TICKER>.csv`

## 8. 현재 남은 후속 작업 후보

- 사용자의 실제 v8.6.41 prediction 파일 경로에서 API 실행 확인
- 로컬 UI에서 `/dashboard` 연결
- 하루 1회 업데이트를 Windows 작업 스케줄러에 등록
- KIS 시세/일봉 조회 전용 어댑터 추가. 주문 기능은 제외
- 에러 로그 파일 저장 고도화
