# Portfolio Regime Advisor v5.2 Stitch UI Backend

## 목적

로컬 단일 사용자 환경에서 다음 흐름을 수행합니다.

```text
UI/UX 사용자 입력
→ Input Normalizer
→ Ticker Registry(JSON)
→ Daily OHLCV Cache
→ Model Input Builder
→ v8.6.41-compatible Prediction Engine
→ Probability / Signal Output
→ Portfolio Allocation Module
→ Dashboard Payload
→ UI 반환
```

## 제외 범위

- DB 저장 없음
- 사용자 계정별 포트폴리오 저장 없음
- 알림 없음
- Stitch UI 생성물은 REST API로 연동
- 주문/자동매매 없음
- 실시간 스트리밍 없음

## 실행

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
run_api.bat
```

Swagger:

```text
http://127.0.0.1:8000/docs
```

## 핵심 API

- `POST /portfolio/evaluate`: 통합 평가 API
- `POST /tickers/add`: 로컬 ticker registry 저장
- `POST /data/update-daily`: 하루 1회 OHLCV 캐시 갱신
- `POST /predictions/generate`: 캐시 기반 prediction 생성
- `GET /predictions/status`: prediction artifact 상태
- `GET /data/freshness`: cache 최신성
- `GET /ui/contract`: Stitch/프론트 연동용 응답 계약
- `GET /ui/mock-request`: UI 테스트용 요청 샘플

## 포트폴리오 입력 예시

```json
{
  "portfolio": [
    {"name": "애플", "ticker": "AAPL", "asset_type": "stock", "current_weight": 0.25},
    {"name": "QQQ", "ticker": "QQQ", "asset_type": "etf", "current_weight": 0.25},
    {"name": "엔비디아", "ticker": "NVDA", "asset_type": "stock", "current_weight": 0.20},
    {"name": "일라이릴리", "ticker": "LLY", "asset_type": "stock", "current_weight": 0.15},
    {"name": "채권", "ticker": "BOND_BUCKET", "asset_type": "bond_bucket", "current_weight": 0.10},
    {"name": "현금", "ticker": "CASH", "asset_type": "cash", "current_weight": 0.05}
  ],
  "risk_profile": "balanced",
  "user_level": "general",
  "settings": {
    "start_date": "2013-01-01",
    "update_data": true,
    "generate_predictions": true,
    "prediction_engine_mode": "external_v8641_xgb",
    "capital_mode": "current_weight",
    "missing_asset_policy": "cash_fallback"
  }
}
```

## Prediction Engine Mode

### reference_v8641_compatible

- 기본값입니다.
- OHLCV 캐시만 읽어서 leakage-safe feature를 만들고, v8.6.41 출력 스키마와 동일한 확률 컬럼을 생성합니다.
- 외부 네트워크를 직접 호출하지 않습니다.

### external_v8641_xgb

- 원본 `xgb_recency_weighted_v8_6_41_model_label_fixed.py`를 연결하기 위한 reserved mode입니다.
- 원본 스크립트는 `model_engine/`에 포함되어 있고, 같은 폴더의 `yfinance.py` shim은 캐시 CSV를 읽도록 되어 있습니다.
- 전체 XGBoost 재학습/생성은 시간이 오래 걸릴 수 있습니다.

## 테스트

```bat
set PYTHONPATH=%CD%\src
python -m compileall src
python scripts\test_smoke.py
```


## v5.2 Stitch UI Integration 추가 사항

- `engine_status` 섹션 추가: `engine_mode`, `production_ready_for_investment`, reference engine 경고 표시
- `ui` 섹션 추가: 현재/추천 비중, 변화폭, 주요 경고를 바로 표시 가능
- `allocation_rows`에 한국어 라벨과 판단 근거 추가: `action_ko`, `risk_class_ko`, `direction_class_ko`, `reason_codes`, `reason_text`
- `latest_signals`에 확률 퍼센트와 한국어 라벨 추가
- `benchmarks` 섹션 추가: 모델 추천, 현재 포트폴리오 유지, QQQ, SPY, 60/40, 85/10/5 비교 구조
- 최신일 수익률은 `return_status="pending"`, `portfolio_return=null`로 표시
- Stitch 연동 문서는 `docs/STITCH_UI_INTEGRATION.md` 참고

## v5.2.1 변경: 실제 v8.6.41 XGBoost 스크립트 엔진 연결

이 패키지는 이제 `external_v8641_xgb` 모드를 실제 실행 경로로 지원합니다.

- `reference_v8641_compatible`: 빠른 UI/API 검증용 수식 기반 reference 엔진
- `external_v8641_xgb`: 포함된 `xgb_recency_weighted_v8_6_41_model_label_fixed.py`를 subprocess로 실행하여 실제 XGBoost walk-forward 예측 CSV를 생성하는 엔진

실제 XGBoost 엔진 사용 예:

```json
{
  "settings": {
    "update_data": true,
    "generate_predictions": true,
    "force_prediction": true,
    "prediction_engine_mode": "external_v8641_xgb",
    "speed_profile": "balanced",
    "transaction_cost_bps": 10.0
  }
}
```

주의:

- `external_v8641_xgb`는 실제 XGBoost 학습/예측 경로입니다.
- 다만 매번 스크립트가 walk-forward 학습을 수행하는 방식이므로 locked artifact 로딩 방식은 아닙니다.
- 실행 시간이 reference 엔진보다 훨씬 길 수 있습니다.
- 캐시에 위험자산뿐 아니라 `IEF`, `BIL`도 필요하므로, evaluate 시 자동 업데이트 대상에 포함됩니다.


## KIS 데이터 연동

- `provider=yahoo`: yfinance 기반 기본 데이터 수집
- `provider=kis`: 한국투자증권 Open API 시세/일봉 조회 전용
- `provider=hybrid`: Yahoo 장기 백필 + KIS 최신 일봉 overlay

키 설정 및 API 사용법은 `docs/KIS_DATA_INTEGRATION.md`를 확인하세요. 주문/자동매매/실시간 스트리밍은 이 패키지 범위에서 제외됩니다.

## v5.4 변경: KIS 키 입력 생략 상태에서 가능한 운영 준비 완료

KIS app key/app secret을 아직 입력하지 않은 상태에서도 다음 기능을 사용할 수 있습니다.

- `GET /data/provider-status`: Yahoo/KIS/Hybrid provider 상태 확인
- `POST /dev/bootstrap-sample-data`: 네트워크/키 없이 UI·API smoke test용 샘플 OHLCV 캐시 생성
- `GET /dashboard`: 마지막 `/portfolio/evaluate` 결과 조회
- `GET /validation`: 마지막 결과의 validation 요약 조회
- `POST /ops/run-latest`: 마지막 포트폴리오 요청을 저장해두고 다음 날 같은 조건으로 재실행

주의: `/dev/bootstrap-sample-data`는 실제 시장 데이터가 아닙니다. Stitch UI 연결, API schema, allocation, validation 흐름 검증용입니다. 성과 주장이나 투자 판단에 사용하면 안 됩니다.

키가 없는 동안 권장 흐름:

```bat
set PYTHONPATH=%CD%\src
python scripts\test_keyless_ops.py
run_api.bat
```

Swagger에서 다음 순서로 확인합니다.

```text
1. GET  /data/provider-status
2. POST /dev/bootstrap-sample-data
3. POST /portfolio/evaluate
4. GET  /dashboard
5. GET  /validation
6. POST /ops/run-latest
```

KIS 키 입력 전 실데이터 운영은 `provider=yahoo`가 가장 단순합니다. `provider=hybrid`는 KIS 키가 없으면 KIS overlay 실패를 warning/note로 남기고 Yahoo 기반 hybrid cache로 fallback합니다.
