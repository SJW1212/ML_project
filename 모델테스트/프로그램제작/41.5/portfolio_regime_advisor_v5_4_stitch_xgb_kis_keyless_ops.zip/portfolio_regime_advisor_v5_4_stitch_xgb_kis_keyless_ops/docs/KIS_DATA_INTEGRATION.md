# KIS 데이터 연동 메모

이 패키지의 KIS 연동 범위는 설계서 요구사항에 맞춰 **시세/일봉 조회 전용**입니다. 주문, 정정/취소, 잔고 조회, 자동매매, 실시간 스트리밍은 구현하지 않습니다.

## 지원 provider

- `yahoo`: yfinance 기반 장기 OHLCV 백필/갱신
- `kis`: 한국투자증권 Open API 일봉/시세 캐시만 사용
- `hybrid`: Yahoo 장기 백필 + KIS 최신 일봉 overlay 후 `storage/market_cache/ohlcv/hybrid/{TICKER}.csv` 저장

모델 학습/예측에는 장기 히스토리가 필요하므로 일반적으로 `hybrid` 또는 `yahoo`를 권장합니다. KIS 해외주식 기간별시세는 계정/API 정책에 따라 한 번에 받을 수 있는 행 수가 제한될 수 있습니다.

## 키 설정 방법

### 방법 A. 환경변수

```bat
set KIS_APP_KEY=발급받은_APP_KEY
set KIS_APP_SECRET=발급받은_APP_SECRET
set KIS_BASE_URL=https://openapi.koreainvestment.com:9443
set KIS_OVERSEAS_EXCHANGE=NAS
```

### 방법 B. 로컬 API로 저장

```http
POST /settings/kis/save
```

요청 예:

```json
{
  "app_key": "...",
  "app_secret": "...",
  "base_url": "https://openapi.koreainvestment.com:9443",
  "virtual_trade": false,
  "overseas_exchange": "NAS",
  "persist_secret": true
}
```

저장 위치:

```text
storage/config/kis_config.json
storage/config/kis_token.json
```

이 파일은 로컬 전용이며 절대 Git이나 외부에 공유하면 안 됩니다.

## 상태 확인

```http
GET /settings/kis/status
GET /settings/kis/template
```

## 데이터 업데이트 예

```json
{
  "tickers": ["AAPL", "QQQ", "NVDA"],
  "provider": "hybrid",
  "start": "1999-03-10",
  "force": false
}
```

## 포트폴리오 평가 예

```json
{
  "settings": {
    "provider": "hybrid",
    "update_data": true,
    "generate_predictions": true,
    "prediction_engine_mode": "external_v8641_xgb",
    "force_update": false,
    "force_prediction": false
  }
}
```
