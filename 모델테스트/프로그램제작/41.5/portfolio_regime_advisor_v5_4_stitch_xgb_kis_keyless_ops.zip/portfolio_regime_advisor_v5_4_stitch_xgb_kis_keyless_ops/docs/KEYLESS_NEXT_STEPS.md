# Keyless Next Steps

KIS 키를 아직 입력하지 않은 상태에서 진행 가능한 단계입니다.

## 처리된 범위

1. Provider 상태 진단
   - `GET /data/provider-status`
   - KIS configured 여부, 주문/실시간 제외 여부, 권장 provider 확인

2. 샘플 캐시 생성
   - `POST /dev/bootstrap-sample-data`
   - 실제 시장 데이터가 아니라 API/UI 검증용 deterministic OHLCV 생성
   - 기본 provider: `yahoo`, `hybrid`

3. 마지막 Dashboard 저장/조회
   - `/portfolio/evaluate` 실행 후 `storage/latest_dashboard_payload.json` 저장
   - `GET /dashboard`로 재조회
   - `GET /validation`으로 검증 요약 확인

4. 마지막 요청 재실행
   - `/portfolio/evaluate` 실행 후 `storage/config/latest_portfolio_request.json` 저장
   - `POST /ops/run-latest`로 다음 날 동일 요청 재실행 가능
   - provider, engine mode, force flags 일부 override 가능

## 키 없이 권장되는 개발 순서

```text
1. /dev/bootstrap-sample-data 로 UI 테스트용 캐시 생성
2. /portfolio/evaluate 를 reference engine으로 실행
3. /dashboard 응답을 Stitch UI에 연결
4. /ops/run-latest 로 하루 1회 갱신 버튼/배치 동작 검증
5. 실제 데이터는 provider=yahoo로 확인
6. KIS 키 입력 후 provider=hybrid로 전환
```

## 주의

- 샘플 데이터는 성능 검증 자료가 아니다.
- KIS 키 없이는 KIS 실조회가 불가능하다.
- `external_v8641_xgb`는 실제 XGBoost 스크립트 실행이므로 시간이 오래 걸릴 수 있다.
- 운영 전에는 `provider=yahoo` 또는 KIS 키 입력 후 `provider=hybrid`로 실제 OHLCV 캐시를 만들어야 한다.
