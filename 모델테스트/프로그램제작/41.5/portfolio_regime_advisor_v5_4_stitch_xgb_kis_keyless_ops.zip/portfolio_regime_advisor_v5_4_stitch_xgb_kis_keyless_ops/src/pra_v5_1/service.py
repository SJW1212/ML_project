from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

import pandas as pd

from .allocation import PortfolioAllocationService
from .benchmarks import BenchmarkService
from .cache import MarketDataCache
from .config import AppConfig
from .logging_utils import JsonlLogger
from .performance import PerformanceAnalyzer
from .prediction_engine import PredictionGenerationService, PredictionRepository
from .provider import DailyMarketDataUpdater
from .schemas import DailyUpdateRequest, PortfolioAssetInput, PortfolioEvaluateRequest, PredictionGenerateRequest, KisSettingsSaveRequest, BootstrapSampleDataRequest, RunLatestRequest
from .signals import SignalClassifier
from .sample_data import bootstrap_sample_cache
from .ticker_registry import LocalTickerRegistry
from .utils import atomic_write_json, config_hash, ensure_dir, normalize_ticker, utc_now_iso
from .ui_contract import postprocess_dashboard_payload
from .validation import ValidationService


class PortfolioRegimeAdvisorService:
    def __init__(self, config: AppConfig | None = None):
        self.config = config or AppConfig.from_json()
        ensure_dir(self.config.storage_root)
        self.registry = LocalTickerRegistry(self.config.registry_path)
        self.cache = MarketDataCache(self.config.cache_dir)
        self.updater = DailyMarketDataUpdater(self.cache, self.config)
        self.pred_repo = PredictionRepository(self.config.prediction_dir)
        self.pred_gen = PredictionGenerationService(
            self.cache,
            self.pred_repo,
            self.config.run_dir,
            external_script_path=self.config.external_v8641_script,
        )
        self.allocator = PortfolioAllocationService()
        self.performance = PerformanceAnalyzer()
        self.benchmarks = BenchmarkService(self.cache, self.performance)
        self.validator = ValidationService()
        self.signals = SignalClassifier()
        self.logger = JsonlLogger(self.config.log_dir / "events.jsonl")

    @property
    def latest_request_path(self) -> Path:
        return self.config.config_dir / "latest_portfolio_request.json"

    @property
    def latest_dashboard_path(self) -> Path:
        return self.config.storage_root / "latest_dashboard_payload.json"

    def provider_status(self) -> Dict[str, Any]:
        kis = self.kis_status()
        return {
            "default_provider": self.config.default_provider,
            "supported_providers": ["yahoo", "kis", "hybrid"],
            "recommended_without_kis_key": "yahoo",
            "recommended_with_kis_key": "hybrid",
            "provider_notes": {
                "yahoo": "Uses yfinance for long historical OHLCV cache.",
                "kis": "Uses KIS quotation/daily OHLCV only; credentials required.",
                "hybrid": "Yahoo historical backfill plus KIS latest overlay when KIS credentials are configured; otherwise degrades to Yahoo-only hybrid cache with warnings.",
            },
            "kis": kis,
            "order_execution": False,
            "realtime_streaming": False,
        }

    def bootstrap_sample_data(self, req: BootstrapSampleDataRequest) -> Dict[str, Any]:
        results = bootstrap_sample_cache(
            self.cache,
            req.tickers,
            providers=req.providers,
            start=req.start,
            end=req.end,
            periods=req.periods,
            overwrite=req.overwrite,
        )
        payload = {
            "ok": True,
            "is_sample_data": True,
            "warning": "Generated deterministic sample OHLCV for local UI/API smoke tests only. Do not use this cache for model performance claims or investment decisions.",
            "results": [r.__dict__ for r in results],
        }
        self.logger.write("bootstrap_sample_data", **payload)
        return payload

    def load_latest_dashboard(self) -> Dict[str, Any]:
        from .utils import load_json
        payload = load_json(self.latest_dashboard_path, default=None)
        if not payload:
            raise FileNotFoundError(f"Latest dashboard payload not found: {self.latest_dashboard_path}")
        return payload

    def latest_validation(self) -> Dict[str, Any]:
        dashboard = self.load_latest_dashboard()
        return {
            "ok": bool(dashboard.get("ok")),
            "request_id": dashboard.get("request_id"),
            "as_of_date": dashboard.get("as_of_date"),
            "engine_status": dashboard.get("engine_status"),
            "validation": dashboard.get("validation"),
        }

    def run_latest(self, req: RunLatestRequest | None = None) -> Dict[str, Any]:
        from .utils import load_json
        data = load_json(self.latest_request_path, default=None)
        if not data:
            raise FileNotFoundError(f"Latest portfolio request not found: {self.latest_request_path}")
        request = PortfolioEvaluateRequest.model_validate(data)
        if req is not None:
            overrides = {
                "provider": req.provider,
                "prediction_engine_mode": req.prediction_engine_mode,
                "update_data": req.update_data,
                "generate_predictions": req.generate_predictions,
                "force_update": req.force_update,
                "force_prediction": req.force_prediction,
                "speed_profile": req.speed_profile,
            }
            update = {k: v for k, v in overrides.items() if v is not None}
            if update:
                current = request.settings.model_dump()
                current.update(update)
                request.settings = request.settings.__class__.model_validate(current)
        return self.evaluate(request)

    def add_tickers(self, tickers: List[str], asset_type: str = "stock", market: str = "US", note: str | None = None) -> Dict:
        records = self.registry.add_or_update(tickers, asset_type=asset_type, market=market, note=note)
        return {"ok": True, "tickers": [r.__dict__ for r in records]}

    def update_daily(self, req: DailyUpdateRequest) -> Dict:
        tickers = req.tickers or self.registry.enabled_tickers()
        status = self.updater.update_daily(tickers, provider=req.provider, start=req.start, end=req.end, force=req.force)
        payload = {"provider": status.provider, "updated": status.updated, "skipped": status.skipped, "errors": status.errors, "notes": status.notes or []}
        self.logger.write("daily_update", **payload)
        return payload

    def kis_status(self) -> Dict:
        return self.updater.kis_status()

    def save_kis_settings(self, req: KisSettingsSaveRequest) -> Dict:
        from .kis_provider import KisSettings
        settings = KisSettings(
            app_key=req.app_key,
            app_secret=req.app_secret,
            base_url=req.base_url.rstrip("/"),
            virtual_trade=req.virtual_trade,
            account_no=req.account_no or "",
            account_product_code=req.account_product_code,
            overseas_exchange=req.overseas_exchange,
            custtype=req.custtype,
            access_token=req.access_token or "",
        )
        path = self.updater.kis_store.save(settings, persist_secret=req.persist_secret)
        payload = {"ok": True, "path": str(path), "settings": settings.redacted(), "warning": "KIS credentials are stored in a local-only config file. Do not commit or share it."}
        self.logger.write("kis_settings_saved", ok=True, path=str(path))
        return payload

    def generate_predictions(self, req: PredictionGenerateRequest, risk_sensitivity: float = 1.0, provider: str = "yahoo") -> Dict:
        tickers = req.tickers or self.registry.enabled_tickers()
        if req.mode == "external_v8641_xgb":
            results = self.pred_gen.generate_external_v8641_xgb(
                tickers,
                provider=provider,
                force=req.force,
                speed_profile=req.speed_profile,
                transaction_cost_bps=req.transaction_cost_bps,
            )
        else:
            results = self.pred_gen.generate_reference(tickers, provider=provider, force=req.force, risk_sensitivity=risk_sensitivity)
        payload = {"ok": all(not r.errors for r in results), "results": [r.__dict__ | {"path": str(r.path)} for r in results]}
        self.logger.write("prediction_generation", **payload)
        return payload

    @staticmethod
    def _risk_assets(portfolio: List[PortfolioAssetInput]) -> List[PortfolioAssetInput]:
        return [a for a in portfolio if a.is_risk_asset]

    def evaluate(self, request: PortfolioEvaluateRequest) -> Dict:
        request_id = config_hash(request.model_dump())
        ensure_dir(self.config.config_dir)
        atomic_write_json(self.latest_request_path, request.model_dump())
        self.logger.write("portfolio_evaluate_started", request_id=request_id, user_level=request.user_level)
        risk_assets = self._risk_assets(request.portfolio)
        risk_tickers = [a.ticker for a in risk_assets]
        if not risk_tickers:
            raise ValueError("At least one risk asset ticker is required")
        # Registry update is local JSON only, not user account storage.
        self.registry.add_or_update(risk_tickers, asset_type="risk_asset", market="US", note="from_evaluate_request")
        # Data update. The script-based v8.6.41 XGBoost engine also needs IEF/BIL cache.
        if request.settings.update_data:
            update_tickers = list(risk_tickers)
            update_start = request.settings.start_date
            if request.settings.prediction_engine_mode == "external_v8641_xgb":
                update_tickers = list(dict.fromkeys([*risk_tickers, self.config.default_bond_ticker, self.config.default_cash_ticker]))
                # The original v8.6.41 script starts from 1999-03-10 by default.
                update_start = "1999-03-10"
            update_req = DailyUpdateRequest(tickers=update_tickers, provider=request.settings.provider, start=update_start, end=request.settings.end_date, force=request.settings.force_update)
            update_status = self.update_daily(update_req)
            if update_status.get("errors"):
                # Continue only for tickers that already have cache.
                pass
        else:
            update_status = {"provider": request.settings.provider, "updated": [], "skipped": [], "errors": {}}
        if request.settings.generate_predictions:
            gen_req = PredictionGenerateRequest(
                tickers=risk_tickers,
                start=request.settings.start_date,
                end=request.settings.end_date,
                provider=request.settings.provider,
                mode=request.settings.prediction_engine_mode,
                force=request.settings.force_prediction,
                speed_profile=request.settings.speed_profile,
                transaction_cost_bps=request.settings.transaction_cost_bps,
            )
            gen_status = self.generate_predictions(gen_req, risk_sensitivity=request.settings.risk_sensitivity, provider=request.settings.provider)
        else:
            gen_status = {"ok": True, "results": []}
        frames: Dict[str, pd.DataFrame] = {}
        latest_predictions: Dict[str, Dict] = {}
        latest_signals: List[Dict] = []
        for t in risk_tickers:
            df = self.pred_repo.read(t)
            frames[t] = df
            latest = df.iloc[-1].to_dict()
            latest["Date"] = str(latest.get("Date"))
            cls = self.signals.classify(latest)
            latest.update(cls)
            latest_predictions[t] = latest
            latest_signals.append({k: latest.get(k) for k in [
                "ticker", "Date", "prob_normal", "prob_high_vol", "prob_overall_risk",
                "prob_up_strengthening_5d", "prob_up_strengthening_10d", "prob_up_strengthening_20d", "prob_up_strengthening_score",
                "prob_down_strengthening_5d", "prob_down_strengthening_10d", "prob_down_strengthening_20d", "prob_down_strengthening_score",
                "risk_class", "direction_class", "allocation_class", "stock_weight", "bond_weight", "cash_weight"
            ]})
        allocation = self.allocator.allocate(request, latest_predictions)
        perf_weights = {row["ticker"]: row["recommended_weight"] for row in allocation["allocation_rows"]}
        perf_df = self.performance.portfolio_returns(frames, perf_weights, missing_asset_policy=request.settings.missing_asset_policy)
        recommended_returns = perf_df["portfolio_return"] if not perf_df.empty else pd.Series(dtype=float)
        metrics = self.performance.metrics(recommended_returns)
        current_weights = {a.ticker: float(a.current_weight or 0.0) for a in risk_assets}
        benchmarks = self.benchmarks.build(frames, current_weights, recommended_returns, provider=request.settings.provider)
        freshness = self.cache.freshness(risk_tickers, provider=request.settings.provider)
        checks = []
        checks.extend(self.validator.validate_predictions(frames, freshness))
        checks.extend(self.validator.validate_allocation(allocation))
        validation = self.validator.summarize(checks)
        payload = {
            "ok": validation["fail_count"] == 0,
            "request_id": request_id,
            "model_version": "v8.6.41_model_label_fixed_xgboost_script" if request.settings.prediction_engine_mode == "external_v8641_xgb" else "v8.6.41_model_label_fixed_compatible_reference",
            "engine_mode": request.settings.prediction_engine_mode,
            "as_of_date": max((s.get("Date") for s in latest_signals if s.get("Date")), default=None),
            "portfolio_input": [a.model_dump() for a in request.portfolio],
            "latest_signals": latest_signals,
            "allocation": allocation,
            "performance": {
                "metrics": metrics,
                "equity_curve_tail": perf_df.tail(20).assign(Date=lambda x: x["Date"].astype(str)).to_dict(orient="records") if not perf_df.empty else [],
            },
            "benchmarks": benchmarks,
            "data_update_status": update_status,
            "prediction_generation_status": gen_status,
            "cache_freshness": freshness,
            "validation": validation,
        }
        payload = postprocess_dashboard_payload(payload, perf_df=perf_df)
        atomic_write_json(self.latest_dashboard_path, payload)
        self.logger.write("portfolio_evaluate_finished", request_id=request_id, ok=payload["ok"], fail_count=validation["fail_count"], warn_count=validation["warn_count"])
        return payload
