from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

import pandas as pd

from .cache import MarketDataCache
from .config import AppConfig
from .kis_provider import KisCredentialStore, KisQuoteProvider
from .utils import normalize_ticker


@dataclass
class UpdateStatus:
    provider: str
    updated: List[str]
    skipped: List[str]
    errors: Dict[str, str]
    notes: List[str] | None = None


class YahooMarketDataProvider:
    def download_ohlcv(self, ticker: str, start: str, end: Optional[str] = None) -> pd.DataFrame:
        try:
            import yfinance as yf
        except Exception as exc:
            raise RuntimeError("yfinance is not installed. Run: python -m pip install yfinance") from exc
        t = normalize_ticker(ticker)
        df = yf.download(t, start=start, end=end, auto_adjust=True, progress=False, threads=False)
        if df is None or df.empty:
            raise RuntimeError(f"No OHLCV data returned for {t}")
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
        return df.reset_index()


class DailyMarketDataUpdater:
    def __init__(self, cache: MarketDataCache, config: AppConfig | None = None):
        self.cache = cache
        self.config = config or AppConfig.from_json()
        self.kis_store = KisCredentialStore(self.config.config_dir)

    def kis_status(self) -> Dict:
        return KisQuoteProvider(self.kis_store).status()

    def update_daily(self, tickers: Iterable[str], provider: str = "yahoo", start: str = "2013-01-01", end: Optional[str] = None, force: bool = False) -> UpdateStatus:
        provider = provider.lower()
        updated: List[str] = []
        skipped: List[str] = []
        errors: Dict[str, str] = {}
        notes: List[str] = []

        if provider not in {"yahoo", "kis", "hybrid"}:
            return UpdateStatus(provider=provider, updated=[], skipped=[], errors={"provider": f"Unsupported provider: {provider}"}, notes=[])

        yf_provider = YahooMarketDataProvider()
        kis_provider = KisQuoteProvider(self.kis_store)

        for raw in tickers:
            t = normalize_ticker(raw)
            try:
                target_provider = provider
                if not force and self.cache.has_ohlcv(t, target_provider):
                    fresh = self.cache.freshness([t], target_provider)[0]
                    if fresh.get("is_fresh_daily"):
                        skipped.append(t)
                        continue

                if provider == "yahoo":
                    df = yf_provider.download_ohlcv(t, start=start, end=end)
                    self.cache.write_ohlcv(t, df, provider)
                elif provider == "kis":
                    df = kis_provider.download_ohlcv(t, start=start, end=end)
                    self.cache.write_ohlcv(t, df, provider)
                    notes.append(f"{t}: KIS daily quotation cache updated. Long historical range can be limited by KIS endpoint/account policy.")
                else:  # hybrid: Yahoo backfill + KIS latest rows, saved under provider=hybrid.
                    yahoo_df = None
                    kis_df = None
                    yahoo_error = None
                    kis_error = None
                    try:
                        if self.cache.has_ohlcv(t, "yahoo") and not force:
                            yahoo_df = self.cache.read_ohlcv(t, "yahoo")
                        else:
                            yahoo_df = yf_provider.download_ohlcv(t, start=start, end=end)
                            self.cache.write_ohlcv(t, yahoo_df, "yahoo")
                    except Exception as exc:
                        yahoo_error = exc
                    try:
                        kis_df = kis_provider.download_ohlcv(t, start=start, end=end)
                        self.cache.write_ohlcv(t, kis_df, "kis")
                    except Exception as exc:
                        kis_error = exc
                    if yahoo_df is None and kis_df is None:
                        raise RuntimeError(f"hybrid update failed. yahoo={yahoo_error}; kis={kis_error}")
                    parts = [df for df in [yahoo_df, kis_df] if df is not None and not df.empty]
                    merged = pd.concat(parts, ignore_index=True)
                    self.cache.write_ohlcv(t, merged, "hybrid")
                    if kis_error:
                        notes.append(f"{t}: hybrid used Yahoo data; KIS overlay failed: {kis_error}")
                    else:
                        notes.append(f"{t}: hybrid cache = Yahoo historical backfill + KIS latest quotation rows.")
                updated.append(t)
            except Exception as exc:
                errors[t] = str(exc)
        return UpdateStatus(provider=provider, updated=updated, skipped=skipped, errors=errors, notes=notes)
