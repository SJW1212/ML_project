from pathlib import Path
import tempfile

from pra_v5_1.config import AppConfig
from pra_v5_1.schemas import DailyUpdateRequest, KisSettingsSaveRequest, PredictionGenerateRequest
from pra_v5_1.service import PortfolioRegimeAdvisorService


def main():
    root = Path(tempfile.mkdtemp()) / "storage"
    svc = PortfolioRegimeAdvisorService(AppConfig(storage_root=root))

    status = svc.kis_status()
    assert status["scope"] == "quotation_daily_ohlcv_only"
    assert status["order_execution"] is False

    saved = svc.save_kis_settings(KisSettingsSaveRequest(
        app_key="TEST_APP_KEY_1234",
        app_secret="TEST_SECRET_5678",
        persist_secret=True,
        overseas_exchange="NAS",
    ))
    assert saved["ok"] is True
    assert "..." in saved["settings"]["app_key"]
    assert (root / "config" / "kis_config.json").exists()

    assert DailyUpdateRequest(provider="hybrid").provider == "hybrid"
    assert PredictionGenerateRequest(provider="hybrid").provider == "hybrid"
    print("PASS kis_config")


if __name__ == "__main__":
    main()
