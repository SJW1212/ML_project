from pathlib import Path
import tempfile

from pra_v5_1.config import AppConfig
from pra_v5_1.schemas import BootstrapSampleDataRequest, PortfolioEvaluateRequest, RunLatestRequest
from pra_v5_1.service import PortfolioRegimeAdvisorService


def make_request():
    return PortfolioEvaluateRequest.model_validate({
        "portfolio": [
            {"name": "애플", "ticker": "AAPL", "asset_type": "stock", "current_weight": 0.25},
            {"name": "QQQ", "ticker": "QQQ", "asset_type": "etf", "current_weight": 0.25},
            {"name": "엔비디아", "ticker": "NVDA", "asset_type": "stock", "current_weight": 0.20},
            {"name": "일라이릴리", "ticker": "LLY", "asset_type": "stock", "current_weight": 0.15},
            {"name": "채권", "ticker": "BOND_BUCKET", "asset_type": "bond_bucket", "current_weight": 0.10},
            {"name": "현금", "ticker": "CASH", "asset_type": "cash", "current_weight": 0.05},
        ],
        "risk_profile": "balanced",
        "user_level": "developer",
        "settings": {
            "provider": "hybrid",
            "update_data": False,
            "generate_predictions": True,
            "force_prediction": True,
            "prediction_engine_mode": "reference_v8641_compatible",
            "capital_mode": "current_weight",
            "missing_asset_policy": "cash_fallback",
        },
    })


def main():
    root = Path(tempfile.mkdtemp()) / "storage"
    svc = PortfolioRegimeAdvisorService(AppConfig(storage_root=root))
    bs = svc.bootstrap_sample_data(BootstrapSampleDataRequest(
        tickers=["AAPL", "QQQ", "NVDA", "LLY", "IEF", "BIL"],
        providers=["yahoo", "hybrid"],
        periods=900,
        overwrite=True,
    ))
    assert bs["ok"] is True
    assert bs["is_sample_data"] is True
    assert len(bs["results"]) == 6

    status = svc.provider_status()
    assert status["kis"]["configured"] is False
    assert status["order_execution"] is False

    payload = svc.evaluate(make_request())
    assert payload["ok"] is True, payload["validation"]
    assert payload["engine_status"]["engine_mode"] == "reference_v8641_compatible"
    assert svc.latest_dashboard_path.exists()
    assert svc.latest_request_path.exists()
    latest = svc.load_latest_dashboard()
    assert latest["request_id"] == payload["request_id"]
    val = svc.latest_validation()
    assert "validation" in val

    rerun = svc.run_latest(RunLatestRequest(force_prediction=False, provider="hybrid"))
    assert rerun["ok"] is True
    print("PASS keyless_ops", payload["as_of_date"], len(payload["latest_signals"]))


if __name__ == "__main__":
    main()
